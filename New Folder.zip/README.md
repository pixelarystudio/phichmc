# PHICHMC — Discover. Create. Share Minecraft.

PHICHMC is a modern, high-performance community platform built specifically for the Minecraft community to discover, share, review, and download Minecraft resources.

---

## 🌟 Core Supported Resource Types
- **Mods** (Forge, Fabric, NeoForge, Quilt)
- **Add-ons** (Bedrock .mcaddon, .mcpack)
- **Resource Packs** (Java / Bedrock textures, fonts, sounds)
- **Shaders** (OptiFine, Iris)
- **Data Packs** (Vanilla datapacks)
- **Maps** (Adventure, Survival, Puzzle, Minigames)
- **Modpacks** (CurseForge / Modrinth compatible zip packs)
- **Skins** (Player skins & HD skins)
- **Other** (Scripts, utilities, documentation)

> **Out of Scope Notice:** PHICHMC explicitly excludes Minecraft server lists, server hosting, server management, launchers, launcher marketplace, and external scraping tools.

---

## 🛠️ Tech Stack & Architecture

- **Frontend:** React 19 + TypeScript + Vite + Tailwind CSS + Lucide Icons
- **State & Context:** React Context API (Theme, Auth, SiteConfig)
- **Backend / BaaS:** Firebase
  - **Firebase Authentication:** Email/Password, Google OAuth, custom claims.
  - **Cloud Firestore:** Scalable NoSQL document store with strict security rules.
  - **Firebase Cloud Storage:** File uploads with extension whitelisting (`.jar`, `.zip`, `.mcpack`, `.mcaddon`, `.mrpack`, `.png`, etc.) and blocking dangerous executables (`.exe`, `.bat`, `.cmd`, `.sh`).
  - **Cloud Functions:** Secure serverless callable endpoints for moderation, role assignment, rate limiting, and metrics.
  - **Firebase Hosting:** Fast edge-hosted web platform.
- **Monetization & Ads:** Safe Adsterra integration with non-intrusive banner placements (Header banner, Sidebar, In-feed, Footer banner). **Ads are strictly prohibited next to or disguised as download buttons.**

---

## 🚀 Getting Started

### 1. Prerequisites
- **Node.js** v18+ (tested on Node v24)
- **npm** v9+

### 2. Environment Configuration
Verify or copy the environment variables in `.env`:
```env
VITE_FIREBASE_API_KEY="AIzaSy..."
VITE_FIREBASE_AUTH_DOMAIN="phich-mc.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="phich-mc"
VITE_FIREBASE_STORAGE_BUCKET="phich-mc.firebasestorage.app"
VITE_FIREBASE_MESSAGING_SENDER_ID="214959648677"
VITE_FIREBASE_APP_ID="1:214959648677:web:8abdf302fb322a3161c572"
VITE_FIREBASE_MEASUREMENT_ID="G-F8F09K323Z"
```

### 3. Install & Run Dev Server
```bash
# Install frontend dependencies
npm install

# Start Vite dev server
npm run dev
```
Open [http://localhost:5173](http://localhost:5173) in your browser.

### 4. Build for Production
```bash
npm run build
```

---

## 🛡️ Security & Role-Based Access Control

The platform enforces 5 user roles:
1. **User (Consumer):** Browse, search, filter, download, rate, comment, bookmark, create collections, report resources.
2. **Creator:** Create, update, submit resources for review, manage version releases, view download analytics.
3. **Verified Creator:** Blue verified checkmark, priority moderation queue, elevated daily upload limits.
4. **Moderator:** Review submitted resources, approve/reject with feedback notes, handle user reports.
5. **Admin:** Full system control, role assignment, Adsterra placement manager, taxonomy manager (game versions, categories, loaders), system settings, audit logs.

### Bootstrapping Admin Access
A secure Cloud Function `bootstrapAdmin` is included in `functions/src/index.ts`.
To assign the initial admin role:
1. Register an account with your desired admin email in the UI.
2. Call `bootstrapAdmin({ secretKey: "..." })` or promote the user directly via the Firebase Admin SDK / Firestore console by setting `role: "admin"` in the `users` document.

---

## 📁 Project Structure

```
PHICHMC/
├── public/                 # Static assets (favicons, manifest, robots.txt, logo)
├── src/
│   ├── components/         # Reusable UI components
│   │   ├── admin/          # Admin management modals and tables
│   │   ├── ads/            # Safe AdSlot & Adsterra script integration
│   │   ├── common/         # Buttons, Badges, Modals, Markdown, Skeletons
│   │   ├── creator/        # Project editors, version uploaders
│   │   ├── discovery/      # Search bar, filters, resource cards
│   │   ├── layout/         # Header, Footer, AdminLayout, MainLayout
│   │   └── project/        # Details, tabs, download drawer, comments
│   ├── contexts/           # AuthContext, ThemeContext, SiteConfigContext
│   ├── firebase/           # Firebase initialization & auto-seeding demo data
│   ├── pages/              # Public, Auth, Creator, User, and Admin views
│   ├── services/           # Firebase services (projects, downloads, admin, community)
│   ├── types/              # Complete TypeScript interfaces
│   └── index.css           # Modern dark-first Tailwind design system
├── functions/              # Cloud Functions (TypeScript backend)
├── firestore.rules         # Hardened Firestore security rules
├── storage.rules           # Storage security rules (MIME/extension whitelist)
├── firestore.indexes.json  # Multi-field query indexes
└── firebase.json           # Firebase CLI deploy configuration
```

---

## 📄 License & Attribution
- Built for the Minecraft creator community.
- Minecraft is a trademark of Mojang Synergies AB. PHICHMC is an independent community platform.

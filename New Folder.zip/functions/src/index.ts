import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

admin.initializeApp();
const db = admin.firestore();

/**
 * 1. Secure First Admin Bootstrap
 */
export const bootstrapAdmin = functions.https.onCall(async (_data: any, context: functions.https.CallableContext) => {
  // Check if any admin exists
  const adminsSnap = await db.collection('users').where('role', '==', 'admin').limit(1).get();
  if (!adminsSnap.empty) {
    throw new functions.https.HttpsError(
      'failed-precondition',
      'An administrator already exists. Further admins must be granted via the Admin Console.'
    );
  }

  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be signed in.');
  }

  const targetUid = context.auth.uid;
  await admin.auth().setCustomUserClaims(targetUid, { admin: true, role: 'admin' });
  await db.collection('users').doc(targetUid).set(
    { role: 'admin', isCreator: true, isVerified: true },
    { merge: true }
  );

  return { success: true, message: `User ${targetUid} bootstrapped as Super Admin.` };
});

/**
 * 2. Set User Role (Admin only)
 */
export const setUserRole = functions.https.onCall(async (data: { targetUid?: string; newRole?: string }, context: functions.https.CallableContext) => {
  if (!context.auth || context.auth.token.admin !== true) {
    throw new functions.https.HttpsError('permission-denied', 'Only administrators can change roles.');
  }

  const { targetUid, newRole } = data;
  if (!targetUid || !newRole || !['user', 'creator', 'admin'].includes(newRole)) {
    throw new functions.https.HttpsError('invalid-argument', 'Invalid user or role.');
  }

  const claims: Record<string, any> = {
    role: newRole,
    admin: newRole === 'admin',
    creator: newRole === 'creator' || newRole === 'admin',
  };

  await admin.auth().setCustomUserClaims(targetUid, claims);
  await db.collection('users').doc(targetUid).update({
    role: newRole,
    isCreator: claims.creator,
  });

  // Write audit log
  await db.collection('auditLogs').add({
    adminId: context.auth.uid,
    action: `SET_USER_ROLE_${newRole.toUpperCase()}`,
    targetType: 'user',
    targetId: targetUid,
    timestamp: new Date().toISOString(),
  });

  return { success: true };
});

/**
 * 3. Moderate Project (Admin only)
 */
export const moderateProject = functions.https.onCall(async (data: { projectId?: string; newStatus?: string; reason?: string; privateNote?: string }, context: functions.https.CallableContext) => {
  if (!context.auth || context.auth.token.admin !== true) {
    throw new functions.https.HttpsError('permission-denied', 'Admin access required.');
  }

  const { projectId, newStatus, reason, privateNote } = data;
  if (!projectId || !newStatus) {
    throw new functions.https.HttpsError('invalid-argument', 'Missing parameters.');
  }

  const projectRef = db.collection('projects').doc(projectId);
  const updateData: Record<string, any> = {
    status: newStatus,
    'moderation.status': newStatus,
    'moderation.reason': reason || null,
    'moderation.privateNote': privateNote || null,
    'moderation.reviewedBy': context.auth.uid,
    'moderation.reviewedAt': new Date().toISOString(),
  };

  if (newStatus === 'approved') {
    updateData.publishedAt = new Date().toISOString();
  }

  await projectRef.update(updateData);

  // Notify creator
  const projSnap = await projectRef.get();
  if (projSnap.exists) {
    const creatorId = projSnap.data()?.creatorId;
    if (creatorId) {
      await db.collection('notifications').add({
        userId: creatorId,
        type: newStatus === 'approved' ? 'project_approved' : 'project_rejected',
        title: newStatus === 'approved' ? 'Project Approved!' : 'Project Requires Changes',
        body:
          newStatus === 'approved'
            ? `Your project "${projSnap.data()?.title}" has been approved and is now live!`
            : `Your project "${projSnap.data()?.title}" was reviewed: ${reason || 'See moderation note.'}`,
        link: `/project/${projSnap.data()?.slug}`,
        read: false,
        createdAt: new Date().toISOString(),
      });
    }
  }

  // Audit log
  await db.collection('auditLogs').add({
    adminId: context.auth.uid,
    action: `MODERATE_PROJECT_${newStatus.toUpperCase()}`,
    targetType: 'project',
    targetId: projectId,
    timestamp: new Date().toISOString(),
    details: reason || undefined,
  });

  return { success: true };
});

/**
 * 4. Request Download & Increment Counters Transactionally
 */
export const requestDownload = functions.https.onCall(async (data: { projectId?: string; versionId?: string; fileId?: string; sessionKey?: string }, _context: functions.https.CallableContext) => {
  const { projectId, versionId, fileId } = data;
  if (!projectId || !versionId || !fileId) {
    throw new functions.https.HttpsError('invalid-argument', 'Missing parameters.');
  }

  const projectRef = db.collection('projects').doc(projectId);
  const versionRef = db.collection('projects').doc(projectId).collection('versions').doc(versionId);

  await db.runTransaction(async (transaction: admin.firestore.Transaction) => {
    transaction.update(projectRef, {
      downloads: admin.firestore.FieldValue.increment(1),
      trendingScore: admin.firestore.FieldValue.increment(3),
    });
    transaction.update(versionRef, {
      downloadCount: admin.firestore.FieldValue.increment(1),
    });
  });

  return { success: true };
});

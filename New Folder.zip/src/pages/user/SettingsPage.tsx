import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/common/Toast';
import { Avatar } from '../../components/common/Avatar';
import { Settings, Save, Globe, MessageSquare, User, AtSign, MapPin } from 'lucide-react';
import { TwitterIcon, GithubIcon } from '../../components/common/SocialIcons';
import { useNavigate } from 'react-router-dom';

export const SettingsPage: React.FC = () => {
  const { user, profile, updateProfileData } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  if (!user || !profile) {
    navigate('/login');
    return null;
  }

  const [displayName, setDisplayName] = useState(profile.displayName || '');
  const [bio, setBio] = useState(profile.bio || '');
  const [country, setCountry] = useState(profile.country || '');
  const [website, setWebsite] = useState(profile.website || '');
  const [avatarUrl, setAvatarUrl] = useState(profile.avatarUrl || '');
  const [discord, setDiscord] = useState(profile.socialLinks?.discord || '');
  const [twitter, setTwitter] = useState(profile.socialLinks?.twitter || '');
  const [github, setGithub] = useState(profile.socialLinks?.github || '');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateProfileData({
        displayName: displayName.trim(),
        bio: bio.trim(),
        country: country.trim(),
        website: website.trim(),
        avatarUrl: avatarUrl.trim() || undefined,
        socialLinks: {
          discord: discord.trim(),
          twitter: twitter.trim(),
          github: github.trim(),
        },
      });
      showToast('Profile updated successfully!');
    } catch {
      showToast('Error saving settings.', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="pb-6 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
          <Settings className="text-primary-400" />
          <span>Account Settings</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Customize your public presence, bio, and social connections.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Avatar Section */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-sm font-heading font-semibold text-slate-200">Avatar & Identity</h3>
          <div className="flex flex-col sm:flex-row items-center gap-5">
            <Avatar src={avatarUrl} name={displayName || profile.username} size="xl" />
            <div className="flex-1 w-full space-y-2">
              <label className="block text-xs font-semibold text-slate-300">
                Avatar Image URL (HTTPS)
              </label>
              <input
                type="url"
                value={avatarUrl}
                onChange={(e) => setAvatarUrl(e.target.value)}
                placeholder="https://example.com/avatar.png"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-primary-500"
              />
              <p className="text-[11px] text-slate-500">
                Provide a square image link or Discord avatar URL.
              </p>
            </div>
          </div>
        </div>

        {/* Basic Info */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 text-xs">
          <h3 className="text-sm font-heading font-semibold text-slate-200">Profile Details</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Username (read-only)</label>
              <div className="relative">
                <AtSign size={14} className="absolute left-3.5 top-3 text-slate-500" />
                <input
                  type="text"
                  disabled
                  value={profile.username}
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-950/50 border border-slate-800 rounded-xl text-slate-500 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Display Name</label>
              <div className="relative">
                <User size={14} className="absolute left-3.5 top-3 text-slate-400" />
                <input
                  type="text"
                  required
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Short Bio</label>
            <textarea
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell other players about your Minecraft projects..."
              className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 placeholder-slate-500 focus:outline-none focus:border-primary-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Country / Region</label>
              <div className="relative">
                <MapPin size={14} className="absolute left-3.5 top-3 text-slate-400" />
                <input
                  type="text"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  placeholder="e.g. United States, Germany"
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Website URL</label>
              <div className="relative">
                <Globe size={14} className="absolute left-3.5 top-3 text-slate-400" />
                <input
                  type="url"
                  value={website}
                  onChange={(e) => setWebsite(e.target.value)}
                  placeholder="https://mywebsite.com"
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Social Links */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 text-xs">
          <h3 className="text-sm font-heading font-semibold text-slate-200">Social Connections</h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Discord Tag or Server</label>
              <div className="relative">
                <MessageSquare size={14} className="absolute left-3.5 top-3 text-slate-400" />
                <input
                  type="text"
                  value={discord}
                  onChange={(e) => setDiscord(e.target.value)}
                  placeholder="username or discord.gg/link"
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Twitter / X</label>
              <div className="relative">
                <TwitterIcon size={14} className="absolute left-3.5 top-3 text-slate-400" />
                <input
                  type="text"
                  value={twitter}
                  onChange={(e) => setTwitter(e.target.value)}
                  placeholder="@handle"
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">GitHub</label>
              <div className="relative">
                <GithubIcon size={14} className="absolute left-3.5 top-3 text-slate-400" />
                <input
                  type="text"
                  value={github}
                  onChange={(e) => setGithub(e.target.value)}
                  placeholder="username"
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 px-6 py-3 bg-primary-600 hover:bg-primary-500 disabled:opacity-50 text-white font-semibold text-xs rounded-xl transition-all shadow-md"
          >
            <Save size={15} />
            <span>{saving ? 'Saving Changes...' : 'Save Settings'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};

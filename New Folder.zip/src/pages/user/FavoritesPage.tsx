import React, { useEffect, useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { communityService } from '../../services/communityService';
import { ProjectItem } from '../../types';
import { ResourceCard } from '../../components/common/ResourceCard';
import { ResourceCardSkeleton } from '../../components/common/ResourceCardSkeleton';
import { EmptyState } from '../../components/common/EmptyState';
import { Heart, Compass } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const FavoritesPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [favorites, setFavorites] = useState<ProjectItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    const loadFavs = async () => {
      setLoading(true);
      const items = await communityService.getUserFavorites(user.uid);
      setFavorites(items);
      setLoading(false);
    };
    loadFavs();
  }, [user, navigate]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="pb-6 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
          <Heart className="text-rose-400 fill-rose-400" />
          <span>My Favorite Projects</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Quickly access your saved Minecraft mods, resource packs, and shaders.
        </p>
      </div>

      {loading ? (
        <div className="space-y-4">
          <ResourceCardSkeleton />
          <ResourceCardSkeleton />
        </div>
      ) : favorites.length === 0 ? (
        <EmptyState
          icon={<Heart size={28} className="text-rose-400" />}
          title="No favorites yet"
          description="Explore projects on PHICHMC and click the heart icon to save them to your library."
          actionText="Discover Resources"
          onAction={() => navigate('/discover')}
        />
      ) : (
        <div className="space-y-4">
          {favorites.map((p) => (
            <ResourceCard key={p.id} project={p} />
          ))}
        </div>
      )}
    </div>
  );
};

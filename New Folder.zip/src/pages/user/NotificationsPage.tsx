import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { notificationService } from '../../services/notificationService';
import { NotificationItem } from '../../types';
import { Bell, CheckCheck, ExternalLink } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { EmptyState } from '../../components/common/EmptyState';

export const NotificationsPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    const loadAll = async () => {
      setLoading(true);
      const items = await notificationService.getUserNotifications(user.uid, 50);
      setNotifications(items);
      setLoading(false);
    };
    loadAll();
  }, [user, navigate]);

  const handleMarkAllRead = async () => {
    if (!user) return;
    await notificationService.markAllAsRead(user.uid);
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleMarkRead = async (id: string) => {
    await notificationService.markAsRead(id);
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex items-center justify-between pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2.5">
            <Bell className="text-primary-400" />
            <span>Notifications</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Stay updated on new versions, comment replies, and moderation alerts.
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={handleMarkAllRead}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-primary-400 rounded-lg text-xs font-semibold border border-slate-700 transition-colors"
          >
            <CheckCheck size={14} />
            <span>Mark all as read</span>
          </button>
        )}
      </div>

      {notifications.length === 0 && !loading ? (
        <EmptyState
          icon={<Bell size={28} className="text-primary-400" />}
          title="No notifications"
          description="When your followed projects update or moderators approve your submissions, you'll see alerts here."
        />
      ) : (
        <div className="divide-y divide-slate-800/80 rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
          {notifications.map((item) => (
            <div
              key={item.id}
              onClick={() => handleMarkRead(item.id)}
              className={`p-4 sm:p-5 flex items-start justify-between gap-4 transition-colors ${
                !item.read ? 'bg-primary-950/20' : 'hover:bg-slate-850'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-heading font-semibold text-sm text-slate-100">{item.title}</h4>
                  {!item.read && (
                    <span className="w-2 h-2 rounded-full bg-primary-500 shrink-0" />
                  )}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{item.body}</p>
                <span className="text-[10px] text-slate-500 font-mono block pt-1">
                  {item.createdAt
                    ? formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })
                    : ''}
                </span>
              </div>

              {item.link && (
                <Link
                  to={item.link}
                  className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 shrink-0"
                  title="View Link"
                >
                  <ExternalLink size={16} />
                </Link>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

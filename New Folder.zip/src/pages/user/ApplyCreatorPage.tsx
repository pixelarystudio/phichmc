import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useSiteConfig } from '../../contexts/SiteConfigContext';
import { useToast } from '../../components/common/Toast';
import { setDoc, doc } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { Sparkles, CheckCircle2, ShieldCheck, ArrowRight } from 'lucide-react';
import confetti from 'canvas-confetti';

export const ApplyCreatorPage: React.FC = () => {
  const { user, profile, isCreator } = useAuth();
  const { settings } = useSiteConfig();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [reason, setReason] = useState('');
  const [experience, setExperience] = useState('');
  const [portfolio, setPortfolio] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!user) {
    return (
      <div className="max-w-md mx-auto py-20 px-4 text-center space-y-4">
        <h2 className="text-xl font-heading font-bold text-white">Sign In Required</h2>
        <p className="text-sm text-slate-400">Please sign in to apply for Creator status on PHICHMC.</p>
        <button
          onClick={() => navigate('/login')}
          className="px-5 py-2.5 bg-primary-600 rounded-xl text-xs font-semibold text-white"
        >
          Sign In
        </button>
      </div>
    );
  }

  if (isCreator) {
    return (
      <div className="max-w-xl mx-auto py-20 px-4 text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto">
          <CheckCircle2 size={32} />
        </div>
        <h2 className="text-2xl font-heading font-bold text-white">You're already a Creator!</h2>
        <p className="text-sm text-slate-400">
          Your account has full publishing rights to create Minecraft projects, upload versions, and view creator analytics.
        </p>
        <Link
          to="/dashboard"
          className="inline-flex items-center gap-2 px-6 py-2.5 bg-primary-600 rounded-xl text-xs font-semibold text-white"
        >
          <span>Go to Creator Dashboard</span>
          <ArrowRight size={14} />
        </Link>
      </div>
    );
  }

  if (!settings.allowCreatorApplications) {
    return (
      <div className="max-w-md mx-auto py-20 px-4 text-center space-y-4">
        <h2 className="text-xl font-heading font-bold text-white">Applications Paused</h2>
        <p className="text-sm text-slate-400">
          Creator applications are temporarily closed. Please check our announcements for updates.
        </p>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const appId = `app_${user.uid}`;
      await setDoc(doc(db, 'creatorApplications', appId), {
        id: appId,
        userId: user.uid,
        username: profile?.username || 'user',
        displayName: profile?.displayName || profile?.username || 'user',
        email: user.email || '',
        reason: reason.trim(),
        experience: experience.trim(),
        portfolio: portfolio.trim(),
        status: 'pending',
        createdAt: new Date().toISOString(),
      });

      confetti({ particleCount: 75, spread: 60 });
      setSubmitted(true);
      showToast('Creator application submitted for review!');
    } catch {
      showToast('Failed to submit application. Try again.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="max-w-md mx-auto py-20 px-4 text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-primary-500/10 text-primary-400 flex items-center justify-center mx-auto">
          <Sparkles size={32} />
        </div>
        <h2 className="text-2xl font-heading font-bold text-white">Application Received!</h2>
        <p className="text-sm text-slate-400 leading-relaxed">
          Our moderation team will review your portfolio and Minecraft experience within 24-48 hours. You will receive a notification once decided.
        </p>
        <Link to="/" className="inline-block px-5 py-2.5 bg-slate-800 rounded-xl text-xs font-semibold text-slate-200">
          Return to Discover
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-12 space-y-6">
      <div className="space-y-2 text-center pb-6 border-b border-slate-800">
        <div className="w-12 h-12 rounded-xl bg-primary-500/10 border border-primary-500/20 text-primary-400 flex items-center justify-center mx-auto">
          <Sparkles size={24} />
        </div>
        <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white">
          Apply for Creator Status
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
          Publish and maintain mods, shaders, resource packs, and add-ons on PHICHMC.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 text-xs">
        <div>
          <label className="block text-slate-300 font-semibold mb-1">
            Why do you want to publish on PHICHMC?
          </label>
          <textarea
            rows={3}
            required
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Tell us what resources you create and what you plan to share..."
            className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
          />
        </div>

        <div>
          <label className="block text-slate-300 font-semibold mb-1">
            Your Minecraft Modding / Resource Experience
          </label>
          <textarea
            rows={3}
            required
            value={experience}
            onChange={(e) => setExperience(e.target.value)}
            placeholder="e.g. 3 years building Fabric mods with Java, pixel art texturing in Aseprite, GLSL shader math..."
            className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
          />
        </div>

        <div>
          <label className="block text-slate-300 font-semibold mb-1">
            Portfolio / Previous Projects Links
          </label>
          <textarea
            rows={3}
            required
            value={portfolio}
            onChange={(e) => setPortfolio(e.target.value)}
            placeholder="Links to GitHub repos, YouTube showcases, Planet Minecraft, or other portfolios..."
            className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500 font-mono text-[11px]"
          />
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full py-3 bg-primary-600 hover:bg-primary-500 disabled:opacity-50 text-white font-semibold text-xs rounded-xl transition-all shadow-md"
        >
          {submitting ? 'Submitting Application...' : 'Submit Application'}
        </button>
      </form>
    </div>
  );
};

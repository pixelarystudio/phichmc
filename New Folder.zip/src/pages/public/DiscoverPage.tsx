import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SearchBar } from '../../components/common/SearchBar';
import { FilterPanel, FilterState } from '../../components/common/FilterPanel';
import { ResourceCard } from '../../components/common/ResourceCard';
import { ResourceCardSkeleton } from '../../components/common/ResourceCardSkeleton';
import { EmptyState } from '../../components/common/EmptyState';
import { AdSlot } from '../../components/common/AdSlot';
import { projectService } from '../../services/projectService';
import { ProjectItem } from '../../types';
import { SlidersHorizontal, ArrowUpDown, X } from 'lucide-react';
import { useSeo } from '../../hooks/useSeo';

export const DiscoverPage: React.FC = () => {
  useSeo({
    title: 'Discover Resources',
    description: 'Explore Minecraft mods, shaders, resource packs, datapacks, and maps on PHICHMC.',
  });

  const [searchParams, setSearchParams] = useSearchParams();

  // Read state from URL
  const initialSearch = searchParams.get('q') || '';
  const initialType = searchParams.get('type') || 'all';
  const initialEdition = searchParams.get('edition') || 'all';
  const initialVersion = searchParams.get('version') || 'all';
  const initialLoader = searchParams.get('loader') || 'all';
  const initialCategory = searchParams.get('category') || 'all';
  const initialEnvironment = searchParams.get('env') || 'all';
  const initialSort = (searchParams.get('sort') as any) || 'relevance';

  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [filters, setFilters] = useState<FilterState>({
    resourceType: initialType,
    edition: initialEdition,
    version: initialVersion,
    loader: initialLoader,
    category: initialCategory,
    environment: initialEnvironment,
  });
  const [sortOption, setSortOption] = useState<string>(initialSort);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Sync state to URL params
  useEffect(() => {
    const params: Record<string, string> = {};
    if (searchQuery.trim()) params.q = searchQuery.trim();
    if (filters.resourceType !== 'all') params.type = filters.resourceType;
    if (filters.edition !== 'all') params.edition = filters.edition;
    if (filters.version !== 'all') params.version = filters.version;
    if (filters.loader !== 'all') params.loader = filters.loader;
    if (filters.category !== 'all') params.category = filters.category;
    if (filters.environment !== 'all') params.env = filters.environment;
    if (sortOption !== 'relevance') params.sort = sortOption;

    setSearchParams(params, { replace: true });
  }, [searchQuery, filters, sortOption, setSearchParams]);

  // Fetch filtered projects
  useEffect(() => {
    let isCancelled = false;
    const fetchFiltered = async () => {
      setLoading(true);
      try {
        const results = await projectService.discoverProjects({
          searchQuery,
          resourceType: filters.resourceType,
          edition: filters.edition,
          version: filters.version,
          loader: filters.loader,
          category: filters.category,
          environment: filters.environment,
          sort: sortOption as any,
          limitCount: 50,
        });
        if (!isCancelled) {
          setProjects(results);
        }
      } catch (err) {
        console.error('Error fetching discovered projects:', err);
      } finally {
        if (!isCancelled) setLoading(false);
      }
    };

    fetchFiltered();
    return () => {
      isCancelled = true;
    };
  }, [searchQuery, filters, sortOption]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setFilters({
      resourceType: 'all',
      edition: 'all',
      version: 'all',
      loader: 'all',
      category: 'all',
      environment: 'all',
    });
    setSortOption('relevance');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Header: Title & Quick Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-slate-100">
            Discover Resources
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Browse and filter through community-tested Minecraft mods, add-ons, and shaders.
          </p>
        </div>

        <div className="w-full md:w-96">
          <SearchBar
            initialValue={searchQuery}
            onSearch={(q) => setSearchQuery(q)}
            placeholder="Search by title, tag, or creator..."
          />
        </div>
      </div>

      {/* Main Grid: Sidebar Filters + Card List */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Desktop Sidebar Filters */}
        <aside className="hidden lg:block lg:col-span-1 space-y-4">
          <FilterPanel
            filters={filters}
            onChange={setFilters}
            onReset={handleResetFilters}
          />
        </aside>

        {/* Mobile Filter Trigger */}
        <div className="lg:hidden flex items-center justify-between gap-3">
          <button
            onClick={() => setMobileFilterOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs font-semibold text-slate-200"
          >
            <SlidersHorizontal size={14} className="text-primary-400" />
            <span>Filter Resources</span>
          </button>

          {/* Sort Selector */}
          <div className="flex items-center gap-2">
            <ArrowUpDown size={14} className="text-slate-400" />
            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value)}
              className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-primary-500"
            >
              <option value="relevance">Relevance</option>
              <option value="downloads">Most Downloads</option>
              <option value="followers">Most Followed</option>
              <option value="trending">Trending</option>
              <option value="updated">Recently Updated</option>
              <option value="published">Recently Published</option>
            </select>
          </div>
        </div>

        {/* Results Area */}
        <section className="lg:col-span-3 space-y-4">
          {/* Desktop Toolbar: Result Count & Sort Selector */}
          <div className="hidden lg:flex items-center justify-between pb-2 text-xs text-slate-400">
            <span>
              Showing <strong className="text-slate-200">{projects.length}</strong> resources
            </span>

            <div className="flex items-center gap-2">
              <span className="text-slate-400">Sort by:</span>
              <select
                value={sortOption}
                onChange={(e) => setSortOption(e.target.value)}
                className="bg-slate-900 border border-slate-700/80 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-primary-500"
              >
                <option value="relevance">Relevance</option>
                <option value="downloads">Total Downloads</option>
                <option value="followers">Followers</option>
                <option value="trending">Trending</option>
                <option value="updated">Recently Updated</option>
                <option value="published">Recently Published</option>
              </select>
            </div>
          </div>

          {/* Cards List */}
          {loading ? (
            <div className="space-y-4">
              <ResourceCardSkeleton />
              <ResourceCardSkeleton />
              <ResourceCardSkeleton />
            </div>
          ) : projects.length === 0 ? (
            <EmptyState
              title="No resources found"
              description="Try adjusting your keywords, changing the Minecraft version, or resetting your filter criteria."
              actionText="Reset All Filters"
              onAction={handleResetFilters}
            />
          ) : (
            <div className="space-y-4">
              {projects.map((project, index) => (
                <React.Fragment key={project.id}>
                  <ResourceCard project={project} />
                  {/* Insert Ad between card results if index == 2 */}
                  {index === 2 && <AdSlot placement="between_cards" />}
                </React.Fragment>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Mobile Filters Drawer / Modal */}
      {mobileFilterOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex flex-col justify-end bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border-t border-slate-800 rounded-t-3xl max-h-[85vh] overflow-y-auto p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="font-heading font-bold text-sm text-slate-100">Filter Resources</span>
              <button
                onClick={() => setMobileFilterOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>
            <FilterPanel
              filters={filters}
              onChange={setFilters}
              onReset={handleResetFilters}
            />
            <button
              onClick={() => setMobileFilterOpen(false)}
              className="w-full py-3 bg-primary-600 hover:bg-primary-500 text-white font-semibold text-xs rounded-xl"
            >
              Apply Filters ({projects.length} results)
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

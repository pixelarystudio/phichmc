import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Compass,
  PlusCircle,
  TrendingUp,
  Sparkles,
  Clock,
  Layers,
  ArrowRight,
  ShieldCheck,
  Zap,
  Users,
} from 'lucide-react';
import { SearchBar } from '../../components/common/SearchBar';
import { ResourceCard } from '../../components/common/ResourceCard';
import { CreatorCard } from '../../components/common/CreatorCard';
import { ResourceCardSkeleton } from '../../components/common/ResourceCardSkeleton';
import { AdSlot } from '../../components/common/AdSlot';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { useSiteConfig } from '../../contexts/SiteConfigContext';
import { projectService } from '../../services/projectService';
import { ProjectItem, UserProfile } from '../../types';

export const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const { resourceTypes, categories } = useSiteConfig();

  const [loading, setLoading] = useState(true);
  const [featuredProjects, setFeaturedProjects] = useState<ProjectItem[]>([]);
  const [trendingProjects, setTrendingProjects] = useState<ProjectItem[]>([]);
  const [latestProjects, setLatestProjects] = useState<ProjectItem[]>([]);
  const [creators, setCreators] = useState<UserProfile[]>([]);

  useEffect(() => {
    const loadHomeData = async () => {
      setLoading(true);
      try {
        const [all, creatorSnap] = await Promise.all([
          projectService.discoverProjects({ limitCount: 20 }),
          getDocs(query(collection(db, 'users'), where('isCreator', '==', true), limit(6))),
        ]);

        setFeaturedProjects(all.filter((p) => p.featured).slice(0, 4));
        setTrendingProjects([...all].sort((a, b) => b.trendingScore - a.trendingScore).slice(0, 4));
        setLatestProjects(
          [...all]
            .sort(
              (a, b) =>
                new Date(b.publishedAt || b.createdAt).getTime() -
                new Date(a.publishedAt || a.createdAt).getTime()
            )
            .slice(0, 4)
        );

        if (!creatorSnap.empty) {
          setCreators(creatorSnap.docs.map((d) => d.data() as UserProfile));
        } else {
          setCreators([]);
        }
      } catch (err) {
        console.error('Error loading homepage data:', err);
      } finally {
        setLoading(false);
      }
    };
    loadHomeData();
  }, []);

  return (
    <div className="space-y-16 py-6 sm:py-10">
      {/* 1. Hero Section */}
      <section className="relative px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="relative rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900/90 to-background border border-slate-800/90 p-8 sm:p-14 lg:p-16 overflow-hidden bg-mc-grid">
          {/* Ambient Glow */}
          <div className="absolute top-0 right-1/4 w-96 h-96 bg-primary-600/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-secondary-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-3xl mx-auto text-center space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary-500/10 border border-primary-500/20 text-primary-400 text-xs font-medium">
              <Sparkles size={14} />
              <span>The Next Generation Minecraft Resource Platform</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-heading font-extrabold tracking-tight text-white leading-tight">
              Discover Minecraft Resources.
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
              Explore mods, add-ons, resource packs, shaders, maps, and more — all in one modern,
              community-driven platform.
            </p>

            {/* Search Bar */}
            <div className="pt-2 max-w-xl mx-auto">
              <SearchBar placeholder="Search mods, shaders, resource packs..." />
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap items-center justify-center gap-4 pt-3">
              <Link
                to="/discover"
                className="flex items-center gap-2 px-6 py-3 rounded-xl bg-primary-600 hover:bg-primary-500 text-white font-heading font-semibold text-sm shadow-lg shadow-primary-600/25 transition-all hover:scale-102"
              >
                <Compass size={18} />
                <span>Explore Resources</span>
              </Link>
              <Link
                to="/dashboard/projects/new"
                className="flex items-center gap-2 px-6 py-3 rounded-xl bg-slate-800/90 hover:bg-slate-800 text-slate-200 border border-slate-700/80 font-heading font-semibold text-sm transition-all hover:scale-102"
              >
                <PlusCircle size={18} />
                <span>Create a Project</span>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Ad Placement: Homepage Top */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AdSlot placement="homepage" />
      </div>

      {/* 2. Popular Resource Categories Bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2 font-heading font-bold text-lg sm:text-xl text-slate-100">
            <Layers className="text-primary-400" size={20} />
            <span>Popular Resource Types</span>
          </div>
          <Link
            to="/discover"
            className="flex items-center gap-1 text-xs sm:text-sm text-primary-400 hover:text-primary-300 font-medium"
          >
            <span>All Types</span>
            <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {resourceTypes.map((type) => (
            <Link
              key={type.id}
              to={`/discover?type=${type.slug}`}
              className="flex flex-col items-center justify-center p-4 rounded-xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-primary-500/40 card-hover-glow transition-all text-center"
            >
              <span className="font-heading font-semibold text-xs sm:text-sm text-slate-200 group-hover:text-primary-400">
                {type.name}
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* 3. Featured Resources (Curated by Admin) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center gap-2 font-heading font-bold text-lg sm:text-xl text-slate-100">
              <Sparkles className="text-amber-400" size={20} />
              <span>Featured Resources</span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">Handpicked quality projects from the community</p>
          </div>
          <Link
            to="/discover?sort=trending"
            className="flex items-center gap-1 text-xs sm:text-sm text-primary-400 hover:text-primary-300 font-medium"
          >
            <span>View More</span>
            <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {loading ? (
            <>
              <ResourceCardSkeleton />
              <ResourceCardSkeleton />
            </>
          ) : featuredProjects.length > 0 ? (
            featuredProjects.map((project) => (
              <ResourceCard key={project.id} project={project} />
            ))
          ) : (
            <div className="md:col-span-2 p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-3">
              <p className="text-sm text-slate-400">No featured projects yet.</p>
              <Link
                to="/dashboard/projects/new"
                className="inline-flex items-center gap-2 px-4 py-2 bg-primary-600 hover:bg-primary-500 text-white text-xs font-semibold rounded-xl transition-colors"
              >
                <PlusCircle size={14} />
                <span>Publish a Minecraft Resource</span>
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* 4. Trending Resources */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center gap-2 font-heading font-bold text-lg sm:text-xl text-slate-100">
              <TrendingUp className="text-emerald-400" size={20} />
              <span>Trending Now</span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">Most active resources over the past week</p>
          </div>
          <Link
            to="/discover?sort=downloads"
            className="flex items-center gap-1 text-xs sm:text-sm text-primary-400 hover:text-primary-300 font-medium"
          >
            <span>See Top Downloads</span>
            <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {loading ? (
            <>
              <ResourceCardSkeleton />
              <ResourceCardSkeleton />
            </>
          ) : trendingProjects.length > 0 ? (
            trendingProjects.map((project) => (
              <ResourceCard key={project.id} project={project} />
            ))
          ) : (
            <div className="md:col-span-2 p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
              <p className="text-sm text-slate-400">New mods, resource packs, and shaders will appear here once published.</p>
            </div>
          )}
        </div>
      </section>

      {/* 5. Featured Creators (Only if creators exist) */}
      {creators.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 font-heading font-bold text-lg sm:text-xl text-slate-100">
                <Users className="text-secondary-400" size={20} />
                <span>Featured Creators</span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">Talented authors creating for Minecraft</p>
            </div>
            <Link
              to="/creators"
              className="flex items-center gap-1 text-xs sm:text-sm text-primary-400 hover:text-primary-300 font-medium"
            >
              <span>All Creators</span>
              <ArrowRight size={14} />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {creators.map((creator) => (
              <CreatorCard key={creator.uid} creator={creator} />
            ))}
          </div>
        </section>
      )}

      {/* 6. Community Call-To-Action Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl bg-gradient-to-r from-primary-950 via-slate-900 to-secondary-950 border border-slate-800 p-8 sm:p-12 overflow-hidden flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-3 text-center md:text-left">
            <h3 className="text-2xl sm:text-3xl font-heading font-bold text-white">
              Create. Share. Build the Minecraft Community.
            </h3>
            <p className="text-slate-300 text-sm max-w-xl leading-relaxed">
              Got a mod, texture pack, shader, or add-on? Join PHICHMC today to share your creations
              with thousands of Minecraft players worldwide with full versioning and analytics.
            </p>
          </div>
          <Link
            to="/apply-creator"
            className="shrink-0 px-6 py-3 rounded-xl bg-white text-slate-950 hover:bg-slate-100 font-heading font-semibold text-sm transition-all hover:scale-105 shadow-xl"
          >
            Join as a Creator
          </Link>
        </div>
      </section>
    </div>
  );
};

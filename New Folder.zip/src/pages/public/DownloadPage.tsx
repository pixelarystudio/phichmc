import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Download, CheckCircle, ArrowLeft, ShieldCheck, FileCode, HardDrive } from 'lucide-react';
import { downloadService, DownloadDetails } from '../../services/downloadService';
import { AdSlot } from '../../components/common/AdSlot';
import { Badge } from '../../components/common/Badge';

export const DownloadPage: React.FC = () => {
  const { projectSlug, versionId } = useParams<{ projectSlug: string; versionId: string }>();
  const [details, setDetails] = useState<DownloadDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [downloadStarted, setDownloadStarted] = useState(false);

  useEffect(() => {
    if (!projectSlug || !versionId) return;

    const initDownload = async () => {
      setLoading(true);
      const res = await downloadService.getDownloadDetails(projectSlug, versionId);
      setDetails(res);
      setLoading(false);

      if (res && res.file) {
        // Record download metric
        await downloadService.recordDownload(res.project.id, res.version.id, res.file.fileId);

        // Auto trigger download after brief half-second pause
        const timer = setTimeout(() => {
          downloadService.triggerFileDownload(res.file);
          setDownloadStarted(true);
        }, 600);

        return () => clearTimeout(timer);
      }
    };

    initDownload();
  }, [projectSlug, versionId]);

  if (loading) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-4">
        <div className="w-12 h-12 rounded-full border-4 border-primary-500/20 border-t-primary-500 animate-spin mx-auto" />
        <p className="text-sm text-slate-400">Verifying file integrity and preparing download...</p>
      </div>
    );
  }

  if (!details) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-xl font-heading font-bold text-slate-100">Download Not Found</h2>
        <p className="text-sm text-slate-400">
          The requested version or file could not be located.
        </p>
        <Link to="/discover" className="inline-block px-4 py-2 bg-primary-600 rounded-lg text-xs font-semibold text-white">
          Back to Discover
        </Link>
      </div>
    );
  }

  const { project, version, file } = details;
  const fileSizeMb = (file.fileSize / (1024 * 1024)).toFixed(2);

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      {/* Return link */}
      <div>
        <Link
          to={`/project/${project.slug}`}
          className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors"
        >
          <ArrowLeft size={14} />
          <span>Back to {project.title}</span>
        </Link>
      </div>

      {/* Main Download Status Card */}
      <div className="p-8 sm:p-10 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-2xl text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto shadow-inner">
          <CheckCircle size={32} className="animate-pulse" />
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white">
            Your Download Has Started!
          </h1>
          <p className="text-sm text-slate-300">
            Downloading <strong className="text-primary-400">{file.fileName}</strong> for Minecraft.
          </p>
        </div>

        {/* File Specifications Panel */}
        <div className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800/80 text-left max-w-lg mx-auto space-y-3 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-slate-400">Project</span>
            <span className="font-semibold text-slate-100">{project.title}</span>
          </div>

          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-slate-400">Version</span>
            <span className="font-mono text-slate-200">{version.versionNumber} ({version.releaseType})</span>
          </div>

          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-slate-400">File Size</span>
            <span className="font-mono text-slate-200">{fileSizeMb} MB</span>
          </div>

          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-slate-400">Compatibility</span>
            <span className="font-mono text-slate-200">
              {version.minecraftVersions.join(', ')} ({version.loaders.join(', ')})
            </span>
          </div>

          {file.sha256 && (
            <div className="pt-1">
              <span className="text-slate-400 block mb-1">SHA-256 Hash</span>
              <span className="font-mono text-[10px] text-slate-400 bg-slate-900 px-2 py-1 rounded block break-all">
                {file.sha256}
              </span>
            </div>
          )}
        </div>

        {/* Manual Download Button */}
        <div className="pt-2 space-y-2">
          <p className="text-xs text-slate-400">
            Didn't download automatically?
          </p>
          <button
            onClick={() => downloadService.triggerFileDownload(file)}
            className="inline-flex items-center gap-2 px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors shadow"
          >
            <Download size={15} />
            <span>Click here to download manually</span>
          </button>
        </div>
      </div>

      {/* Ad Placement on Download Page */}
      <AdSlot placement="download" />
    </div>
  );
};

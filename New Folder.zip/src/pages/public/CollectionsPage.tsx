import React, { useEffect, useState } from 'react';
import { CollectionItem } from '../../types';
import { communityService } from '../../services/communityService';
import { CollectionCard } from '../../components/common/CollectionCard';
import { FolderHeart } from 'lucide-react';

export const CollectionsPage: React.FC = () => {
  const [collections, setCollections] = useState<CollectionItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const items = await communityService.getPublicCollections();
      setCollections(items);
      setLoading(false);
    };
    load();
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="pb-6 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
          <FolderHeart className="text-secondary-400" />
          <span>Curated Collections</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Explore custom bundles, survival packs, and community-recommended sets of Minecraft resources.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {collections.length === 0 && !loading ? (
          <div className="col-span-3 p-12 text-center text-slate-400 text-sm">
            No public collections available yet.
          </div>
        ) : (
          collections.map((col) => <CollectionCard key={col.id} collection={col} />)
        )}
      </div>
    </div>
  );
};

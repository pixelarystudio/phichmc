import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { communityService } from '../../services/communityService';
import { useToast } from '../../components/common/Toast';
import { Flag, ShieldAlert } from 'lucide-react';

export const ReportPage: React.FC = () => {
  const { user, profile } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [targetType, setTargetType] = useState<'project' | 'user' | 'comment'>('project');
  const [targetId, setTargetId] = useState('');
  const [reason, setReason] = useState('copyright');
  const [details, setDetails] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      navigate('/login');
      return;
    }

    setSubmitting(true);
    try {
      await communityService.submitReport({
        id: `rep_${Date.now()}`,
        targetType,
        targetId: targetId.trim(),
        reporterId: user.uid,
        reporterUsername: profile?.username || 'anonymous',
        reason: reason as any,
        details: details.trim(),
        status: 'pending',
        createdAt: new Date().toISOString(),
      });
      showToast('Thank you. Your report has been submitted to moderators.');
      navigate('/');
    } catch {
      showToast('Error submitting report. Please try again.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-12 space-y-6">
      <div className="flex items-center gap-3 pb-6 border-b border-slate-800">
        <div className="w-12 h-12 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-center">
          <Flag size={24} />
        </div>
        <div>
          <h1 className="text-2xl font-heading font-extrabold text-white">Report Content or Abuse</h1>
          <p className="text-xs text-slate-400">
            Submit a formal complaint or security flag to our moderation team.
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 text-xs">
        <div>
          <label className="block text-slate-300 font-semibold mb-1">What are you reporting?</label>
          <select
            value={targetType}
            onChange={(e) => setTargetType(e.target.value as any)}
            className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
          >
            <option value="project">Minecraft Project / Resource</option>
            <option value="user">User / Creator Account</option>
            <option value="comment">Inappropriate Comment</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-300 font-semibold mb-1">Project Name, URL, or Username</label>
          <input
            type="text"
            required
            value={targetId}
            onChange={(e) => setTargetId(e.target.value)}
            placeholder="e.g. project slug or username"
            className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
          />
        </div>

        <div>
          <label className="block text-slate-300 font-semibold mb-1">Reason for Complaint</label>
          <select
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
          >
            <option value="copyright">Copyright Infringement / DMCA</option>
            <option value="malware">Malware / Malicious Code</option>
            <option value="scam">Scam / Phishing</option>
            <option value="nsfw">NSFW / Inappropriate Content</option>
            <option value="misleading">Misleading Content</option>
            <option value="reupload">Unauthorized Reupload</option>
            <option value="harassment">Harassment or Hate Speech</option>
            <option value="spam">Spam</option>
            <option value="other">Other</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-300 font-semibold mb-1">Details & Evidence</label>
          <textarea
            rows={4}
            required
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            placeholder="Please detail why this content violates community guidelines..."
            className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
          />
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full py-3 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white font-semibold rounded-xl text-xs transition-colors shadow-md"
        >
          {submitting ? 'Submitting Report...' : 'Submit Report for Moderation'}
        </button>
      </form>
    </div>
  );
};

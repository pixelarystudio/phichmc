import React from 'react';
import { Link } from 'react-router-dom';
import { Compass, Home, Box } from 'lucide-react';
import { useSeo } from '../../hooks/useSeo';

export const NotFoundPage: React.FC = () => {
  useSeo({
    title: '404 Not Found',
    description: 'The requested Minecraft resource or page could not be found.',
  });

  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center space-y-4">
      <div className="w-20 h-20 rounded-3xl bg-slate-900 border border-slate-800 text-primary-400 flex items-center justify-center mx-auto shadow-inner">
        <Box size={40} />
      </div>
      <h1 className="text-4xl sm:text-5xl font-heading font-extrabold text-white">404</h1>
      <h2 className="text-lg font-heading font-semibold text-slate-200">Chunk Not Generated (Page Not Found)</h2>
      <p className="text-sm text-slate-400 max-w-md leading-relaxed">
        The resource or page you are looking for does not exist in this realm or may have been relocated.
      </p>
      <div className="flex items-center gap-3 pt-4">
        <Link
          to="/"
          className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-xs font-semibold shadow-md"
        >
          <Home size={15} />
          <span>Return Home</span>
        </Link>
        <Link
          to="/discover"
          className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700"
        >
          <Compass size={15} />
          <span>Discover Resources</span>
        </Link>
      </div>
    </div>
  );
};

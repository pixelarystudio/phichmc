import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  Download,
  Heart,
  Users,
  Share2,
  Flag,
  ExternalLink,
  MessageSquare,
  HelpCircle,
  FileCode,
  ShieldCheck,
  Check,
  Copy,
  Clock,
  Box,
  Image as ImageIcon,
  BookOpen,
  Trash2,
} from 'lucide-react';
import { GithubIcon } from '../../components/common/SocialIcons';
import { projectService } from '../../services/projectService';
import { adminService } from '../../services/adminService';
import { communityService } from '../../services/communityService';
import { useAuth } from '../../contexts/AuthContext';
import { ProjectItem, ProjectVersion, ProjectComment } from '../../types';
import { Badge } from '../../components/common/Badge';
import { VerifiedBadge } from '../../components/common/VerifiedBadge';
import { VersionCard } from '../../components/common/VersionCard';
import { MarkdownRenderer } from '../../components/common/MarkdownRenderer';
import { Avatar } from '../../components/common/Avatar';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { AdSlot } from '../../components/common/AdSlot';
import { useToast } from '../../components/common/Toast';
import { formatCount } from '../../components/common/ResourceCard';
import { formatDistanceToNow } from 'date-fns';
import { getSafeUrl } from '../../utils/security';
import { useSeo } from '../../hooks/useSeo';

export const ProjectDetailPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { user, profile, isAdmin } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [project, setProject] = useState<ProjectItem | null>(null);

  useSeo({
    title: project ? project.title : 'Loading Project...',
    description: project?.shortDescription,
    image: project?.iconUrl,
  });
  const [versions, setVersions] = useState<ProjectVersion[]>([]);
  const [comments, setComments] = useState<ProjectComment[]>([]);
  const [loading, setLoading] = useState(true);

  // Interactive states
  const [activeTab, setActiveTab] = useState<
    'overview' | 'versions' | 'gallery' | 'changelog' | 'dependencies' | 'comments'
  >('overview');

  const [isFollowing, setIsFollowing] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportReason, setReportReason] = useState('malware');
  const [reportDetails, setReportDetails] = useState('');

  // Comment input
  const [newComment, setNewComment] = useState('');
  const [postingComment, setPostingComment] = useState(false);

  // Gallery modal
  const [activeImage, setActiveImage] = useState<string | null>(null);

  // Admin delete modal
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);

  useEffect(() => {
    if (!slug) return;
    const loadProject = async () => {
      setLoading(true);
      try {
        const p = await projectService.getProjectBySlug(slug);
        setProject(p);
        if (p) {
          // Record view event
          projectService.recordProjectView(p.id);

          // Check if viewer is creator or admin
          const isCreatorOrAdmin = Boolean((user && user.uid === p.creatorId) || isAdmin);

          // Load versions (creators/admins can see all their versions, public sees approved)
          const vers = await projectService.getProjectVersions(p.id, !isCreatorOrAdmin);
          setVersions(vers);

          // Load comments
          const cmts = await communityService.getProjectComments(p.id);
          setComments(cmts);

          // Check user status
          if (user) {
            const [following, favorited] = await Promise.all([
              communityService.isFollowingProject(p.id, user.uid),
              communityService.isProjectFavorited(p.id, user.uid),
            ]);
            setIsFollowing(following);
            setIsFavorited(favorited);
          }
        }
      } catch (err) {
        console.error('Error loading project page:', err);
      } finally {
        setLoading(false);
      }
    };
    loadProject();
  }, [slug, user]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 animate-pulse space-y-6">
        <div className="h-32 bg-slate-900 rounded-3xl" />
        <div className="h-96 bg-slate-900 rounded-3xl" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <div className="w-16 h-16 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mx-auto mb-4">
          <Box size={32} />
        </div>
        <h2 className="text-2xl font-heading font-bold text-slate-100 mb-2">Project Not Found</h2>
        <p className="text-sm text-slate-400 mb-6">
          The requested Minecraft project does not exist or may have been unlisted.
        </p>
        <Link
          to="/discover"
          className="px-5 py-2.5 bg-primary-600 hover:bg-primary-500 text-white text-xs font-semibold rounded-xl"
        >
          Discover Other Resources
        </Link>
      </div>
    );
  }

  const isOwner = user && user.uid === project.creatorId;
  const isApproved = project.status === 'approved';

  // Permission guard for drafts / unapproved projects
  if (!isApproved && !isOwner && !isAdmin) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <h2 className="text-xl font-heading font-bold text-amber-400 mb-2">Project Under Review</h2>
        <p className="text-sm text-slate-400 mb-6">
          This project has not yet been approved by the moderation team.
        </p>
        <Link
          to="/"
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg"
        >
          Return Home
        </Link>
      </div>
    );
  }

  const handleFollowToggle = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    const next = await communityService.toggleFollowProject(project.id, user.uid);
    setIsFollowing(next);
    setProject((prev) => (prev ? { ...prev, followers: prev.followers + (next ? 1 : -1) } : null));
    showToast(next ? 'Following project!' : 'Unfollowed project');
  };

  const handleFavoriteToggle = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    const next = await communityService.toggleFavorite(project.id, user.uid);
    setIsFavorited(next);
    setProject((prev) => (prev ? { ...prev, favorites: prev.favorites + (next ? 1 : -1) } : null));
    showToast(next ? 'Added to favorites!' : 'Removed from favorites');
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    showToast('Link copied to clipboard!');
    setShareModalOpen(false);
  };

  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      navigate('/login');
      return;
    }
    await communityService.submitReport({
      id: `rep_${Date.now()}`,
      targetType: 'project',
      targetId: project.id,
      targetName: project.title,
      reporterId: user.uid,
      reporterUsername: profile?.username || 'anonymous',
      reason: reportReason as any,
      details: reportDetails,
      status: 'pending',
      createdAt: new Date().toISOString(),
    });
    showToast('Report submitted for moderator review.');
    setReportModalOpen(false);
    setReportDetails('');
  };

  const handlePostComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) {
      navigate('/login');
      return;
    }
    if (!newComment.trim()) return;

    setPostingComment(true);
    const commentObj: ProjectComment = {
      id: `cmt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      projectId: project.id,
      authorId: user.uid,
      authorUsername: profile.username,
      authorDisplayName: profile.displayName || profile.username,
      authorAvatarUrl: profile.avatarUrl,
      authorIsCreator: user.uid === project.creatorId,
      authorIsAdmin: isAdmin,
      content: newComment.trim(),
      createdAt: new Date().toISOString(),
    };

    await communityService.postComment(commentObj);
    setComments([commentObj, ...comments]);
    setNewComment('');
    setPostingComment(false);
    showToast('Comment posted!');
  };

  const latestVersion = versions.find((v) => v.status === 'approved') || versions[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Moderation Warning Banner if not approved */}
      {!isApproved && (
        <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-800/80 text-amber-200 text-xs flex items-center justify-between">
          <div>
            <strong>Notice:</strong> This project is currently in status:{' '}
            <span className="font-mono uppercase font-bold">{project.status}</span>. Only the creator
            and administrators can view this page.
          </div>
          {isAdmin && (
            <div className="flex items-center gap-2">
              <Link
                to="/admin/moderation"
                className="px-3 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded font-medium"
              >
                Review in Moderation
              </Link>
              <button
                onClick={() => setDeleteConfirmOpen(true)}
                className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded font-medium flex items-center gap-1 transition-colors"
              >
                <Trash2 size={13} />
                <span>Delete Project</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Project Header Card */}
      <section className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800/90 shadow-xl flex flex-col md:flex-row gap-6 items-start justify-between">
        <div className="flex gap-5 items-start">
          {/* Icon */}
          <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-slate-800 border border-slate-700/80 overflow-hidden shrink-0 shadow-lg">
            {project.iconUrl ? (
              <img src={project.iconUrl} alt={project.title} className="w-full h-full object-cover" />
            ) : (
              <Box size={40} className="w-full h-full p-4 text-primary-400" />
            )}
          </div>

          {/* Title & Info */}
          <div className="min-w-0 flex-1 space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl sm:text-3xl font-heading font-extrabold text-white">
                {project.title}
              </h1>
              <Badge variant="primary" size="sm" className="uppercase font-mono text-[10px]">
                {project.resourceTypeId}
              </Badge>
              {project.verified && <VerifiedBadge type="project" showLabel />}
            </div>

            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              {project.shortDescription}
            </p>

            <div className="flex items-center gap-2 text-xs text-slate-400 pt-1">
              <span>Created by</span>
              <Link
                to={`/user/${project.creatorUsername}`}
                className="flex items-center gap-1.5 text-slate-200 font-semibold hover:text-primary-400 transition-colors"
              >
                <Avatar
                  src={project.creatorAvatarUrl}
                  name={project.creatorDisplayName || project.creatorUsername}
                  size="xs"
                />
                <span>{project.creatorDisplayName || project.creatorUsername}</span>
              </Link>
              {project.creatorVerified && <VerifiedBadge type="creator" size="sm" />}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full lg:w-auto flex flex-col gap-3 shrink-0 pt-4 lg:pt-0 border-t lg:border-t-0 border-slate-800/80">
          {latestVersion ? (
            <Link
              to={`/download/${project.slug}/${latestVersion.id}`}
              className="w-full lg:min-w-[260px] min-h-[48px] flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-primary-600 via-primary-500 to-emerald-500 hover:from-primary-500 hover:to-emerald-400 text-white font-heading font-bold text-sm shadow-xl shadow-primary-950/60 hover:shadow-primary-600/30 transition-all active:scale-[0.98] group"
            >
              <Download size={19} className="shrink-0 transition-transform group-hover:-translate-y-0.5" />
              <span className="whitespace-nowrap">Download Latest</span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-950/40 border border-white/20 font-mono text-white/95 whitespace-nowrap shadow-inner">
                v{latestVersion.versionNumber}
              </span>
            </Link>
          ) : (
            <button
              disabled
              className="w-full lg:min-w-[260px] min-h-[48px] px-6 py-3.5 rounded-2xl bg-slate-800 text-slate-500 text-xs font-semibold cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Download size={16} />
              <span>No versions published</span>
            </button>
          )}

          {/* Secondary Actions Row */}
          <div className="flex items-center gap-2 w-full">
            <button
              onClick={handleFollowToggle}
              className={`flex-1 min-h-[40px] flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
                isFollowing
                  ? 'bg-secondary-500/20 border-secondary-500/50 text-secondary-300'
                  : 'bg-slate-800/90 hover:bg-slate-800 border-slate-700/80 text-slate-300 hover:text-white'
              }`}
            >
              <Users size={14} className="shrink-0" />
              <span>{isFollowing ? 'Following' : 'Follow'}</span>
            </button>

            <button
              onClick={handleFavoriteToggle}
              className={`min-h-[40px] px-3 py-2 rounded-xl border transition-all flex items-center justify-center ${
                isFavorited
                  ? 'bg-rose-500/20 border-rose-500/50 text-rose-400'
                  : 'bg-slate-800/90 hover:bg-slate-800 border-slate-700/80 text-slate-400 hover:text-slate-200'
              }`}
              title={isFavorited ? 'Remove Favorite' : 'Add to Favorites'}
              aria-label="Favorite Project"
            >
              <Heart size={16} className={isFavorited ? 'fill-rose-400' : ''} />
            </button>

            <button
              onClick={() => setShareModalOpen(true)}
              className="min-h-[40px] px-3 py-2 rounded-xl bg-slate-800/90 hover:bg-slate-800 border border-slate-700/80 text-slate-400 hover:text-slate-200 transition-all flex items-center justify-center"
              title="Share Project"
              aria-label="Share Project"
            >
              <Share2 size={16} />
            </button>

            <button
              onClick={() => setReportModalOpen(true)}
              className="min-h-[40px] px-3 py-2 rounded-xl bg-slate-800/90 hover:bg-rose-950/40 border border-slate-700/80 hover:border-rose-900/60 text-slate-400 hover:text-rose-400 transition-all flex items-center justify-center"
              title="Report Project"
              aria-label="Report Project"
            >
              <Flag size={16} />
            </button>

            {isAdmin && (
              <button
                onClick={() => setDeleteConfirmOpen(true)}
                className="min-h-[40px] px-3 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-400 hover:text-rose-200 transition-all flex items-center justify-center"
                title="Admin: Delete Project Permanently"
                aria-label="Delete Project"
              >
                <Trash2 size={16} />
              </button>
            )}
          </div>

          {/* Quick Management Links for Creator / Admin */}
          {(isOwner || isAdmin) && (
            <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
              <Link
                to={`/dashboard/projects/${project.id}/edit`}
                className="flex-1 text-center py-2 px-3 text-xs font-semibold text-slate-300 hover:text-white bg-slate-950/80 hover:bg-slate-800 rounded-xl border border-slate-800 transition-colors"
              >
                Edit Project
              </Link>
              <Link
                to={`/dashboard/projects/${project.id}/versions`}
                className="flex-1 text-center py-2 px-3 text-xs font-semibold text-slate-300 hover:text-white bg-slate-950/80 hover:bg-slate-800 rounded-xl border border-slate-800 transition-colors"
              >
                Manage Versions
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-1 border-b border-slate-800 overflow-x-auto pb-1 text-sm font-medium">
        {[
          { key: 'overview', label: 'Overview' },
          { key: 'versions', label: `Versions (${versions.length})` },
          { key: 'gallery', label: `Gallery (${project.gallery?.length || 0})` },
          { key: 'changelog', label: 'Changelog' },
          { key: 'comments', label: `Comments (${comments.length})` },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as any)}
            className={`px-4 py-2.5 rounded-lg whitespace-nowrap transition-colors ${
              activeTab === tab.key
                ? 'text-primary-400 bg-primary-500/10 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content Columns: Tab Content (Left) + Sidebar Details (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Tab Content */}
        <div className="lg:col-span-2 space-y-6">
          {activeTab === 'overview' && (
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800/80">
              <MarkdownRenderer content={project.description} />
            </div>
          )}

          {activeTab === 'versions' && (
            <div className="space-y-3">
              {versions.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-sm">
                  No published versions available yet.
                </div>
              ) : (
                versions.map((ver) => (
                  <VersionCard key={ver.id} version={ver} project={project} />
                ))
              )}
            </div>
          )}

          {activeTab === 'gallery' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {(!project.gallery || project.gallery.length === 0) && (
                <div className="col-span-2 p-12 text-center text-slate-400 text-sm">
                  No gallery screenshots uploaded for this project.
                </div>
              )}
              {project.gallery?.map((imgUrl, i) => (
                <div
                  key={i}
                  onClick={() => setActiveImage(imgUrl)}
                  className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950 aspect-video cursor-pointer hover:border-primary-500/50 transition-colors"
                >
                  <img src={imgUrl} alt={`Screenshot ${i + 1}`} className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          )}

          {activeTab === 'changelog' && (
            <div className="space-y-4">
              {versions.map((ver) => (
                <div
                  key={ver.id}
                  className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-heading font-semibold text-sm text-slate-200">
                      Version {ver.versionNumber}
                    </span>
                    <span className="text-xs text-slate-500">
                      {ver.publishedAt
                        ? formatDistanceToNow(new Date(ver.publishedAt), { addSuffix: true })
                        : ''}
                    </span>
                  </div>
                  <div className="text-xs text-slate-300 whitespace-pre-wrap leading-relaxed">
                    {ver.changelog || 'No changelog provided.'}
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'comments' && (
            <div className="space-y-6">
              {/* Post comment box */}
              {user ? (
                <form
                  onSubmit={handlePostComment}
                  className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3"
                >
                  <label className="block text-xs font-semibold text-slate-300">
                    Join the Discussion
                  </label>
                  <textarea
                    rows={3}
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Ask questions, leave feedback, or report issues..."
                    className="w-full p-3 bg-slate-950 border border-slate-700/80 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-primary-500"
                  />
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={postingComment || !newComment.trim()}
                      className="px-4 py-2 bg-primary-600 hover:bg-primary-500 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors"
                    >
                      {postingComment ? 'Posting...' : 'Post Comment'}
                    </button>
                  </div>
                </form>
              ) : (
                <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 text-center text-xs text-slate-400">
                  Please{' '}
                  <Link to="/login" className="text-primary-400 hover:underline">
                    sign in
                  </Link>{' '}
                  to leave a comment.
                </div>
              )}

              {/* Comments list */}
              <div className="space-y-3">
                {comments.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-500">
                    No comments yet. Be the first to start the conversation!
                  </div>
                ) : (
                  comments.map((c) => (
                    <div
                      key={c.id}
                      className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Avatar src={c.authorAvatarUrl} name={c.authorDisplayName} size="xs" />
                          <span className="text-xs font-semibold text-slate-200">
                            {c.authorDisplayName}
                          </span>
                          {c.authorIsCreator && (
                            <Badge variant="primary" size="sm">
                              Creator
                            </Badge>
                          )}
                          {c.authorIsAdmin && (
                            <Badge variant="warning" size="sm">
                              Admin
                            </Badge>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {formatDistanceToNow(new Date(c.createdAt), { addSuffix: true })}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">{c.content}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Sidebar Info (Right) */}
        <aside className="space-y-6">
          {/* Metadata Card */}
          <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-4 text-xs">
            <h3 className="font-heading font-semibold text-slate-200 text-sm pb-2 border-b border-slate-800">
              Technical Details
            </h3>

            {/* Edition */}
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Minecraft Edition</span>
              <span className="font-semibold text-slate-200 uppercase">{project.editionId}</span>
            </div>

            {/* Environment */}
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Environment</span>
              <span className="font-semibold text-slate-200 capitalize">{project.environment}</span>
            </div>

            {/* License */}
            <div className="flex items-center justify-between">
              <span className="text-slate-400">License</span>
              <span className="font-mono text-slate-300">{project.license || 'Custom'}</span>
            </div>

            {/* Supported MC Versions */}
            <div>
              <span className="block text-slate-400 mb-1.5">Game Versions</span>
              <div className="flex flex-wrap gap-1">
                {project.minecraftVersions?.map((v) => (
                  <span
                    key={v}
                    className="font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px]"
                  >
                    {v}
                  </span>
                ))}
              </div>
            </div>

            {/* Loaders */}
            <div>
              <span className="block text-slate-400 mb-1.5">Loaders</span>
              <div className="flex flex-wrap gap-1">
                {project.loaders?.map((l) => (
                  <span
                    key={l}
                    className="capitalize px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px]"
                  >
                    {l}
                  </span>
                ))}
              </div>
            </div>

            {/* Categories */}
            <div>
              <span className="block text-slate-400 mb-1.5">Categories</span>
              <div className="flex flex-wrap gap-1">
                {project.categoryIds?.map((cat) => (
                  <Link
                    key={cat}
                    to={`/discover?category=${cat}`}
                    className="capitalize px-2 py-0.5 rounded bg-secondary-950/40 text-secondary-300 border border-secondary-800/40 text-[11px] hover:border-secondary-500"
                  >
                    {cat}
                  </Link>
                ))}
              </div>
            </div>

            {/* Statistics */}
            <div className="pt-3 border-t border-slate-800/80 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Downloads</span>
                <span className="font-semibold text-slate-200">{formatCount(project.downloads)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Followers</span>
                <span className="font-semibold text-slate-200">{formatCount(project.followers)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Views</span>
                <span className="font-semibold text-slate-200">{formatCount(project.views)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Last Updated</span>
                <span className="text-slate-400">
                  {project.updatedAt
                    ? formatDistanceToNow(new Date(project.updatedAt), { addSuffix: true })
                    : 'recently'}
                </span>
              </div>
            </div>

            {/* External Links */}
            {project.links && (
              <div className="pt-3 border-t border-slate-800/80 space-y-1.5">
                {getSafeUrl(project.links.source) && (
                  <a
                    href={getSafeUrl(project.links.source)!}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-800/50 hover:bg-slate-800 text-slate-300 transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <GithubIcon size={14} /> Source Code
                    </span>
                    <ExternalLink size={12} className="text-slate-500" />
                  </a>
                )}
                {getSafeUrl(project.links.issues) && (
                  <a
                    href={getSafeUrl(project.links.issues)!}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-800/50 hover:bg-slate-800 text-slate-300 transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <HelpCircle size={14} /> Issue Tracker
                    </span>
                    <ExternalLink size={12} className="text-slate-500" />
                  </a>
                )}
                {getSafeUrl(project.links.wiki) && (
                  <a
                    href={getSafeUrl(project.links.wiki)!}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-800/50 hover:bg-slate-800 text-slate-300 transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <BookOpen size={14} /> Documentation / Wiki
                    </span>
                    <ExternalLink size={12} className="text-slate-500" />
                  </a>
                )}
              </div>
            )}
          </div>

          {/* Ad Slot on Project Page */}
          <AdSlot placement="project" />
        </aside>
      </div>

      {/* Share Modal */}
      <Modal isOpen={shareModalOpen} onClose={() => setShareModalOpen(false)} title="Share Project">
        <div className="space-y-4 text-xs">
          <p className="text-slate-400">Share this Minecraft resource with your friends and community:</p>
          <div className="flex items-center gap-2 p-2 bg-slate-950 border border-slate-800 rounded-xl">
            <input
              type="text"
              readOnly
              value={window.location.href}
              className="bg-transparent text-slate-300 text-xs w-full focus:outline-none font-mono"
            />
            <button
              onClick={handleCopyLink}
              className="px-3 py-1.5 bg-primary-600 hover:bg-primary-500 text-white rounded-lg font-medium shrink-0 flex items-center gap-1"
            >
              <Copy size={13} />
              <span>Copy</span>
            </button>
          </div>
        </div>
      </Modal>

      {/* Report Modal */}
      <Modal
        isOpen={reportModalOpen}
        onClose={() => setReportModalOpen(false)}
        title="Report Content to Moderators"
      >
        <form onSubmit={handleReportSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Reason for Report</label>
            <select
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
            >
              <option value="copyright">Copyright Infringement / Stolen Assets</option>
              <option value="malware">Malware / Malicious Code</option>
              <option value="scam">Scam / Phishing</option>
              <option value="nsfw">NSFW / Inappropriate Content</option>
              <option value="misleading">Misleading Description or Title</option>
              <option value="reupload">Unauthorized Reupload</option>
              <option value="spam">Spam / Low Quality</option>
              <option value="other">Other Violation</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Additional Details</label>
            <textarea
              rows={3}
              required
              value={reportDetails}
              onChange={(e) => setReportDetails(e.target.value)}
              placeholder="Please provide specific timestamps, URLs, or evidence..."
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setReportModalOpen(false)}
              className="px-3 py-1.5 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg font-semibold"
            >
              Submit Report
            </button>
          </div>
        </form>
      </Modal>

      {/* Screenshot Lightbox Modal */}
      {activeImage && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setActiveImage(null)}
        >
          <img
            src={activeImage}
            alt="Screenshot Preview"
            className="max-w-full max-h-[90vh] object-contain rounded-2xl shadow-2xl"
          />
        </div>
      )}

      {/* Admin Delete Confirmation Dialog */}
      {deleteConfirmOpen && (
        <ConfirmDialog
          isOpen={deleteConfirmOpen}
          onClose={() => setDeleteConfirmOpen(false)}
          onConfirm={async () => {
            if (!user) return;
            try {
              await adminService.deleteProject(
                project.id,
                user.uid,
                profile?.username || 'admin',
                project.title
              );
              showToast(`Project "${project.title}" was permanently deleted.`, 'success');
              navigate('/admin/projects');
            } catch (err: any) {
              showToast(err.message || 'Failed to delete project.', 'error');
            }
          }}
          title="Delete Project Permanently"
          message={`Are you sure you want to permanently delete "${project.title}"? All associated files, versions, and metadata will be permanently deleted from PHICHMC. This action cannot be undone.`}
          confirmText="Delete Project"
          cancelText="Cancel"
          isDestructive={true}
        />
      )}
    </div>
  );
};

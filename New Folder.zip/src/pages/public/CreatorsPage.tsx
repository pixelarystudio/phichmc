import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs, limit, orderBy } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { UserProfile } from '../../types';
import { CreatorCard } from '../../components/common/CreatorCard';
import { Users, Search } from 'lucide-react';

export const CreatorsPage: React.FC = () => {
  const [creators, setCreators] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchCreators = async () => {
      setLoading(true);
      try {
        const q = query(
          collection(db, 'users'),
          where('isCreator', '==', true),
          limit(30)
        );
        const snap = await getDocs(q);
        if (!snap.empty) {
          setCreators(snap.docs.map((d) => d.data() as UserProfile));
        }
      } catch (err) {
        console.warn('Error fetching creators:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchCreators();
  }, []);

  const filtered = creators.filter(
    (c) =>
      c.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.displayName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
            <Users className="text-primary-400" />
            <span>Minecraft Creators</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Discover passionate mod developers, texture pack designers, and world builders.
          </p>
        </div>

        <div className="w-full sm:w-72 relative">
          <Search size={16} className="absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search creators..."
            className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-primary-500"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.length === 0 && !loading ? (
          <div className="col-span-3 p-12 text-center text-slate-400 text-sm">
            No creators found matching your search.
          </div>
        ) : (
          filtered.map((creator) => (
            <CreatorCard key={creator.uid} creator={creator} />
          ))
        )}
      </div>
    </div>
  );
};

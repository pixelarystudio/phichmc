import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import { ShieldAlert, BookOpen, Scale, FileText, LifeBuoy, HeartHandshake } from 'lucide-react';

export const LegalPage: React.FC = () => {
  const { pathname } = useLocation();

  const getPageData = () => {
    switch (pathname) {
      case '/about':
        return {
          title: 'About PHICHMC',
          icon: BookOpen,
          content: `### Discover. Create. Share Minecraft.

PHICHMC is a modern, independent resource-sharing and creator ecosystem designed specifically for the Minecraft community. Inspired by modern open package repositories, PHICHMC brings together mod developers, shader creators, texture pack designers, and players under one fast, secure, and clean web experience.

#### Our Principles
- **Creator-First Publishing:** Transparent moderation, robust multi-version management, real-time analytics, and clean submission flows.
- **Safety & Quality:** Strict file validation, SHA-256 integrity verification, no dangerous executables, and proactive community moderation.
- **Independent Identity:** PHICHMC is an autonomous platform with its own community standards and infrastructure.
- **Mojang Disclaimer:** PHICHMC is NOT an official Minecraft service and is NOT associated or endorsed by Mojang Synergies AB or Microsoft.`,
        };

      case '/terms':
        return {
          title: 'Terms of Service',
          icon: Scale,
          content: `### 1. Acceptance of Terms
By creating an account, browsing, uploading, or downloading resources on PHICHMC, you agree to be bound by these Terms of Service and all applicable laws and regulations.

### 2. User Accounts & Responsibilities
- You are responsible for safeguarding your login credentials.
- You must provide accurate registration information.
- Accounts engaged in malicious behavior, spamming, artificial metric manipulation, or harassment will be immediately suspended or terminated.

### 3. Creator Content & Licensing
- Creators retain ownership and copyrights to their submitted Minecraft files and assets.
- By submitting resources to PHICHMC, you grant the platform a worldwide, non-exclusive license to host, display, and distribute your content to players.
- You represent and warrant that you own or possess all necessary rights, licenses, and permissions for any material you upload.

### 4. Prohibited Content
You may NOT upload:
- Executable malware, viruses, miners, trojans, or unauthorized scripts.
- Reuploaded content belonging to other authors without explicit permission.
- Deceptive download links or malicious redirects.`,
        };

      case '/privacy':
        return {
          title: 'Privacy Policy',
          icon: FileText,
          content: `### 1. Information We Collect
We collect only the minimal data required to provide a reliable platform:
- **Account Data:** Username, email address, display name, and avatar.
- **Operational Analytics:** Download events and view counts, stored using privacy-conscious session identifiers and anonymized/hashed IP addresses.
- **We NEVER sell your personal data to third parties.**

### 2. Cookies & Storage
PHICHMC uses secure browser storage for authentication tokens and session preferences.

### 3. Security
All data is stored and protected using Google Cloud Firestore and Firebase Authentication with strict security rules and access limitations.`,
        };

      case '/dmca':
      case '/copyright':
        return {
          title: 'DMCA & Copyright Policy',
          icon: ShieldAlert,
          content: `### Digital Millennium Copyright Act Notice

PHICHMC respects the intellectual property rights of others and expects its users to do the same.

If you believe that your copyrighted work has been copied and made accessible on PHICHMC in a way that constitutes copyright infringement, please submit a formal DMCA Takedown Notice to our moderation team with:
1. Identification of the copyrighted work claimed to have been infringed.
2. The URL or specific project on PHICHMC where the infringing material is located.
3. Your contact information (Name, organization, email, address).
4. A statement of good faith belief that the disputed use is not authorized by the copyright owner.
5. A statement under penalty of perjury that the information in the notification is accurate and that you are authorized to act on behalf of the owner.

You can submit an immediate DMCA report using our [Report Content](/report) form.`,
        };

      case '/community-guidelines':
        return {
          title: 'Community Guidelines',
          icon: HeartHandshake,
          content: `### Keeping PHICHMC Safe & Friendly

1. **Be Respectful:** Treat fellow creators and players with kindness. Hate speech, harassment, impersonation, and abusive conduct will result in a permanent ban.
2. **Honest Resource Listings:** Accurately represent your mods, add-ons, and texture packs. Do not use misleading tags, clickbait titles, or false Minecraft version claims.
3. **No Malicious Files:** Any attempt to distribute malware, rat tools, token loggers, or suspicious binaries will result in account termination and report to security authorities.
4. **Constructive Feedback:** When leaving comments or reporting issues, keep remarks helpful and constructive.`,
        };

      case '/contact':
        return {
          title: 'Contact Us',
          icon: LifeBuoy,
          content: `### Get in Touch with the PHICHMC Team

- **Community Support & Feedback:** Join our official Discord community for real-time discussion, suggestions, and assistance.
- **Security & Vulnerability Reports:** Email security inquiries to \`security@phichmc.com\`.
- **DMCA / Legal Matters:** Send legal correspondence to \`legal@phichmc.com\` or use the [Report Abuse](/report) tool.`,
        };

      default:
        return {
          title: 'Information',
          icon: BookOpen,
          content: 'Information page.',
        };
    }
  };

  const { title, icon: Icon, content } = getPageData();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      <div className="flex items-center gap-3 pb-6 border-b border-slate-800">
        <div className="w-12 h-12 rounded-xl bg-primary-500/10 border border-primary-500/20 text-primary-400 flex items-center justify-center">
          <Icon size={24} />
        </div>
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white">{title}</h1>
          <p className="text-xs text-slate-400 font-mono">PHICHMC Official Documentation</p>
        </div>
      </div>

      <div className="p-8 rounded-3xl bg-slate-900/60 border border-slate-800 text-slate-300 text-sm leading-relaxed space-y-4">
        {content.split('\n\n').map((paragraph, i) => {
          if (paragraph.startsWith('### ')) {
            return (
              <h2 key={i} className="text-xl font-heading font-bold text-white pt-4 pb-1">
                {paragraph.replace('### ', '')}
              </h2>
            );
          }
          if (paragraph.startsWith('#### ')) {
            return (
              <h3 key={i} className="text-base font-heading font-semibold text-slate-100 pt-2">
                {paragraph.replace('#### ', '')}
              </h3>
            );
          }
          return (
            <p key={i} className="whitespace-pre-line">
              {paragraph}
            </p>
          );
        })}
      </div>
    </div>
  );
};

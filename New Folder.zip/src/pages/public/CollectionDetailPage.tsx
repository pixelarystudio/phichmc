import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { CollectionItem, ProjectItem } from '../../types';
import { communityService } from '../../services/communityService';
import { projectService } from '../../services/projectService';
import { ResourceCard } from '../../components/common/ResourceCard';
import { FolderHeart, ArrowLeft, Layers } from 'lucide-react';

export const CollectionDetailPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [collection, setCollection] = useState<CollectionItem | null>(null);
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!slug) return;
    const loadData = async () => {
      setLoading(true);
      const col = await communityService.getCollectionBySlug(slug);
      setCollection(col);
      if (col && col.projectIds?.length > 0) {
        const pList: ProjectItem[] = [];
        for (const pid of col.projectIds) {
          const p = await projectService.getProjectById(pid);
          if (p && p.status === 'approved') {
            pList.push(p);
          }
        }
        setProjects(pList);
      }
      setLoading(false);
    };
    loadData();
  }, [slug]);

  if (!collection && !loading) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-xl font-heading font-bold text-white">Collection Not Found</h2>
        <Link to="/collections" className="text-xs text-primary-400 hover:underline">
          Browse All Collections
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <Link
        to="/collections"
        className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200"
      >
        <ArrowLeft size={14} />
        <span>All Collections</span>
      </Link>

      {collection && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-secondary-400 text-xs font-semibold uppercase tracking-wider">
            <FolderHeart size={16} />
            <span>Curated Collection</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white">
            {collection.name}
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
            {collection.description}
          </p>
          <div className="text-xs text-slate-500 pt-2">
            Curated by @{collection.ownerUsername} • {projects.length} approved items
          </div>
        </div>
      )}

      <div className="space-y-4">
        {projects.length === 0 && !loading ? (
          <div className="p-12 text-center text-slate-400 text-sm">
            This collection does not contain any approved resources yet.
          </div>
        ) : (
          projects.map((p) => <ResourceCard key={p.id} project={p} />)
        )}
      </div>
    </div>
  );
};

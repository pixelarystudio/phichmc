import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  Users,
  Download,
  Box,
  Calendar,
  Globe,
  MessageSquare,
  Eye,
  Heart,
  FolderHeart,
} from 'lucide-react';
import { TwitterIcon, GithubIcon } from '../../components/common/SocialIcons';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { UserProfile, ProjectItem, CollectionItem } from '../../types';
import { Avatar } from '../../components/common/Avatar';
import { VerifiedBadge } from '../../components/common/VerifiedBadge';
import { ResourceCard } from '../../components/common/ResourceCard';
import { CollectionCard } from '../../components/common/CollectionCard';
import { useAuth } from '../../contexts/AuthContext';
import { communityService } from '../../services/communityService';
import { formatCount } from '../../components/common/ResourceCard';
import { format } from 'date-fns';
import { getSafeUrl } from '../../utils/security';
import { useToast } from '../../components/common/Toast';
import { useSeo } from '../../hooks/useSeo';

export const UserProfilePage: React.FC = () => {
  const { username } = useParams<{ username: string }>();
  const { user } = useAuth();
  const { showToast } = useToast();

  const [profile, setProfile] = useState<UserProfile | null>(null);

  useSeo({
    title: profile ? `@${profile.username} (${profile.displayName})` : `@${username || 'creator'}`,
    description: profile?.bio || `View Minecraft projects and collections by ${username} on PHICHMC.`,
  });
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [collections, setCollections] = useState<CollectionItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'projects' | 'collections' | 'about'>('projects');
  const [isFollowing, setIsFollowing] = useState(false);

  useEffect(() => {
    if (!username) return;
    const fetchUser = async () => {
      setLoading(true);
      try {
        const q = query(collection(db, 'users'), where('username', '==', username), limit(1));
        const snap = await getDocs(q);

        if (!snap.empty) {
          const uData = snap.docs[0].data() as UserProfile;
          setProfile(uData);

          // Fetch user's approved projects
          const pq = query(
            collection(db, 'projects'),
            where('creatorId', '==', uData.uid),
            where('status', '==', 'approved')
          );
          const pSnap = await getDocs(pq);
          setProjects(pSnap.docs.map((d) => d.data() as ProjectItem));

          // Fetch user's public collections
          const cq = query(
            collection(db, 'collections'),
            where('ownerId', '==', uData.uid),
            where('visibility', '==', 'public')
          );
          const cSnap = await getDocs(cq);
          setCollections(cSnap.docs.map((d) => d.data() as CollectionItem));

          // Follow state check
          if (user) {
            const fol = await communityService.isFollowingUser(uData.uid, user.uid);
            setIsFollowing(fol);
          }
        } else {
          setProfile(null);
        }
      } catch (err) {
        console.error('Error fetching user profile:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [username, user]);

  const handleFollowToggle = async () => {
    if (!user || !profile) return;
    const next = await communityService.toggleFollowUser(profile.uid, user.uid);
    setIsFollowing(next);
    setProfile((prev) =>
      prev ? { ...prev, followersCount: prev.followersCount + (next ? 1 : -1) } : null
    );
    showToast(next ? `Following @${profile.username}!` : `Unfollowed @${profile.username}`);
  };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-16 animate-pulse space-y-6">
        <div className="h-44 bg-slate-900 rounded-3xl" />
        <div className="h-64 bg-slate-900 rounded-3xl" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <h2 className="text-xl font-heading font-bold text-slate-100 mb-2">User Not Found</h2>
        <p className="text-sm text-slate-400 mb-6">
          The user "@{username}" could not be found on PHICHMC.
        </p>
        <Link to="/" className="px-4 py-2 bg-primary-600 rounded-xl text-xs font-semibold text-white">
          Back Home
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Profile Header Banner */}
      <section className="relative p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-xl overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <Avatar
              src={profile.avatarUrl}
              name={profile.displayName || profile.username}
              size="xl"
              className="border-2 border-primary-500/40 shadow-xl"
            />
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-heading font-bold text-white">
                  {profile.displayName || profile.username}
                </h1>
                {profile.isVerified && <VerifiedBadge type="creator" showLabel />}
              </div>
              <p className="text-xs sm:text-sm text-primary-400 font-mono">@{profile.username}</p>
              {profile.bio && (
                <p className="text-xs sm:text-sm text-slate-300 max-w-xl leading-relaxed pt-1">
                  {profile.bio}
                </p>
              )}
            </div>
          </div>

          {/* Follow Button (if not own profile) */}
          {user && user.uid !== profile.uid && (
            <button
              onClick={handleFollowToggle}
              className={`px-5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                isFollowing
                  ? 'bg-slate-800 text-slate-200 border border-slate-700'
                  : 'bg-primary-600 hover:bg-primary-500 text-white shadow-md'
              }`}
            >
              {isFollowing ? 'Following' : 'Follow Creator'}
            </button>
          )}
        </div>

        {/* Counter Strip */}
        <div className="flex flex-wrap items-center gap-6 pt-6 mt-6 border-t border-slate-800/80 text-xs text-slate-300">
          <div className="flex items-center gap-1.5">
            <Users size={15} className="text-primary-400" />
            <strong className="text-white">{formatCount(profile.followersCount || 0)}</strong>
            <span className="text-slate-400">followers</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Box size={15} className="text-secondary-400" />
            <strong className="text-white">{projects.length}</strong>
            <span className="text-slate-400">projects</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Download size={15} className="text-emerald-400" />
            <strong className="text-white">{formatCount(profile.totalDownloads || 0)}</strong>
            <span className="text-slate-400">downloads</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-500 ml-auto">
            <Calendar size={14} />
            <span>
              Joined {profile.joinedAt ? format(new Date(profile.joinedAt), 'MMMM yyyy') : 'Recently'}
            </span>
          </div>
        </div>
      </section>

      {/* Profile Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-sm font-medium">
        <button
          onClick={() => setActiveTab('projects')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            activeTab === 'projects'
              ? 'bg-primary-500/10 text-primary-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Projects ({projects.length})
        </button>
        <button
          onClick={() => setActiveTab('collections')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            activeTab === 'collections'
              ? 'bg-primary-500/10 text-primary-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Collections ({collections.length})
        </button>
        <button
          onClick={() => setActiveTab('about')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            activeTab === 'about'
              ? 'bg-primary-500/10 text-primary-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          About
        </button>
      </div>

      {/* Tab Panels */}
      {activeTab === 'projects' && (
        <div className="space-y-4">
          {projects.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-sm">
              This creator hasn't published any public projects yet.
            </div>
          ) : (
            projects.map((p) => <ResourceCard key={p.id} project={p} />)
          )}
        </div>
      )}

      {activeTab === 'collections' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {collections.length === 0 ? (
            <div className="col-span-3 p-12 text-center text-slate-400 text-sm">
              No public collections created yet.
            </div>
          ) : (
            collections.map((col) => <CollectionCard key={col.id} collection={col} />)
          )}
        </div>
      )}

      {activeTab === 'about' && (
        <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4 text-xs">
          <h3 className="font-heading font-semibold text-slate-200 text-sm">About Creator</h3>
          <p className="text-slate-300 leading-relaxed">
            {profile.bio || 'No extended bio provided.'}
          </p>

          {getSafeUrl(profile.website) && (
            <div className="pt-3 border-t border-slate-800 flex items-center gap-2 text-primary-400">
              <Globe size={14} />
              <a
                href={getSafeUrl(profile.website)!}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:underline"
              >
                {profile.website}
              </a>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

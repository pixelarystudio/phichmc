import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useSiteConfig } from '../../contexts/SiteConfigContext';
import { DiscoverPage } from './DiscoverPage';
import { Badge } from '../../components/common/Badge';

export const ResourceHubPage: React.FC = () => {
  const { type } = useParams<{ type?: string }>();
  const { resourceTypes } = useSiteConfig();

  const currentType = resourceTypes.find((t) => t.slug === type);

  return (
    <div>
      {/* Category banner if specific type */}
      {currentType && (
        <div className="bg-slate-900/80 border-b border-slate-800 py-8 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto space-y-2">
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-heading font-extrabold text-white">
                Minecraft {currentType.name}
              </h1>
              <Badge variant="primary" size="md">
                Hub
              </Badge>
            </div>
            <p className="text-sm text-slate-400 max-w-2xl leading-relaxed">
              {currentType.description}. Browse approved downloads tested for compatibility across Java and Bedrock editions.
            </p>
          </div>
        </div>
      )}

      {/* Renders the full search and discovery mechanism */}
      <DiscoverPage />
    </div>
  );
};

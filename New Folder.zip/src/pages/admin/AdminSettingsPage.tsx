import React, { useState } from 'react';
import { useSiteConfig } from '../../contexts/SiteConfigContext';
import { adminService } from '../../services/adminService';
import { useToast } from '../../components/common/Toast';
import { seedPlatformDefaults, removeDemoData } from '../../firebase/seed';
import { Settings, Save, AlertTriangle, RefreshCw, Database } from 'lucide-react';

export const AdminSettingsPage: React.FC = () => {
  const { settings, reloadConfig } = useSiteConfig();
  const { showToast } = useToast();

  const [siteName, setSiteName] = useState(settings.siteName);
  const [tagline, setTagline] = useState(settings.tagline);
  const [primaryColor, setPrimaryColor] = useState(settings.primaryColor);
  const [secondaryColor, setSecondaryColor] = useState(settings.secondaryColor);
  const [maintenanceMode, setMaintenanceMode] = useState(settings.maintenanceMode);
  const [allowRegistration, setAllowRegistration] = useState(settings.allowRegistration);
  const [allowCreatorApplications, setAllowCreatorApplications] = useState(settings.allowCreatorApplications);
  const [allowComments, setAllowComments] = useState(settings.allowComments);
  const [discordUrl, setDiscordUrl] = useState(settings.discordUrl || '');
  const [twitterUrl, setTwitterUrl] = useState(settings.twitterUrl || '');
  const [githubUrl, setGithubUrl] = useState(settings.githubUrl || '');
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await adminService.updateSiteSettings({
        siteName: siteName.trim(),
        tagline: tagline.trim(),
        primaryColor,
        secondaryColor,
        maintenanceMode,
        allowRegistration,
        allowCreatorApplications,
        allowComments,
        discordUrl: discordUrl.trim(),
        twitterUrl: twitterUrl.trim(),
        githubUrl: githubUrl.trim(),
      });
      showToast('Platform settings saved successfully!');
      reloadConfig();
    } catch {
      showToast('Error updating settings.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleSeedDefaults = async () => {
    try {
      await seedPlatformDefaults(true);
      showToast('Platform defaults & sample projects seeded!');
      reloadConfig();
    } catch {
      showToast('Error seeding defaults.', 'error');
    }
  };

  const handleRemoveDemo = async () => {
    try {
      await removeDemoData();
      showToast('Demo projects purged.');
      reloadConfig();
    } catch {
      showToast('Error removing demo data.', 'error');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <div className="pb-6 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
          <Settings className="text-amber-400" />
          <span>Global Platform Settings</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Configure site name, brand accents, maintenance locks, and registration controls.
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-6 text-xs">
        {/* Maintenance Lock */}
        <div className="p-6 rounded-2xl bg-amber-950/20 border border-amber-900/40 space-y-2">
          <div className="flex items-center justify-between">
            <div>
              <span className="font-heading font-bold text-sm text-amber-200">
                Platform Maintenance Mode
              </span>
              <p className="text-xs text-slate-400 mt-0.5">
                Displays a maintenance screen to public visitors while allowing administrators full access.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setMaintenanceMode(!maintenanceMode)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                maintenanceMode
                  ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}
            >
              {maintenanceMode ? 'ACTIVE' : 'OFF'}
            </button>
          </div>
        </div>

        {/* Feature Switches */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="font-heading font-bold text-sm text-white">Platform Feature Controls</h3>

          <div className="flex items-center justify-between py-2 border-b border-slate-800">
            <div>
              <span className="font-semibold text-slate-200 block">Allow New User Registration</span>
              <span className="text-slate-400">Controls whether new visitors can sign up.</span>
            </div>
            <input
              type="checkbox"
              checked={allowRegistration}
              onChange={(e) => setAllowRegistration(e.target.checked)}
              className="w-4 h-4 rounded text-primary-600 focus:ring-primary-500 bg-slate-950 border-slate-700"
            />
          </div>

          <div className="flex items-center justify-between py-2 border-b border-slate-800">
            <div>
              <span className="font-semibold text-slate-200 block">Allow Creator Applications</span>
              <span className="text-slate-400">Controls whether users can submit creator requests.</span>
            </div>
            <input
              type="checkbox"
              checked={allowCreatorApplications}
              onChange={(e) => setAllowCreatorApplications(e.target.checked)}
              className="w-4 h-4 rounded text-primary-600 focus:ring-primary-500 bg-slate-950 border-slate-700"
            />
          </div>

          <div className="flex items-center justify-between py-2">
            <div>
              <span className="font-semibold text-slate-200 block">Allow Public Comments</span>
              <span className="text-slate-400">Global killswitch for comment threads on project pages.</span>
            </div>
            <input
              type="checkbox"
              checked={allowComments}
              onChange={(e) => setAllowComments(e.target.checked)}
              className="w-4 h-4 rounded text-primary-600 focus:ring-primary-500 bg-slate-950 border-slate-700"
            />
          </div>
        </div>

        {/* Brand Information */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="font-heading font-bold text-sm text-white">Brand & Presentation</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Platform Name</label>
              <input
                type="text"
                required
                value={siteName}
                onChange={(e) => setSiteName(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Tagline</label>
              <input
                type="text"
                required
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Primary Accent Color</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="w-10 h-10 rounded-lg bg-transparent border border-slate-700 cursor-pointer"
                />
                <input
                  type="text"
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Secondary Accent Color</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={secondaryColor}
                  onChange={(e) => setSecondaryColor(e.target.value)}
                  className="w-10 h-10 rounded-lg bg-transparent border border-slate-700 cursor-pointer"
                />
                <input
                  type="text"
                  value={secondaryColor}
                  onChange={(e) => setSecondaryColor(e.target.value)}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200 font-mono"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Social Links */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="font-heading font-bold text-sm text-white">Community & Social Links</h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Discord Invite URL</label>
              <input
                type="url"
                value={discordUrl}
                onChange={(e) => setDiscordUrl(e.target.value)}
                className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Twitter / X URL</label>
              <input
                type="url"
                value={twitterUrl}
                onChange={(e) => setTwitterUrl(e.target.value)}
                className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">GitHub Org URL</label>
              <input
                type="url"
                value={githubUrl}
                onChange={(e) => setGithubUrl(e.target.value)}
                className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 px-6 py-2.5 bg-amber-600 hover:bg-amber-500 text-black font-semibold rounded-xl shadow-md transition-all"
          >
            <Save size={16} />
            <span>{saving ? 'Saving...' : 'Save Site Settings'}</span>
          </button>
        </div>
      </form>

      {/* Database Diagnostics & Seed Utilities */}
      <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4 text-xs">
        <h3 className="font-heading font-bold text-sm text-white flex items-center gap-2">
          <Database size={16} className="text-primary-400" />
          <span>Platform Data Tools</span>
        </h3>
        <p className="text-slate-400 leading-relaxed">
          Initialize or refresh default Minecraft taxonomy, loaders, and sample resources.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            type="button"
            onClick={handleSeedDefaults}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-semibold border border-slate-700"
          >
            <RefreshCw size={14} />
            <span>Reset & Re-seed Defaults</span>
          </button>

          <button
            type="button"
            onClick={handleRemoveDemo}
            className="flex items-center gap-1.5 px-4 py-2 bg-rose-950/40 hover:bg-rose-900/40 text-rose-300 rounded-xl font-semibold border border-rose-800/60"
          >
            <span>Purge Demo Data</span>
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { adminService } from '../../services/adminService';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/common/Toast';
import { ProjectItem, CreatorApplication } from '../../types';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { MarkdownRenderer } from '../../components/common/MarkdownRenderer';
import {
  FileCheck2,
  Users,
  CheckCircle,
  XCircle,
  AlertTriangle,
  ExternalLink,
  Eye,
  Box,
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export const AdminModerationPage: React.FC = () => {
  const { user, profile } = useAuth();
  const { showToast } = useToast();

  const [activeQueue, setActiveQueue] = useState<'projects' | 'applications'>('projects');
  const [pendingProjects, setPendingProjects] = useState<ProjectItem[]>([]);
  const [pendingApps, setPendingApps] = useState<CreatorApplication[]>([]);
  const [loading, setLoading] = useState(true);

  // Review Project Modal
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [rejectReasonPreset, setRejectReasonPreset] = useState('Invalid file or missing dependencies');
  const [customReason, setCustomReason] = useState('');
  const [privateNote, setPrivateNote] = useState('');
  const [showRejectForm, setShowRejectForm] = useState(false);
  const [processing, setProcessing] = useState(false);

  // Review Application Modal
  const [selectedApp, setSelectedApp] = useState<CreatorApplication | null>(null);
  const [appDecisionNote, setAppDecisionNote] = useState('');

  const fetchQueues = async () => {
    setLoading(true);
    try {
      const [projs, apps] = await Promise.all([
        adminService.getPendingProjects(),
        adminService.getCreatorApplications(),
      ]);
      setPendingProjects(projs);
      setPendingApps(apps.filter((a) => a.status === 'pending'));
    } catch (err) {
      console.warn('Error loading moderation queue:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchQueues();
  }, []);

  const handleApproveProject = async (project: ProjectItem) => {
    if (!user) return;
    const adminName = profile?.username || user.displayName || user.email?.split('@')[0] || 'admin';
    setProcessing(true);
    try {
      await adminService.moderateProject(
        project.id,
        'approved',
        user.uid,
        adminName,
        'Approved by moderation team'
      );
      showToast(`Approved "${project.title}"! Project is now public.`, 'success');
      setSelectedProject(null);
      fetchQueues();
    } catch (err: any) {
      console.error('Error approving project:', err);
      showToast(err?.message || 'Error approving project.', 'error');
    } finally {
      setProcessing(false);
    }
  };

  const handleRejectProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !user) return;
    const adminName = profile?.username || user.displayName || user.email?.split('@')[0] || 'admin';

    const publicReason = customReason.trim() ? customReason.trim() : rejectReasonPreset;
    setProcessing(true);
    try {
      await adminService.moderateProject(
        selectedProject.id,
        'rejected',
        user.uid,
        adminName,
        publicReason,
        privateNote.trim() || undefined
      );
      showToast(`Project rejected with feedback.`, 'success');
      setSelectedProject(null);
      setShowRejectForm(false);
      fetchQueues();
    } catch (err: any) {
      console.error('Error rejecting project:', err);
      showToast(err?.message || 'Error rejecting project.', 'error');
    } finally {
      setProcessing(false);
    }
  };

  const handleReviewApplication = async (decision: 'approved' | 'rejected') => {
    if (!selectedApp || !user) return;
    const adminName = profile?.username || user.displayName || user.email?.split('@')[0] || 'admin';
    setProcessing(true);
    try {
      await adminService.reviewCreatorApplication(
        selectedApp.id,
        selectedApp.userId,
        decision,
        user.uid,
        adminName,
        appDecisionNote.trim() || undefined
      );
      showToast(`Creator application ${decision}!`, 'success');
      setSelectedApp(null);
      fetchQueues();
    } catch (err: any) {
      console.error('Error updating application:', err);
      showToast(err?.message || 'Error updating creator application.', 'error');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
            <FileCheck2 className="text-amber-400" />
            <span>Moderation Center</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Review submissions, evaluate Minecraft resource safety, and process creator applications.
          </p>
        </div>

        {/* Queue Switcher */}
        <div className="flex items-center gap-2 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs font-semibold">
          <button
            onClick={() => setActiveQueue('projects')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${
              activeQueue === 'projects'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>Pending Projects</span>
            {pendingProjects.length > 0 && (
              <span className="w-5 h-5 rounded-full bg-amber-500 text-black text-[10px] font-bold flex items-center justify-center">
                {pendingProjects.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveQueue('applications')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${
              activeQueue === 'applications'
                ? 'bg-primary-500/20 text-primary-300 border border-primary-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>Creator Apps</span>
            {pendingApps.length > 0 && (
              <span className="w-5 h-5 rounded-full bg-primary-500 text-white text-[10px] font-bold flex items-center justify-center">
                {pendingApps.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Queue 1: Pending Projects */}
      {activeQueue === 'projects' && (
        <div className="space-y-4">
          {pendingProjects.length === 0 && !loading ? (
            <div className="p-16 rounded-3xl bg-slate-900 border border-slate-800 text-center text-slate-400 text-xs">
              <CheckCircle size={32} className="text-emerald-400 mx-auto mb-3" />
              <p className="text-sm font-semibold text-slate-200">The moderation queue is clear!</p>
              <p className="text-slate-500 mt-1">All submitted Minecraft projects have been reviewed.</p>
            </div>
          ) : (
            pendingProjects.map((p) => (
              <div
                key={p.id}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/30 transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-xl bg-slate-800 shrink-0 flex items-center justify-center overflow-hidden">
                    {p.iconUrl ? (
                      <img src={p.iconUrl} alt={p.title} className="w-full h-full object-cover" />
                    ) : (
                      <Box size={24} className="text-amber-400" />
                    )}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-heading font-semibold text-sm text-white">{p.title}</h4>
                      <Badge variant="warning" size="sm" className="uppercase text-[10px]">
                        {p.resourceTypeId}
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-400 line-clamp-1">{p.shortDescription}</p>
                    <div className="flex items-center gap-3 text-[11px] text-slate-500 font-mono pt-1">
                      <span>Creator: @{p.creatorUsername}</span>
                      <span>•</span>
                      <span>MC: {p.minecraftVersions?.join(', ')}</span>
                      <span>•</span>
                      <span>
                        Submitted {p.createdAt ? formatDistanceToNow(new Date(p.createdAt), { addSuffix: true }) : ''}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      setSelectedProject(p);
                      setShowRejectForm(false);
                    }}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl"
                  >
                    Inspect & Review
                  </button>
                  <button
                    onClick={() => handleApproveProject(p)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl"
                  >
                    Quick Approve
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Queue 2: Creator Applications */}
      {activeQueue === 'applications' && (
        <div className="space-y-4">
          {pendingApps.length === 0 && !loading ? (
            <div className="p-16 rounded-3xl bg-slate-900 border border-slate-800 text-center text-slate-400 text-xs">
              <CheckCircle size={32} className="text-emerald-400 mx-auto mb-3" />
              <p className="text-sm font-semibold text-slate-200">No pending creator applications</p>
            </div>
          ) : (
            pendingApps.map((app) => (
              <div
                key={app.id}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-heading font-semibold text-sm text-white">
                      {app.displayName} (@{app.username})
                    </span>
                    <Badge variant="primary" size="sm">
                      {app.email}
                    </Badge>
                  </div>
                  <span className="text-xs text-slate-500 font-mono">
                    {app.createdAt ? formatDistanceToNow(new Date(app.createdAt), { addSuffix: true }) : ''}
                  </span>
                </div>

                <div className="p-3.5 bg-slate-950/60 rounded-xl space-y-2 text-xs">
                  <div>
                    <strong className="text-slate-400">Reason:</strong>{' '}
                    <span className="text-slate-200">{app.reason}</span>
                  </div>
                  <div>
                    <strong className="text-slate-400">Experience:</strong>{' '}
                    <span className="text-slate-200">{app.experience}</span>
                  </div>
                  {app.portfolio && (
                    <div>
                      <strong className="text-slate-400">Portfolio:</strong>{' '}
                      <span className="text-primary-400 font-mono break-all">{app.portfolio}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    onClick={() => {
                      setSelectedApp(app);
                    }}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl"
                  >
                    Decision Note
                  </button>
                  <button
                    onClick={() => {
                      setSelectedApp(app);
                      handleReviewApplication('approved');
                    }}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl"
                  >
                    Approve Creator
                  </button>
                  <button
                    onClick={() => {
                      setSelectedApp(app);
                      handleReviewApplication('rejected');
                    }}
                    className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-xl"
                  >
                    Reject
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Review Project Modal */}
      {selectedProject && (
        <Modal
          isOpen={Boolean(selectedProject)}
          onClose={() => setSelectedProject(null)}
          title={`Review Submission: ${selectedProject.title}`}
          maxWidth="xl"
        >
          <div className="space-y-6 text-xs">
            {/* Meta summary */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Creator:</span>
                <span className="font-semibold text-slate-200">
                  @{selectedProject.creatorUsername}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Resource Type:</span>
                <span className="uppercase text-primary-400">{selectedProject.resourceTypeId}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">MC Versions:</span>
                <span className="font-mono text-slate-200">
                  {selectedProject.minecraftVersions?.join(', ')}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Loaders:</span>
                <span className="capitalize text-slate-200">
                  {selectedProject.loaders?.join(', ')}
                </span>
              </div>
            </div>

            {/* Description Preview */}
            <div className="space-y-2">
              <span className="font-semibold text-slate-300">Project Description:</span>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 max-h-48 overflow-y-auto">
                <MarkdownRenderer content={selectedProject.description} />
              </div>
            </div>

            {/* Reject Form */}
            {showRejectForm ? (
              <form onSubmit={handleRejectProject} className="p-4 rounded-xl bg-rose-950/20 border border-rose-900/40 space-y-3">
                <h4 className="font-semibold text-rose-300">Rejection Feedback</h4>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Preset Reason</label>
                  <select
                    value={rejectReasonPreset}
                    onChange={(e) => setRejectReasonPreset(e.target.value)}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
                  >
                    <option value="Invalid file or missing dependencies">Invalid file or missing dependencies</option>
                    <option value="Copyright issue or unauthorized reupload">Copyright issue or unauthorized reupload</option>
                    <option value="Malware or security concern">Malware or security concern</option>
                    <option value="Misleading title or description">Misleading title or description</option>
                    <option value="Duplicate project already exists">Duplicate project already exists</option>
                    <option value="Incorrect category or resource type">Incorrect category or resource type</option>
                    <option value="Unsupported content or corrupted archive">Unsupported content or corrupted archive</option>
                    <option value="Community guideline violation">Community guideline violation</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Custom Public Note (Optional)</label>
                  <textarea
                    rows={2}
                    value={customReason}
                    onChange={(e) => setCustomReason(e.target.value)}
                    placeholder="Specific explanation shown to the creator..."
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Private Moderator Note (Staff Only)</label>
                  <input
                    type="text"
                    value={privateNote}
                    onChange={(e) => setPrivateNote(e.target.value)}
                    placeholder="Internal reference not visible to the user..."
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200 font-mono"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowRejectForm(false)}
                    className="px-3 py-1.5 text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={processing}
                    className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-semibold rounded-lg"
                  >
                    {processing ? 'Rejecting...' : 'Confirm Rejection'}
                  </button>
                </div>
              </form>
            ) : (
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowRejectForm(true)}
                  className="px-4 py-2 bg-rose-950/40 hover:bg-rose-900/40 border border-rose-800/60 text-rose-300 font-semibold rounded-xl"
                >
                  Reject with Reason
                </button>
                <button
                  type="button"
                  disabled={processing}
                  onClick={() => handleApproveProject(selectedProject)}
                  className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl shadow-lg"
                >
                  {processing ? 'Approving...' : 'Approve Project'}
                </button>
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};

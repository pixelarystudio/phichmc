import React, { useState } from 'react';
import { useSiteConfig } from '../../contexts/SiteConfigContext';
import { adminService } from '../../services/adminService';
import { useToast } from '../../components/common/Toast';
import { AdUnit } from '../../types';
import { DollarSign, Plus, Power, Trash2, Eye, ShieldAlert } from 'lucide-react';
import { Modal } from '../../components/common/Modal';

export const AdminAdsPage: React.FC = () => {
  const { settings, activeAds, reloadConfig } = useSiteConfig();
  const { showToast } = useToast();

  const [modalOpen, setModalOpen] = useState(false);
  const [unitTitle, setUnitTitle] = useState('');
  const [placementId, setPlacementId] = useState<'homepage' | 'discover' | 'project' | 'download' | 'between_cards' | 'footer'>('homepage');
  const [format, setFormat] = useState<'banner' | 'native' | 'social_bar' | 'popunder'>('banner');
  const [desktopCode, setDesktopCode] = useState('');
  const [saving, setSaving] = useState(false);

  const handleToggleGlobal = async () => {
    const next = !settings.adsEnabled;
    await adminService.toggleGlobalAds(next);
    showToast(next ? 'All advertisements ENABLED.' : 'Global Ads KILLSWITCH activated. All ads disabled.');
    reloadConfig();
  };

  const handleToggleAdsterra = async () => {
    const next = !settings.adsterraEnabled;
    await adminService.toggleAdsterra(next);
    showToast(next ? 'Adsterra network enabled.' : 'Adsterra network disabled.');
    reloadConfig();
  };

  const handleSaveUnit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const id = `ad_${Date.now()}`;
      const newUnit: AdUnit = {
        id,
        providerId: 'adsterra',
        placementId,
        format,
        title: unitTitle.trim(),
        desktopCode: desktopCode.trim(),
        status: 'active',
      };

      await adminService.saveAdUnit(newUnit);
      showToast('Ad unit saved successfully!');
      setModalOpen(false);
      setUnitTitle('');
      setDesktopCode('');
      reloadConfig();
    } catch {
      showToast('Error saving ad unit.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteUnit = async (id: string) => {
    await adminService.deleteAdUnit(id);
    showToast('Ad unit deleted.');
    reloadConfig();
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
            <DollarSign className="text-amber-400" />
            <span>Adsterra & Monetization Manager</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Manage ad scripts, placements, and instant platform killswitches.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-black font-semibold rounded-xl text-xs shadow-md transition-colors"
        >
          <Plus size={16} />
          <span>New Ad Unit</span>
        </button>
      </div>

      {/* Control Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Global Ads Switch */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
          <div className="space-y-1">
            <span className="font-heading font-bold text-sm text-white">Global Ads Killswitch</span>
            <p className="text-xs text-slate-400">Instantly disables all ad units across the entire platform.</p>
          </div>
          <button
            onClick={handleToggleGlobal}
            className={`p-3 rounded-xl border flex items-center gap-2 font-bold text-xs transition-colors ${
              settings.adsEnabled
                ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300'
                : 'bg-rose-950/40 border-rose-800 text-rose-300'
            }`}
          >
            <Power size={16} />
            <span>{settings.adsEnabled ? 'ON' : 'OFF'}</span>
          </button>
        </div>

        {/* Adsterra Provider Switch */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
          <div className="space-y-1">
            <span className="font-heading font-bold text-sm text-white">Adsterra Network</span>
            <p className="text-xs text-slate-400">Controls integration with Adsterra ad scripts.</p>
          </div>
          <button
            onClick={handleToggleAdsterra}
            className={`p-3 rounded-xl border flex items-center gap-2 font-bold text-xs transition-colors ${
              settings.adsterraEnabled
                ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300'
                : 'bg-slate-800 border-slate-700 text-slate-400'
            }`}
          >
            <Power size={16} />
            <span>{settings.adsterraEnabled ? 'ACTIVE' : 'PAUSED'}</span>
          </button>
        </div>
      </div>

      {/* Policy Guard Notice */}
      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs text-slate-400 flex items-start gap-3">
        <ShieldAlert size={18} className="text-amber-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong>UX Integrity Policy:</strong> Ads will never be injected over download buttons, navigation headers, authentication forms, creator dashboards, or admin console screens.
        </p>
      </div>

      {/* Configured Units */}
      <div className="space-y-3">
        <h3 className="font-heading font-bold text-sm text-white">Active Ad Units</h3>

        {activeAds.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-400">
            No custom ad units configured yet. Click "New Ad Unit" to inject an Adsterra banner or script.
          </div>
        ) : (
          activeAds.map((unit) => (
            <div
              key={unit.id}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-4 text-xs"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-heading font-semibold text-slate-100">{unit.title}</h4>
                  <span className="px-2 py-0.5 rounded bg-slate-800 font-mono text-[10px] uppercase text-primary-400">
                    {unit.placementId}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-400 capitalize">
                    {unit.format}
                  </span>
                </div>
                <div className="text-slate-500 font-mono text-[11px] truncate max-w-xl">
                  {unit.desktopCode.slice(0, 80)}...
                </div>
              </div>

              <button
                onClick={() => handleDeleteUnit(unit.id)}
                className="p-2 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                title="Delete unit"
              >
                <Trash2 size={16} />
              </button>
            </div>
          ))
        )}
      </div>

      {/* New Unit Modal */}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Configure New Ad Unit">
        <form onSubmit={handleSaveUnit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Ad Unit Name</label>
            <input
              type="text"
              required
              value={unitTitle}
              onChange={(e) => setUnitTitle(e.target.value)}
              placeholder="e.g. Discover Top 728x90 Banner"
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Placement Target</label>
              <select
                value={placementId}
                onChange={(e) => setPlacementId(e.target.value as any)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
              >
                <option value="homepage">Homepage</option>
                <option value="discover">Discover Page</option>
                <option value="project">Project Page</option>
                <option value="download">Download Page</option>
                <option value="between_cards">Between Resource Cards</option>
                <option value="footer">Footer Slot</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Format</label>
              <select
                value={format}
                onChange={(e) => setFormat(e.target.value as any)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
              >
                <option value="banner">Display Banner</option>
                <option value="native">Native Banner</option>
                <option value="social_bar">Social Bar</option>
                <option value="popunder">Popunder</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Adsterra Script / HTML Code</label>
            <textarea
              rows={4}
              required
              value={desktopCode}
              onChange={(e) => setDesktopCode(e.target.value)}
              placeholder="<!-- Paste Adsterra script tag or iframe here -->"
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200 font-mono text-[11px]"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-black font-semibold rounded-lg"
            >
              {saving ? 'Saving...' : 'Deploy Ad Unit'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

import React, { useState } from 'react';
import { useSiteConfig } from '../../contexts/SiteConfigContext';
import { adminService } from '../../services/adminService';
import { useToast } from '../../components/common/Toast';
import { Layers, Plus, Trash2, CheckCircle2, XCircle } from 'lucide-react';
import { Modal } from '../../components/common/Modal';

export const AdminTaxonomyPage: React.FC = () => {
  const {
    resourceTypes,
    categories,
    loaders,
    minecraftVersions,
    tags,
    reloadConfig,
  } = useSiteConfig();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<'categories' | 'loaders' | 'versions' | 'types' | 'tags'>('categories');

  // Add Item Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [itemName, setItemName] = useState('');
  const [itemSlug, setItemSlug] = useState('');
  const [itemDesc, setItemDesc] = useState('');
  const [itemEdition, setItemEdition] = useState<'java' | 'bedrock'>('java');

  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = itemSlug.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '') || `item_${Date.now()}`;
    const slug = id;

    try {
      if (activeTab === 'categories') {
        await adminService.saveCategory({
          id,
          name: itemName.trim(),
          slug,
          description: itemDesc.trim(),
          active: true,
          order: categories.length + 1,
        });
      } else if (activeTab === 'loaders') {
        await adminService.saveLoader({
          id,
          name: itemName.trim(),
          slug,
          edition: itemEdition,
          active: true,
        });
      } else if (activeTab === 'versions') {
        await adminService.saveMinecraftVersion({
          id,
          version: itemName.trim(),
          edition: itemEdition,
          majorGroup: itemName.split('.').slice(0, 2).join('.'),
          releaseType: 'release',
          active: true,
        });
      } else if (activeTab === 'types') {
        await adminService.saveResourceType({
          id,
          name: itemName.trim(),
          slug: slug as any,
          description: itemDesc.trim(),
          active: true,
        });
      } else if (activeTab === 'tags') {
        await adminService.saveTag({
          id,
          name: itemName.trim(),
          slug,
          active: true,
        });
      }

      showToast(`Added ${itemName} to ${activeTab}!`);
      setModalOpen(false);
      setItemName('');
      setItemSlug('');
      setItemDesc('');
      reloadConfig();
    } catch {
      showToast('Error adding taxonomy item.', 'error');
    }
  };

  const handleDeleteItem = async (id: string) => {
    try {
      if (activeTab === 'categories') await adminService.deleteCategory(id);
      if (activeTab === 'loaders') await adminService.deleteLoader(id);
      if (activeTab === 'versions') await adminService.deleteMinecraftVersion(id);
      if (activeTab === 'types') await adminService.deleteResourceType(id);
      if (activeTab === 'tags') await adminService.deleteTag(id);

      showToast('Item deleted.');
      reloadConfig();
    } catch {
      showToast('Error deleting item.', 'error');
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
            <Layers className="text-amber-400" />
            <span>Minecraft Taxonomy & Compatibility</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Configure supported game versions, mod loaders, resource categories, and tagging options at runtime.
          </p>
        </div>

        <button
          onClick={() => {
            setItemName('');
            setItemSlug('');
            setItemDesc('');
            setModalOpen(true);
          }}
          className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-black font-semibold rounded-xl text-xs shadow-md transition-colors"
        >
          <Plus size={16} />
          <span>Add New {activeTab.slice(0, -1)}</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs font-semibold overflow-x-auto">
        {[
          { key: 'categories', label: `Categories (${categories.length})` },
          { key: 'loaders', label: `Loaders (${loaders.length})` },
          { key: 'versions', label: `Minecraft Versions (${minecraftVersions.length})` },
          { key: 'types', label: `Resource Types (${resourceTypes.length})` },
          { key: 'tags', label: `Tags (${tags.length})` },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as any)}
            className={`px-3.5 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              activeTab === tab.key
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {activeTab === 'categories' &&
          categories.map((c) => (
            <div
              key={c.id}
              className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3 text-xs"
            >
              <div>
                <strong className="text-white block">{c.name}</strong>
                <span className="text-slate-400 text-[11px]">{c.description}</span>
              </div>
              <button
                onClick={() => handleDeleteItem(c.id)}
                className="p-1.5 rounded text-slate-500 hover:text-rose-400 transition-colors"
                title="Delete"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}

        {activeTab === 'loaders' &&
          loaders.map((l) => (
            <div
              key={l.id}
              className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3 text-xs"
            >
              <div>
                <strong className="text-white block">{l.name}</strong>
                <span className="text-slate-500 font-mono text-[10px] uppercase">{l.edition}</span>
              </div>
              <button
                onClick={() => handleDeleteItem(l.id)}
                className="p-1.5 rounded text-slate-500 hover:text-rose-400 transition-colors"
                title="Delete"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}

        {activeTab === 'versions' &&
          minecraftVersions.map((v) => (
            <div
              key={v.id}
              className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3 text-xs"
            >
              <div>
                <strong className="text-white font-mono block">{v.version}</strong>
                <span className="text-slate-500 text-[10px] uppercase font-mono">{v.edition} edition</span>
              </div>
              <button
                onClick={() => handleDeleteItem(v.id)}
                className="p-1.5 rounded text-slate-500 hover:text-rose-400 transition-colors"
                title="Delete"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}

        {activeTab === 'types' &&
          resourceTypes.map((t) => (
            <div
              key={t.id}
              className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3 text-xs"
            >
              <div>
                <strong className="text-white block">{t.name}</strong>
                <span className="text-slate-400 text-[11px]">{t.description}</span>
              </div>
              <button
                onClick={() => handleDeleteItem(t.id)}
                className="p-1.5 rounded text-slate-500 hover:text-rose-400 transition-colors"
                title="Delete"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}

        {activeTab === 'tags' &&
          tags.map((tg) => (
            <div
              key={tg.id}
              className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3 text-xs"
            >
              <strong className="text-white font-mono">#{tg.name}</strong>
              <button
                onClick={() => handleDeleteItem(tg.id)}
                className="p-1.5 rounded text-slate-500 hover:text-rose-400 transition-colors"
                title="Delete"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
      </div>

      {/* Add Modal */}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={`Add ${activeTab.slice(0, -1)}`}>
        <form onSubmit={handleAddItem} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Name / Version</label>
            <input
              type="text"
              required
              value={itemName}
              onChange={(e) => {
                setItemName(e.target.value);
                setItemSlug(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''));
              }}
              placeholder="e.g. 1.21.5 or Optimization"
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Identifier / Slug</label>
            <input
              type="text"
              required
              value={itemSlug}
              onChange={(e) => setItemSlug(e.target.value)}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200 font-mono"
            />
          </div>

          {(activeTab === 'loaders' || activeTab === 'versions') && (
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Minecraft Edition</label>
              <select
                value={itemEdition}
                onChange={(e) => setItemEdition(e.target.value as any)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
              >
                <option value="java">Java Edition</option>
                <option value="bedrock">Bedrock Edition</option>
              </select>
            </div>
          )}

          {(activeTab === 'categories' || activeTab === 'types') && (
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Description</label>
              <textarea
                rows={2}
                value={itemDesc}
                onChange={(e) => setItemDesc(e.target.value)}
                placeholder="Brief description of this category or resource type..."
                className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-200"
              />
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-black font-semibold rounded-lg"
            >
              Save Item
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { adminService } from '../../services/adminService';
import { AuditLogItem } from '../../types';
import { History, Search, Shield } from 'lucide-react';
import { formatDistanceToNow, format } from 'date-fns';

export const AdminAuditLogsPage: React.FC = () => {
  const [logs, setLogs] = useState<AuditLogItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLogs = async () => {
      setLoading(true);
      const items = await adminService.getAuditLogs(100);
      setLogs(items);
      setLoading(false);
    };
    fetchLogs();
  }, []);

  const filtered = logs.filter(
    (l) =>
      l.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.adminUsername.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.targetType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.targetId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
            <History className="text-amber-400" />
            <span>Administrative Audit Trail</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Immutable log of all privileged actions, status changes, and settings modifications.
          </p>
        </div>

        <div className="w-full sm:w-72 relative">
          <Search size={15} className="absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search action, admin, or target..."
            className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
              <tr>
                <th className="p-4">Timestamp</th>
                <th className="p-4">Admin</th>
                <th className="p-4">Action</th>
                <th className="p-4">Target Type</th>
                <th className="p-4">Target ID</th>
                <th className="p-4">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
              {filtered.length === 0 && !loading ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-500 font-sans text-xs">
                    No audit logs recorded yet.
                  </td>
                </tr>
              ) : (
                filtered.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-850/60 transition-colors">
                    <td className="p-4 text-slate-400 whitespace-nowrap">
                      {log.timestamp ? format(new Date(log.timestamp), 'yyyy-MM-dd HH:mm:ss') : ''}
                    </td>
                    <td className="p-4 text-amber-300 font-semibold">@{log.adminUsername}</td>
                    <td className="p-4 text-primary-400 font-semibold">{log.action}</td>
                    <td className="p-4 capitalize text-slate-300">{log.targetType}</td>
                    <td className="p-4 text-slate-400">{log.targetId}</td>
                    <td className="p-4 text-slate-400 font-sans max-w-xs truncate">
                      {log.details || '—'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

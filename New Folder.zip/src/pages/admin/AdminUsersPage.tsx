import React, { useEffect, useState } from 'react';
import { adminService } from '../../services/adminService';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/common/Toast';
import { UserProfile, UserRole, UserStatus } from '../../types';
import { Avatar } from '../../components/common/Avatar';
import { Badge } from '../../components/common/Badge';
import { VerifiedBadge } from '../../components/common/VerifiedBadge';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { Users, Search, Shield, Ban, CheckCircle, ShieldAlert, Sparkles } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export const AdminUsersPage: React.FC = () => {
  const { user, profile: currentAdmin } = useAuth();
  const { showToast } = useToast();

  const [users, setUsers] = useState<UserProfile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  // Dialog state
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [dialogAction, setDialogAction] = useState<'ban' | 'suspend' | 'unban' | 'makeAdmin' | 'removeAdmin' | null>(null);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const all = await adminService.getAllUsers();
      setUsers(all);
    } catch (err) {
      console.warn('Error fetching all users:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleRoleChange = async (targetUser: UserProfile, newRole: UserRole) => {
    if (!user || !currentAdmin) return;
    try {
      await adminService.updateUserRole(targetUser.uid, newRole, user.uid, currentAdmin.username);
      showToast(`Updated @${targetUser.username}'s role to ${newRole}`);
      fetchUsers();
    } catch {
      showToast('Error changing role.', 'error');
    }
  };

  const handleToggleVerified = async (targetUser: UserProfile) => {
    if (!user || !currentAdmin) return;
    const next = !targetUser.isVerified;
    try {
      await adminService.toggleUserVerified(targetUser.uid, next, user.uid, currentAdmin.username);
      showToast(next ? `Verified @${targetUser.username}` : `Unverified @${targetUser.username}`);
      fetchUsers();
    } catch {
      showToast('Error toggling verified status.', 'error');
    }
  };

  const handleConfirmAction = async () => {
    if (!selectedUser || !user || !currentAdmin) return;

    if (dialogAction === 'ban') {
      await adminService.updateUserStatus(selectedUser.uid, 'banned', user.uid, currentAdmin.username);
      showToast(`User @${selectedUser.username} has been banned.`);
    } else if (dialogAction === 'suspend') {
      await adminService.updateUserStatus(selectedUser.uid, 'suspended', user.uid, currentAdmin.username);
      showToast(`User @${selectedUser.username} has been suspended.`);
    } else if (dialogAction === 'unban') {
      await adminService.updateUserStatus(selectedUser.uid, 'active', user.uid, currentAdmin.username);
      showToast(`User @${selectedUser.username} has been reactivated.`);
    } else if (dialogAction === 'makeAdmin') {
      await adminService.updateUserRole(selectedUser.uid, 'admin', user.uid, currentAdmin.username);
      showToast(`Granted admin role to @${selectedUser.username}.`);
    } else if (dialogAction === 'removeAdmin') {
      await adminService.updateUserRole(selectedUser.uid, 'creator', user.uid, currentAdmin.username);
      showToast(`Removed admin role from @${selectedUser.username}.`);
    }

    setDialogAction(null);
    setSelectedUser(null);
    fetchUsers();
  };

  const filtered = users.filter(
    (u) =>
      u.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.displayName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
            <Users className="text-amber-400" />
            <span>User & Account Management</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Search, modify roles, verify creators, and enforce platform conduct.
          </p>
        </div>

        <div className="w-full sm:w-80 relative">
          <Search size={16} className="absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by username, display name, email..."
            className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* Users Table */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
              <tr>
                <th className="p-4">User</th>
                <th className="p-4">Role</th>
                <th className="p-4">Status</th>
                <th className="p-4">Verified</th>
                <th className="p-4">Joined</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map((u) => (
                <tr key={u.uid} className="hover:bg-slate-850/60 transition-colors">
                  <td className="p-4 flex items-center gap-3">
                    <Avatar src={u.avatarUrl} name={u.displayName || u.username} size="sm" />
                    <div>
                      <div className="font-heading font-semibold text-slate-100">
                        {u.displayName || u.username}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">@{u.username}</div>
                    </div>
                  </td>

                  <td className="p-4">
                    <select
                      value={u.role}
                      onChange={(e) => handleRoleChange(u, e.target.value as UserRole)}
                      className="bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-200 capitalize"
                    >
                      <option value="user">User</option>
                      <option value="creator">Creator</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>

                  <td className="p-4">
                    <Badge
                      variant={
                        u.status === 'active'
                          ? 'success'
                          : u.status === 'suspended'
                          ? 'warning'
                          : 'danger'
                      }
                      size="sm"
                      className="capitalize"
                    >
                      {u.status}
                    </Badge>
                  </td>

                  <td className="p-4">
                    <button
                      onClick={() => handleToggleVerified(u)}
                      className={`text-xs font-semibold px-2 py-1 rounded border transition-colors ${
                        u.isVerified
                          ? 'bg-primary-500/20 text-primary-300 border-primary-500/40'
                          : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                      }`}
                    >
                      {u.isVerified ? 'Verified ✓' : 'Unverified'}
                    </button>
                  </td>

                  <td className="p-4 text-slate-400 font-mono text-[11px]">
                    {u.joinedAt ? formatDistanceToNow(new Date(u.joinedAt), { addSuffix: true }) : ''}
                  </td>

                  <td className="p-4 text-right space-x-2">
                    {u.status === 'active' ? (
                      <>
                        <button
                          onClick={() => {
                            setSelectedUser(u);
                            setDialogAction('suspend');
                          }}
                          className="px-2.5 py-1 rounded bg-amber-950/40 hover:bg-amber-900/40 border border-amber-800/60 text-amber-300 text-[11px] font-semibold"
                        >
                          Suspend
                        </button>
                        <button
                          onClick={() => {
                            setSelectedUser(u);
                            setDialogAction('ban');
                          }}
                          className="px-2.5 py-1 rounded bg-rose-950/40 hover:bg-rose-900/40 border border-rose-800/60 text-rose-300 text-[11px] font-semibold"
                        >
                          Ban
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => {
                          setSelectedUser(u);
                          setDialogAction('unban');
                        }}
                        className="px-2.5 py-1 rounded bg-emerald-950/40 hover:bg-emerald-900/40 border border-emerald-800/60 text-emerald-300 text-[11px] font-semibold"
                      >
                        Reactivate
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Confirmation Dialog */}
      {selectedUser && dialogAction && (
        <ConfirmDialog
          isOpen={Boolean(selectedUser && dialogAction)}
          onClose={() => {
            setSelectedUser(null);
            setDialogAction(null);
          }}
          onConfirm={handleConfirmAction}
          title={
            dialogAction === 'ban'
              ? `Ban @${selectedUser.username}?`
              : dialogAction === 'suspend'
              ? `Suspend @${selectedUser.username}?`
              : `Reactivate @${selectedUser.username}?`
          }
          message={
            dialogAction === 'ban'
              ? `Are you sure you want to ban @${selectedUser.username}? Banned users cannot publish, download, or access dashboards.`
              : dialogAction === 'suspend'
              ? `Suspended users will have read-only access to the platform.`
              : `This will restore full active permissions for @${selectedUser.username}.`
          }
          isDestructive={dialogAction === 'ban' || dialogAction === 'suspend'}
          confirmText={dialogAction === 'ban' ? 'Ban User' : 'Confirm'}
        />
      )}
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { adminService } from '../../services/adminService';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/common/Toast';
import { ProjectItem, ProjectStatus } from '../../types';
import { Badge } from '../../components/common/Badge';
import { VerifiedBadge } from '../../components/common/VerifiedBadge';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { Box, Search, Star, ShieldCheck, Eye, Trash2, RotateCcw } from 'lucide-react';
import { Link } from 'react-router-dom';

export const AdminProjectsPage: React.FC = () => {
  const { user, profile: currentAdmin } = useAuth();
  const { showToast } = useToast();

  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [projectToDelete, setProjectToDelete] = useState<ProjectItem | null>(null);

  const fetchProjects = async () => {
    setLoading(true);
    try {
      const all = await adminService.getAllProjects();
      setProjects(all);
    } catch (err) {
      console.warn('Error fetching admin projects:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const handleToggleFeatured = async (p: ProjectItem) => {
    if (!user) return;
    const adminName = currentAdmin?.username || user.displayName || user.email?.split('@')[0] || 'admin';
    const next = !p.featured;
    setProjects((prev) =>
      prev.map((item) => (item.id === p.id ? { ...item, featured: next } : item))
    );
    try {
      await adminService.toggleProjectFeatured(p.id, next, user.uid, adminName);
      showToast(next ? `Featured "${p.title}"` : `Unfeatured "${p.title}"`, 'success');
      fetchProjects();
    } catch (err: any) {
      console.error('Error toggling featured:', err);
      showToast(err?.message || 'Error toggling featured status.', 'error');
      fetchProjects();
    }
  };

  const handleToggleVerified = async (p: ProjectItem) => {
    if (!user) return;
    const adminName = currentAdmin?.username || user.displayName || user.email?.split('@')[0] || 'admin';
    const next = !p.verified;
    setProjects((prev) =>
      prev.map((item) => (item.id === p.id ? { ...item, verified: next } : item))
    );
    try {
      await adminService.toggleProjectVerified(p.id, next, user.uid, adminName);
      showToast(next ? `Verified badge added to "${p.title}"` : `Removed verified badge`, 'success');
      fetchProjects();
    } catch (err: any) {
      console.error('Error updating verification:', err);
      showToast(err?.message || 'Error updating verification.', 'error');
      fetchProjects();
    }
  };

  const handleStatusChange = async (p: ProjectItem, newStatus: ProjectStatus) => {
    if (!user) return;
    const adminName = currentAdmin?.username || user.displayName || user.email?.split('@')[0] || 'admin';
    // Optimistic UI update
    setProjects((prev) =>
      prev.map((item) => (item.id === p.id ? { ...item, status: newStatus } : item))
    );
    try {
      await adminService.moderateProject(
        p.id,
        newStatus,
        user.uid,
        adminName,
        `Admin changed status to ${newStatus}`
      );
      showToast(`Updated status to ${newStatus}`, 'success');
      fetchProjects();
    } catch (err: any) {
      console.error('Error updating status:', err);
      showToast(err?.message || 'Error updating project status.', 'error');
      fetchProjects(); // Revert back
    }
  };

  const confirmDeleteProject = async () => {
    if (!projectToDelete || !user) return;
    const adminName = currentAdmin?.username || user.displayName || user.email?.split('@')[0] || 'admin';
    try {
      await adminService.deleteProject(
        projectToDelete.id,
        user.uid,
        adminName,
        projectToDelete.title
      );
      showToast(`Permanently deleted project "${projectToDelete.title}"`, 'success');
      setProjects((prev) => prev.filter((p) => p.id !== projectToDelete.id));
    } catch (err: any) {
      console.error('Error deleting project:', err);
      showToast(err?.message || 'Failed to delete project.', 'error');
    } finally {
      setProjectToDelete(null);
    }
  };

  const filtered = projects.filter((p) => {
    const matchesSearch =
      p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.slug.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.creatorUsername.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
            <Box className="text-amber-400" />
            <span>All Projects Directory</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Manage visibility, verified badges, homepage feature priorities, and content lifecycle.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-full sm:w-64 relative">
            <Search size={15} className="absolute left-3.5 top-3 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search title, slug, creator..."
              className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-amber-500"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200"
          >
            <option value="all">All Statuses</option>
            <option value="approved">Approved</option>
            <option value="pending_review">Pending Review</option>
            <option value="draft">Draft</option>
            <option value="rejected">Rejected</option>
            <option value="suspended">Suspended</option>
          </select>
        </div>
      </div>

      <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
              <tr>
                <th className="p-4">Project</th>
                <th className="p-4">Creator</th>
                <th className="p-4">Type</th>
                <th className="p-4">Status</th>
                <th className="p-4">Featured</th>
                <th className="p-4">Verified</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map((p) => (
                <tr key={p.id} className="hover:bg-slate-850/60 transition-colors">
                  <td className="p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-slate-800 shrink-0 overflow-hidden flex items-center justify-center">
                      {p.iconUrl ? (
                        <img src={p.iconUrl} alt={p.title} className="w-full h-full object-cover" />
                      ) : (
                        <Box size={20} className="text-amber-400" />
                      )}
                    </div>
                    <div>
                      <Link
                        to={`/project/${p.slug}`}
                        className="font-heading font-semibold text-slate-100 hover:text-amber-400"
                      >
                        {p.title}
                      </Link>
                      <div className="text-[11px] text-slate-500 font-mono">/{p.slug}</div>
                    </div>
                  </td>

                  <td className="p-4 font-mono text-slate-400">@{p.creatorUsername}</td>

                  <td className="p-4 uppercase text-[10px] font-mono text-primary-400">
                    {p.resourceTypeId}
                  </td>

                  <td className="p-4">
                    <select
                      value={p.status}
                      onChange={(e) => handleStatusChange(p, e.target.value as ProjectStatus)}
                      className="bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-200 capitalize font-medium"
                    >
                      <option value="approved">Approved</option>
                      <option value="pending_review">Pending</option>
                      <option value="draft">Draft</option>
                      <option value="rejected">Rejected</option>
                      <option value="suspended">Suspended</option>
                      <option value="archived">Archived</option>
                    </select>
                  </td>

                  <td className="p-4">
                    <button
                      onClick={() => handleToggleFeatured(p)}
                      className={`p-1.5 rounded-lg border transition-colors ${
                        p.featured
                          ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                          : 'bg-slate-800 border-slate-700 text-slate-500 hover:text-white'
                      }`}
                      title={p.featured ? 'Featured on Homepage' : 'Not Featured'}
                    >
                      <Star size={15} className={p.featured ? 'fill-amber-300' : ''} />
                    </button>
                  </td>

                  <td className="p-4">
                    <button
                      onClick={() => handleToggleVerified(p)}
                      className={`text-xs font-semibold px-2 py-1 rounded border transition-colors ${
                        p.verified
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                      }`}
                    >
                      {p.verified ? 'Verified ✓' : 'Unverified'}
                    </button>
                  </td>

                  <td className="p-4 text-right space-x-2 whitespace-nowrap">
                    <Link
                      to={`/project/${p.slug}`}
                      className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white inline-block transition-colors"
                      title="Inspect Project"
                    >
                      <Eye size={14} />
                    </Link>
                    <button
                      onClick={() => setProjectToDelete(p)}
                      className="p-1.5 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-200 border border-rose-500/30 transition-colors inline-block"
                      title="Delete Project Permanently"
                    >
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      {projectToDelete && (
        <ConfirmDialog
          isOpen={Boolean(projectToDelete)}
          onClose={() => setProjectToDelete(null)}
          onConfirm={confirmDeleteProject}
          title="Delete Project Permanently"
          message={`Are you sure you want to permanently delete "${projectToDelete.title}" (slug: /${projectToDelete.slug})? All associated version files, downloads, and metadata will be permanently removed. This action cannot be reversed.`}
          confirmText="Delete Project"
          cancelText="Cancel"
          isDestructive={true}
        />
      )}
    </div>
  );
};

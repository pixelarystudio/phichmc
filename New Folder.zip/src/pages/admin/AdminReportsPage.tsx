import React, { useEffect, useState } from 'react';
import { adminService } from '../../services/adminService';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/common/Toast';
import { ReportItem } from '../../types';
import { Badge } from '../../components/common/Badge';
import { AlertOctagon, CheckCircle2, XCircle, Search } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export const AdminReportsPage: React.FC = () => {
  const { user, profile } = useAuth();
  const { showToast } = useToast();

  const [reports, setReports] = useState<ReportItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'resolved'>('pending');

  const fetchReports = async () => {
    setLoading(true);
    try {
      const items = await adminService.getReports();
      setReports(items);
    } catch (err) {
      console.warn('Error fetching reports:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  const handleResolve = async (reportId: string, decision: 'resolved' | 'dismissed') => {
    if (!user || !profile) return;
    try {
      await adminService.resolveReport(
        reportId,
        decision,
        user.uid,
        profile.username,
        `Marked as ${decision} by ${profile.username}`
      );
      showToast(`Report ${decision}!`);
      fetchReports();
    } catch {
      showToast('Error resolving report.', 'error');
    }
  };

  const filtered = reports.filter((r) => {
    if (filter === 'all') return true;
    return r.status === filter;
  });

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
            <AlertOctagon className="text-rose-400" />
            <span>Community Reports & DMCA Claims</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Investigate copyright flags, malware reports, and content violations.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
          {['pending', 'resolved', 'all'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f as any)}
              className={`px-3 py-1.5 rounded-lg capitalize transition-colors font-medium ${
                filter === f
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {filtered.length === 0 && !loading ? (
          <div className="p-16 rounded-3xl bg-slate-900 border border-slate-800 text-center text-slate-400 text-xs">
            <CheckCircle2 size={32} className="text-emerald-400 mx-auto mb-2" />
            <p className="font-semibold text-slate-200">No reports in this queue.</p>
          </div>
        ) : (
          filtered.map((report) => (
            <div
              key={report.id}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 text-xs"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge variant="danger" size="sm" className="uppercase font-mono">
                    {report.reason}
                  </Badge>
                  <span className="font-heading font-semibold text-white">
                    Target: {report.targetName || report.targetId} ({report.targetType})
                  </span>
                </div>
                <span className="text-[11px] text-slate-500 font-mono">
                  {report.createdAt ? formatDistanceToNow(new Date(report.createdAt), { addSuffix: true }) : ''}
                </span>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl space-y-1">
                <div className="text-slate-400">
                  Reported by: <span className="text-slate-200 font-mono">@{report.reporterUsername}</span>
                </div>
                <div className="text-slate-300 leading-relaxed">{report.details || 'No extra details provided.'}</div>
              </div>

              {report.status === 'pending' ? (
                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    onClick={() => handleResolve(report.id, 'dismissed')}
                    className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
                  >
                    Dismiss Report
                  </button>
                  <button
                    onClick={() => handleResolve(report.id, 'resolved')}
                    className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-semibold"
                  >
                    Mark Resolved (Action Taken)
                  </button>
                </div>
              ) : (
                <div className="text-[11px] text-slate-500">
                  Status: <span className="capitalize text-slate-400 font-semibold">{report.status}</span>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

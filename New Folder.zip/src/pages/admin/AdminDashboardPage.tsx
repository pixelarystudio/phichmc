import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { adminService } from '../../services/adminService';
import { useSiteConfig } from '../../contexts/SiteConfigContext';
import {
  Users,
  Box,
  FileCheck2,
  AlertOctagon,
  Download,
  Eye,
  Shield,
  DollarSign,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { formatCount } from '../../components/common/ResourceCard';
import { Badge } from '../../components/common/Badge';

export const AdminDashboardPage: React.FC = () => {
  const { settings } = useSiteConfig();
  const [stats, setStats] = useState({
    totalUsers: 0,
    creators: 0,
    publishedProjects: 0,
    pendingProjects: 0,
    pendingReports: 0,
    pendingCreatorApps: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAdminOverview = async () => {
      setLoading(true);
      try {
        const [users, projects, reports, creatorApps] = await Promise.all([
          adminService.getAllUsers(),
          adminService.getAllProjects(),
          adminService.getReports(),
          adminService.getCreatorApplications(),
        ]);

        setStats({
          totalUsers: users.length,
          creators: users.filter((u) => u.isCreator || u.role === 'creator').length,
          publishedProjects: projects.filter((p) => p.status === 'approved').length,
          pendingProjects: projects.filter((p) => p.status === 'pending_review').length,
          pendingReports: reports.filter((r) => r.status === 'pending').length,
          pendingCreatorApps: creatorApps.filter((a) => a.status === 'pending').length,
        });
      } catch (err) {
        console.warn('Error loading admin overview stats:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchAdminOverview();
  }, []);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2.5">
            <Shield className="text-amber-400" />
            <span>Platform Administration Console</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time telemetry, moderation queues, user roles, and platform settings.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {settings.maintenanceMode && (
            <Badge variant="warning" size="md">
              Maintenance Mode Active
            </Badge>
          )}
          <Badge variant={settings.adsEnabled ? 'success' : 'neutral'} size="md">
            Ads {settings.adsEnabled ? 'Enabled' : 'Disabled'}
          </Badge>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Pending Moderation */}
        <Link
          to="/admin/moderation"
          className="p-5 rounded-2xl bg-amber-950/20 border border-amber-900/40 hover:border-amber-500/50 transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between text-xs text-amber-300">
            <span>Pending Reviews</span>
            <FileCheck2 size={16} />
          </div>
          <div className="text-2xl sm:text-3xl font-heading font-bold text-white group-hover:text-amber-300 transition-colors">
            {stats.pendingProjects}
          </div>
          <div className="text-[11px] text-amber-400/80">Projects awaiting approval</div>
        </Link>

        {/* Pending Reports */}
        <Link
          to="/admin/reports"
          className="p-5 rounded-2xl bg-rose-950/20 border border-rose-900/40 hover:border-rose-500/50 transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between text-xs text-rose-300">
            <span>Pending Reports</span>
            <AlertOctagon size={16} />
          </div>
          <div className="text-2xl sm:text-3xl font-heading font-bold text-white group-hover:text-rose-300 transition-colors">
            {stats.pendingReports}
          </div>
          <div className="text-[11px] text-rose-400/80">User complaints & DMCA flags</div>
        </Link>

        {/* Creator Applications */}
        <Link
          to="/admin/moderation"
          className="p-5 rounded-2xl bg-primary-950/20 border border-primary-900/40 hover:border-primary-500/50 transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between text-xs text-primary-300">
            <span>Creator Applications</span>
            <Users size={16} />
          </div>
          <div className="text-2xl sm:text-3xl font-heading font-bold text-white group-hover:text-primary-300 transition-colors">
            {stats.pendingCreatorApps}
          </div>
          <div className="text-[11px] text-primary-400/80">Requests for creator role</div>
        </Link>

        {/* Published Projects */}
        <Link
          to="/admin/projects"
          className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Approved Projects</span>
            <Box size={16} className="text-emerald-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-heading font-bold text-white">
            {stats.publishedProjects}
          </div>
          <div className="text-[11px] text-slate-500">Live on platform</div>
        </Link>
      </div>

      {/* Quick Action Hub */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="font-heading font-bold text-sm text-slate-200">Quick Administrative Hub</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <Link
            to="/admin/moderation"
            className="flex items-center justify-between p-4 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-800 text-xs font-semibold text-slate-200 transition-colors"
          >
            <span>Process Moderation Queue</span>
            <ArrowRight size={14} className="text-primary-400" />
          </Link>

          <Link
            to="/admin/users"
            className="flex items-center justify-between p-4 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-800 text-xs font-semibold text-slate-200 transition-colors"
          >
            <span>Manage User Roles & Bans</span>
            <ArrowRight size={14} className="text-primary-400" />
          </Link>

          <Link
            to="/admin/ads"
            className="flex items-center justify-between p-4 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-800 text-xs font-semibold text-slate-200 transition-colors"
          >
            <span>Adsterra & Ads Control</span>
            <ArrowRight size={14} className="text-primary-400" />
          </Link>
        </div>
      </div>
    </div>
  );
};

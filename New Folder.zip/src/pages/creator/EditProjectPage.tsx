import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/common/Toast';
import { projectService } from '../../services/projectService';
import { ProjectItem } from '../../types';
import { Save, ArrowLeft, Box } from 'lucide-react';

export const EditProjectPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user, isAdmin } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [project, setProject] = useState<ProjectItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Form Fields
  const [title, setTitle] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [description, setDescription] = useState('');
  const [iconUrl, setIconUrl] = useState('');
  const [gallery, setGallery] = useState('');
  const [sourceUrl, setSourceUrl] = useState('');
  const [issuesUrl, setIssuesUrl] = useState('');
  const [wikiUrl, setWikiUrl] = useState('');
  const [discordUrl, setDiscordUrl] = useState('');

  useEffect(() => {
    if (!id) return;
    const fetch = async () => {
      setLoading(true);
      try {
        const p = await projectService.getProjectById(id);
        if (p) {
          if (user && p.creatorId !== user.uid && !isAdmin) {
            showToast('Unauthorized: You do not own this project.', 'error');
            navigate('/dashboard/projects', { replace: true });
            return;
          }
          setProject(p);
          setTitle(p.title);
          setShortDescription(p.shortDescription);
          setDescription(p.description);
          setIconUrl(p.iconUrl || '');
          setGallery(p.gallery?.join('\n') || '');
          setSourceUrl(p.links?.source || '');
          setIssuesUrl(p.links?.issues || '');
          setWikiUrl(p.links?.wiki || '');
          setDiscordUrl(p.links?.discord || '');
        }
      } catch (err: any) {
        showToast(err.message || 'Error loading project', 'error');
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [id, user, isAdmin, navigate]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!project || !user) return;
    if (project.creatorId !== user.uid && !isAdmin) {
      showToast('Unauthorized: You do not have permission to edit this project.', 'error');
      return;
    }

    setSaving(true);
    try {
      const galleryList = gallery
        .split('\n')
        .map((g) => g.trim())
        .filter((g) => g.length > 0);

      const updated: ProjectItem = {
        ...project,
        title: title.trim(),
        shortDescription: shortDescription.trim(),
        description: description.trim(),
        iconUrl: iconUrl.trim() || undefined,
        gallery: galleryList,
        links: {
          source: sourceUrl.trim() || undefined,
          issues: issuesUrl.trim() || undefined,
          wiki: wikiUrl.trim() || undefined,
          discord: discordUrl.trim() || undefined,
        },
        updatedAt: new Date().toISOString(),
      };

      await projectService.saveProject(updated);
      showToast('Project updated successfully!');
      navigate('/dashboard/projects');
    } catch {
      showToast('Error saving project.', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto py-12 animate-pulse space-y-4">
        <div className="h-8 bg-slate-800 rounded w-48" />
        <div className="h-96 bg-slate-900 rounded-3xl" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="text-center py-20 text-slate-400">
        Project not found.
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      <button
        onClick={() => navigate('/dashboard/projects')}
        className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white"
      >
        <ArrowLeft size={14} />
        <span>Back to Projects</span>
      </button>

      <div className="pb-4 border-b border-slate-800 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-heading font-extrabold text-white">
            Edit: {project.title}
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">Slug: {project.slug}</p>
        </div>
      </div>

      <form onSubmit={handleSave} className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-5 text-xs">
        <div>
          <label className="block text-slate-300 font-semibold mb-1">Project Title</label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-100 text-sm font-semibold"
          />
        </div>

        <div>
          <label className="block text-slate-300 font-semibold mb-1">Short Description</label>
          <input
            type="text"
            required
            value={shortDescription}
            onChange={(e) => setShortDescription(e.target.value)}
            className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
          />
        </div>

        <div>
          <label className="block text-slate-300 font-semibold mb-1">Full Description (Markdown)</label>
          <textarea
            rows={8}
            required
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 font-mono text-xs"
          />
        </div>

        <div>
          <label className="block text-slate-300 font-semibold mb-1">Project Icon URL</label>
          <input
            type="url"
            value={iconUrl}
            onChange={(e) => setIconUrl(e.target.value)}
            className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
          />
        </div>

        <div>
          <label className="block text-slate-300 font-semibold mb-1">
            Gallery Screenshot URLs (one per line)
          </label>
          <textarea
            rows={4}
            value={gallery}
            onChange={(e) => setGallery(e.target.value)}
            className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 font-mono text-[11px]"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-slate-800">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Source Code URL</label>
            <input
              type="url"
              value={sourceUrl}
              onChange={(e) => setSourceUrl(e.target.value)}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
            />
          </div>
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Issue Tracker URL</label>
            <input
              type="url"
              value={issuesUrl}
              onChange={(e) => setIssuesUrl(e.target.value)}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
            />
          </div>
        </div>

        <div className="flex justify-end pt-4">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 px-6 py-2.5 bg-primary-600 hover:bg-primary-500 text-white rounded-xl font-semibold shadow-md transition-all"
          >
            <Save size={15} />
            <span>{saving ? 'Saving...' : 'Save Changes'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};

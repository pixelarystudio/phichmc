import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useSiteConfig } from '../../contexts/SiteConfigContext';
import { useToast } from '../../components/common/Toast';
import { projectService } from '../../services/projectService';
import { ProjectItem, ProjectVersion, ReleaseType, ProjectStatus } from '../../types';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import {
  HardDrive,
  Plus,
  ArrowLeft,
  Download,
  Pencil,
  Trash2,
  FileCode,
  Clock,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';

export const ProjectVersionsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();
  const { minecraftVersions, loaders } = useSiteConfig();
  const { showToast } = useToast();

  const [project, setProject] = useState<ProjectItem | null>(null);
  const [versions, setVersions] = useState<ProjectVersion[]>([]);
  const [loading, setLoading] = useState(true);

  // New Version Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [versionNumber, setVersionNumber] = useState('');
  const [versionName, setVersionName] = useState('');
  const [releaseType, setReleaseType] = useState<ReleaseType>('release');
  const [selectedVersions, setSelectedVersions] = useState<string[]>(['1.21.4']);
  const [selectedLoaders, setSelectedLoaders] = useState<string[]>(['fabric']);
  const [fileName, setFileName] = useState('');
  const [fileUrl, setFileUrl] = useState('');
  const [fileSizeMb, setFileSizeMb] = useState('3.5');
  const [changelog, setChangelog] = useState('');
  const [versionStatus, setVersionStatus] = useState<ProjectStatus>('approved');
  const [saving, setSaving] = useState(false);

  // Edit Version Modal State
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingVersion, setEditingVersion] = useState<ProjectVersion | null>(null);
  const [editVersionNumber, setEditVersionNumber] = useState('');
  const [editVersionName, setEditVersionName] = useState('');
  const [editReleaseType, setEditReleaseType] = useState<ReleaseType>('release');
  const [editSelectedVersions, setEditSelectedVersions] = useState<string[]>([]);
  const [editSelectedLoaders, setEditSelectedLoaders] = useState<string[]>([]);
  const [editFileName, setEditFileName] = useState('');
  const [editFileUrl, setEditFileUrl] = useState('');
  const [editFileSizeMb, setEditFileSizeMb] = useState('3.5');
  const [editChangelog, setEditChangelog] = useState('');
  const [editStatus, setEditStatus] = useState<ProjectStatus>('pending_review');

  // Delete Confirm State
  const [versionToDelete, setVersionToDelete] = useState<ProjectVersion | null>(null);

  const fetchProjectData = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const p = await projectService.getProjectById(id);
      if (p) {
        if (user && p.creatorId !== user.uid && !isAdmin) {
          showToast('Unauthorized: You do not own this project.', 'error');
          navigate('/dashboard/projects', { replace: true });
          return;
        }
        setProject(p);
        // Load all versions (including pending_review and draft) for creator
        const v = await projectService.getProjectVersions(p.id, false);
        setVersions(v);
      }
    } catch (err: any) {
      console.error('Error loading project versions:', err);
      showToast(err?.message || 'Error loading project versions', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjectData();
  }, [id, user, isAdmin]);

  const toggleSelection = (list: string[], item: string, setter: (val: string[]) => void) => {
    if (list.includes(item)) {
      setter(list.filter((x) => x !== item));
    } else {
      setter([...list, item]);
    }
  };

  // Open Edit Modal and prefill form
  const handleOpenEdit = (ver: ProjectVersion) => {
    setEditingVersion(ver);
    setEditVersionNumber(ver.versionNumber || '');
    setEditVersionName(ver.name || '');
    setEditReleaseType(ver.releaseType || 'release');
    setEditSelectedVersions(ver.minecraftVersions || []);
    setEditSelectedLoaders(ver.loaders || []);
    const file = ver.files?.[0];
    setEditFileName(file?.fileName || '');
    setEditFileUrl(file?.downloadUrl || '');
    setEditFileSizeMb(file?.fileSize ? (file.fileSize / (1024 * 1024)).toFixed(1) : '3.5');
    setEditChangelog(ver.changelog || '');
    setEditStatus(ver.status || 'pending_review');
    setEditModalOpen(true);
  };

  // Create Version Handler
  const handleCreateVersion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!project) return;

    if (selectedVersions.length === 0) {
      showToast('Please select at least one Minecraft version.', 'error');
      return;
    }
    if (selectedLoaders.length === 0) {
      showToast('Please select at least one loader.', 'error');
      return;
    }

    setSaving(true);
    try {
      const versionId = `v_${Date.now()}`;
      const sizeBytes = Math.round(parseFloat(fileSizeMb || '1') * 1024 * 1024);

      const finalStatus: ProjectStatus = versionStatus === 'draft' ? 'draft' : 'approved';

      const newVersion: ProjectVersion = {
        id: versionId,
        projectId: project.id,
        versionNumber: versionNumber.trim(),
        name: versionName.trim() || `Version ${versionNumber}`,
        releaseType,
        changelog: changelog.trim(),
        minecraftVersions: selectedVersions,
        loaders: selectedLoaders,
        files: [
          {
            fileId: `file_${Date.now()}`,
            fileName: fileName.trim() || `${project.slug}-${versionNumber}.jar`,
            fileSize: sizeBytes,
            downloadUrl: fileUrl.trim() || 'https://github.com/phichmc/demo-files/raw/main/sample.jar',
            primary: true,
          },
        ],
        dependencies: [],
        status: finalStatus,
        downloadCount: 0,
        publishedAt: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      };

      await projectService.addProjectVersion(project.id, newVersion);
      showToast(
        finalStatus === 'approved'
          ? 'Version published and live to the public!'
          : 'Version saved as draft.',
        'success'
      );

      // Reset form
      setVersionNumber('');
      setVersionName('');
      setFileName('');
      setFileUrl('');
      setChangelog('');
      setModalOpen(false);
      fetchProjectData();
    } catch (err: any) {
      console.error('Error adding version:', err);
      showToast(err?.message || 'Failed to add version.', 'error');
    } finally {
      setSaving(false);
    }
  };

  // One-click publish for pending review or draft versions
  const handlePublishNow = async (ver: ProjectVersion) => {
    if (!project) return;
    try {
      await projectService.updateProjectVersion(project.id, ver.id, {
        status: 'approved',
        publishedAt: new Date().toISOString(),
      });
      showToast(`Version v${ver.versionNumber} is now live and published!`, 'success');
      fetchProjectData();
    } catch (err: any) {
      console.error('Failed to publish version:', err);
      showToast(err?.message || 'Failed to publish version.', 'error');
    }
  };

  // Update Version Handler
  const handleUpdateVersion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!project || !editingVersion) return;

    if (editSelectedVersions.length === 0) {
      showToast('Please select at least one Minecraft version.', 'error');
      return;
    }
    if (editSelectedLoaders.length === 0) {
      showToast('Please select at least one loader.', 'error');
      return;
    }

    setSaving(true);
    try {
      const sizeBytes = Math.round(parseFloat(editFileSizeMb || '1') * 1024 * 1024);
      const existingFile = editingVersion.files?.[0];
      const finalStatus: ProjectStatus = editStatus === 'draft' ? 'draft' : 'approved';

      const updates: Partial<ProjectVersion> = {
        versionNumber: editVersionNumber.trim(),
        name: editVersionName.trim() || `Version ${editVersionNumber}`,
        releaseType: editReleaseType,
        changelog: editChangelog.trim(),
        minecraftVersions: editSelectedVersions,
        loaders: editSelectedLoaders,
        files: [
          {
            fileId: existingFile?.fileId || `file_${Date.now()}`,
            fileName: editFileName.trim() || `${project.slug}-${editVersionNumber}.jar`,
            fileSize: sizeBytes,
            downloadUrl: editFileUrl.trim() || existingFile?.downloadUrl || '',
            primary: true,
          },
        ],
        status: finalStatus,
      };

      await projectService.updateProjectVersion(project.id, editingVersion.id, updates);
      showToast(
        finalStatus === 'approved'
          ? 'Version published and live to public!'
          : 'Version saved as draft.',
        'success'
      );
      setEditModalOpen(false);
      setEditingVersion(null);
      fetchProjectData();
    } catch (err: any) {
      console.error('Failed to update version:', err);
      showToast(err?.message || 'Failed to update version.', 'error');
    } finally {
      setSaving(false);
    }
  };

  // Delete Version Handler
  const handleDeleteVersion = async () => {
    if (!project || !versionToDelete) return;
    try {
      await projectService.deleteProjectVersion(project.id, versionToDelete.id);
      showToast(`Deleted version v${versionToDelete.versionNumber}`, 'success');
      setVersions((prev) => prev.filter((v) => v.id !== versionToDelete.id));
    } catch (err: any) {
      console.error('Failed to delete version:', err);
      showToast(err?.message || 'Failed to delete version.', 'error');
    } finally {
      setVersionToDelete(null);
    }
  };

  const getStatusBadge = (status: ProjectStatus) => {
    switch (status) {
      case 'approved':
        return <Badge variant="success" size="sm">Approved</Badge>;
      case 'pending_review':
        return <Badge variant="warning" size="sm">Under Review</Badge>;
      case 'draft':
        return <Badge variant="neutral" size="sm">Draft</Badge>;
      case 'rejected':
        return <Badge variant="danger" size="sm">Rejected</Badge>;
      case 'archived':
        return <Badge variant="neutral" size="sm">Archived</Badge>;
      default:
        return <Badge variant="neutral" size="sm">{status}</Badge>;
    }
  };

  if (loading) {
    return <div className="p-12 text-center text-slate-400">Loading versions...</div>;
  }

  if (!project) {
    return <div className="p-12 text-center text-slate-400">Project not found.</div>;
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <Link
        to="/dashboard/projects"
        className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
      >
        <ArrowLeft size={14} />
        <span>Back to Projects</span>
      </Link>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-heading font-extrabold text-white flex items-center gap-2">
            <HardDrive className="text-primary-400" />
            <span>Manage Versions: {project.title}</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Publish updates, edit version specifications, upload Minecraft jars, and maintain changelogs.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2.5 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-primary-950 transition-all hover:scale-[1.02]"
        >
          <Plus size={16} />
          <span>Upload New Version</span>
        </button>
      </div>

      {/* Version List */}
      <div className="space-y-4">
        {versions.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-slate-900 border border-slate-800 text-slate-400 text-xs">
            No versions uploaded yet. Click "Upload New Version" to publish your first file.
          </div>
        ) : (
          versions.map((ver) => {
            const file = ver.files?.[0];
            const sizeDisplay = file?.fileSize
              ? (file.fileSize / (1024 * 1024)).toFixed(1) + ' MB'
              : 'Unknown size';

            return (
              <div
                key={ver.id}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 hover:border-slate-700 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-heading font-semibold text-base text-white">
                      {ver.name}
                    </h3>
                    <Badge variant={ver.releaseType === 'release' ? 'success' : 'warning'} size="sm">
                      {ver.releaseType}
                    </Badge>
                    <span className="font-mono text-xs text-primary-400 font-semibold">
                      v{ver.versionNumber}
                    </span>
                    {getStatusBadge(ver.status)}
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 text-xs text-slate-400 font-mono mr-2">
                      <Download size={14} className="text-primary-400" />
                      <span>{ver.downloadCount || 0} downloads</span>
                    </div>

                    {ver.status !== 'approved' && (
                      <button
                        onClick={() => handlePublishNow(ver)}
                        className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors flex items-center gap-1 text-xs px-2.5 font-semibold shadow-md shadow-emerald-950"
                        title="Publish Version Directly (Live to Public)"
                      >
                        <CheckCircle2 size={13} />
                        <span>Publish Now</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleOpenEdit(ver)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors flex items-center gap-1 text-xs px-2.5 font-medium border border-slate-700"
                      title="Edit Version"
                    >
                      <Pencil size={13} />
                      <span>Edit</span>
                    </button>

                    <button
                      onClick={() => setVersionToDelete(ver)}
                      className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 transition-colors flex items-center gap-1 text-xs px-2.5 font-medium border border-rose-500/20"
                      title="Delete Version"
                    >
                      <Trash2 size={13} />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>

                {/* Compatibility Badges */}
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
                  <span className="text-slate-500 font-mono text-[11px]">MC:</span>
                  {ver.minecraftVersions?.map((v) => (
                    <span key={v} className="px-2 py-0.5 rounded bg-slate-800 font-mono text-[11px] text-slate-300">
                      {v}
                    </span>
                  ))}
                  <span className="text-slate-600">|</span>
                  <span className="text-slate-500 font-mono text-[11px]">Loaders:</span>
                  {ver.loaders?.map((l) => (
                    <span key={l} className="px-2 py-0.5 rounded bg-primary-950/60 border border-primary-800/40 text-primary-300 capitalize text-[11px]">
                      {l}
                    </span>
                  ))}
                </div>

                {/* File summary */}
                {file && (
                  <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400 bg-slate-950/60 p-2 rounded-lg border border-slate-800/80">
                    <FileCode size={13} className="text-primary-400" />
                    <span className="text-slate-200">{file.fileName}</span>
                    <span className="text-slate-500">({sizeDisplay})</span>
                    {file.downloadUrl && (
                      <a
                        href={file.downloadUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="ml-auto inline-flex items-center gap-1 text-primary-400 hover:text-primary-300"
                      >
                        <span>Download URL</span>
                        <ExternalLink size={11} />
                      </a>
                    )}
                  </div>
                )}

                {/* Changelog */}
                {ver.changelog && (
                  <div className="p-3 bg-slate-950/40 rounded-xl text-xs text-slate-300 whitespace-pre-wrap border border-slate-800/50">
                    {ver.changelog}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Add Version Modal */}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Upload New Version" maxWidth="lg">
        <form onSubmit={handleCreateVersion} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Version Number *</label>
              <input
                type="text"
                required
                value={versionNumber}
                onChange={(e) => setVersionNumber(e.target.value)}
                placeholder="1.2.0"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 font-mono focus:outline-none focus:border-primary-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Version Title</label>
              <input
                type="text"
                value={versionName}
                onChange={(e) => setVersionName(e.target.value)}
                placeholder="e.g. Nether Expansion Update"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Release Channel</label>
              <select
                value={releaseType}
                onChange={(e) => setReleaseType(e.target.value as ReleaseType)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
              >
                <option value="release">Release (Stable)</option>
                <option value="beta">Beta</option>
                <option value="alpha">Alpha</option>
              </select>
            </div>
          </div>

          {/* MC Versions */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1.5">Game Versions *</label>
            <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-2 bg-slate-950 rounded-xl border border-slate-800">
              {minecraftVersions.map((v) => (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => toggleSelection(selectedVersions, v.version, setSelectedVersions)}
                  className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                    selectedVersions.includes(v.version)
                      ? 'bg-primary-600 text-white font-semibold'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {v.version}
                </button>
              ))}
            </div>
          </div>

          {/* Loaders */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1.5">Loaders *</label>
            <div className="flex flex-wrap gap-1.5">
              {loaders.map((l) => (
                <button
                  key={l.id}
                  type="button"
                  onClick={() => toggleSelection(selectedLoaders, l.slug, setSelectedLoaders)}
                  className={`px-2.5 py-1 rounded-lg text-xs capitalize transition-colors ${
                    selectedLoaders.includes(l.slug)
                      ? 'bg-primary-600 text-white font-semibold'
                      : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {l.name}
                </button>
              ))}
            </div>
          </div>

          {/* File details */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <h4 className="font-semibold text-slate-200">File Specification</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 mb-1">File Name</label>
                <input
                  type="text"
                  required
                  value={fileName}
                  onChange={(e) => setFileName(e.target.value)}
                  placeholder={`${project.slug}-${versionNumber || '1.0'}.jar`}
                  className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">File Size (MB)</label>
                <input
                  type="number"
                  step="0.1"
                  value={fileSizeMb}
                  onChange={(e) => setFileSizeMb(e.target.value)}
                  className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 font-mono"
                />
              </div>
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Direct Download Link / Storage URL *</label>
              <input
                type="url"
                required
                value={fileUrl}
                onChange={(e) => setFileUrl(e.target.value)}
                placeholder="https://example.com/files/mod.jar"
                className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Changelog</label>
            <textarea
              rows={3}
              required
              value={changelog}
              onChange={(e) => setChangelog(e.target.value)}
              placeholder="What changes, bug fixes, or enhancements were added in this update?"
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
            />
          </div>

          {/* Publication State */}
          <div className="flex items-center gap-4 p-3 bg-slate-950/80 rounded-xl border border-slate-800">
            <span className="text-slate-300 font-semibold">Publish Option:</span>
            <label className="inline-flex items-center gap-1.5 cursor-pointer">
              <input
                type="radio"
                name="versionStatus"
                value="approved"
                checked={versionStatus === 'approved'}
                onChange={() => setVersionStatus('approved')}
                className="text-primary-500"
              />
              <span className="text-slate-200 font-medium">Publish Immediately (Live to Public)</span>
            </label>
            <label className="inline-flex items-center gap-1.5 cursor-pointer">
              <input
                type="radio"
                name="versionStatus"
                value="draft"
                checked={versionStatus === 'draft'}
                onChange={() => setVersionStatus('draft')}
                className="text-primary-500"
              />
              <span className="text-slate-400">Save as Draft</span>
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl font-semibold transition-colors disabled:opacity-50"
            >
              {saving ? 'Uploading...' : 'Submit Version'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Edit Version Modal */}
      <Modal isOpen={editModalOpen} onClose={() => setEditModalOpen(false)} title="Edit Version" maxWidth="lg">
        <form onSubmit={handleUpdateVersion} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Version Number *</label>
              <input
                type="text"
                required
                value={editVersionNumber}
                onChange={(e) => setEditVersionNumber(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 font-mono focus:outline-none focus:border-primary-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Version Title</label>
              <input
                type="text"
                value={editVersionName}
                onChange={(e) => setEditVersionName(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Release Channel</label>
              <select
                value={editReleaseType}
                onChange={(e) => setEditReleaseType(e.target.value as ReleaseType)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
              >
                <option value="release">Release (Stable)</option>
                <option value="beta">Beta</option>
                <option value="alpha">Alpha</option>
              </select>
            </div>
          </div>

          {/* MC Versions */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1.5">Game Versions *</label>
            <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-2 bg-slate-950 rounded-xl border border-slate-800">
              {minecraftVersions.map((v) => (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => toggleSelection(editSelectedVersions, v.version, setEditSelectedVersions)}
                  className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                    editSelectedVersions.includes(v.version)
                      ? 'bg-primary-600 text-white font-semibold'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {v.version}
                </button>
              ))}
            </div>
          </div>

          {/* Loaders */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1.5">Loaders *</label>
            <div className="flex flex-wrap gap-1.5">
              {loaders.map((l) => (
                <button
                  key={l.id}
                  type="button"
                  onClick={() => toggleSelection(editSelectedLoaders, l.slug, setEditSelectedLoaders)}
                  className={`px-2.5 py-1 rounded-lg text-xs capitalize transition-colors ${
                    editSelectedLoaders.includes(l.slug)
                      ? 'bg-primary-600 text-white font-semibold'
                      : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {l.name}
                </button>
              ))}
            </div>
          </div>

          {/* File details */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <h4 className="font-semibold text-slate-200">File Specification</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 mb-1">File Name</label>
                <input
                  type="text"
                  required
                  value={editFileName}
                  onChange={(e) => setEditFileName(e.target.value)}
                  className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">File Size (MB)</label>
                <input
                  type="number"
                  step="0.1"
                  value={editFileSizeMb}
                  onChange={(e) => setEditFileSizeMb(e.target.value)}
                  className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 font-mono"
                />
              </div>
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Direct Download Link / Storage URL *</label>
              <input
                type="url"
                required
                value={editFileUrl}
                onChange={(e) => setEditFileUrl(e.target.value)}
                className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Changelog</label>
            <textarea
              rows={3}
              required
              value={editChangelog}
              onChange={(e) => setEditChangelog(e.target.value)}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
            />
          </div>

          {/* Status option */}
          <div className="flex items-center gap-4 p-3 bg-slate-950/80 rounded-xl border border-slate-800">
            <span className="text-slate-300 font-semibold">Status:</span>
            <label className="inline-flex items-center gap-1.5 cursor-pointer">
              <input
                type="radio"
                name="editStatus"
                value="approved"
                checked={editStatus === 'approved'}
                onChange={() => setEditStatus('approved')}
                className="text-primary-500"
              />
              <span className="text-slate-200 font-medium">Published (Live to Public)</span>
            </label>
            <label className="inline-flex items-center gap-1.5 cursor-pointer">
              <input
                type="radio"
                name="editStatus"
                value="draft"
                checked={editStatus === 'draft'}
                onChange={() => setEditStatus('draft')}
                className="text-primary-500"
              />
              <span className="text-slate-400">Draft (Hidden from Public)</span>
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setEditModalOpen(false)}
              className="px-4 py-2 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl font-semibold transition-colors disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Confirm Delete Dialog */}
      <ConfirmDialog
        isOpen={Boolean(versionToDelete)}
        onClose={() => setVersionToDelete(null)}
        onConfirm={handleDeleteVersion}
        title="Delete Version"
        message={`Are you sure you want to delete version v${versionToDelete?.versionNumber}? This action cannot be undone.`}
        confirmText="Delete Version"
        isDestructive
      />
    </div>
  );
};

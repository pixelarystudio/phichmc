import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { ProjectItem, ProjectStatus } from '../../types';
import { Badge } from '../../components/common/Badge';
import { Box, Plus, Eye, Download, Users, FileEdit, HardDrive, AlertCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export const CreatorProjectsPage: React.FC = () => {
  const { user } = useAuth();
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    if (!user) return;
    const fetchProjects = async () => {
      setLoading(true);
      try {
        const q = query(collection(db, 'projects'), where('creatorId', '==', user.uid));
        const snap = await getDocs(q);
        setProjects(snap.docs.map((d) => d.data() as ProjectItem));
      } catch (err) {
        console.warn('Error fetching projects:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchProjects();
  }, [user]);

  const filtered = projects.filter((p) => {
    if (statusFilter === 'all') return true;
    return p.status === statusFilter;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white">
            My Minecraft Projects
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Track submission reviews, update versions, and manage changelogs.
          </p>
        </div>

        <Link
          to="/dashboard/projects/new"
          className="flex items-center gap-1.5 px-4 py-2.5 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-xs font-semibold shadow-md"
        >
          <Plus size={16} />
          <span>New Project</span>
        </Link>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs font-medium overflow-x-auto">
        {[
          { key: 'all', label: 'All' },
          { key: 'approved', label: 'Approved' },
          { key: 'pending_review', label: 'Pending Review' },
          { key: 'draft', label: 'Drafts' },
          { key: 'rejected', label: 'Rejected / Changes' },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setStatusFilter(tab.key)}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              statusFilter === tab.key
                ? 'bg-primary-600 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Projects List */}
      <div className="space-y-4">
        {filtered.length === 0 && !loading ? (
          <div className="p-12 rounded-2xl bg-slate-900 border border-slate-800 text-center text-slate-400 text-xs">
            No projects found in this category.
          </div>
        ) : (
          filtered.map((project) => (
            <div
              key={project.id}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-5"
            >
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-xl bg-slate-800 overflow-hidden shrink-0 flex items-center justify-center">
                  {project.iconUrl ? (
                    <img src={project.iconUrl} alt={project.title} className="w-full h-full object-cover" />
                  ) : (
                    <Box size={28} className="text-primary-400" />
                  )}
                </div>

                <div className="space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <Link
                      to={`/project/${project.slug}`}
                      className="font-heading font-semibold text-base text-white hover:text-primary-400 transition-colors"
                    >
                      {project.title}
                    </Link>
                    <Badge
                      variant={
                        project.status === 'approved'
                          ? 'success'
                          : project.status === 'pending_review'
                          ? 'warning'
                          : project.status === 'rejected'
                          ? 'danger'
                          : 'neutral'
                      }
                      size="sm"
                      className="uppercase text-[10px]"
                    >
                      {project.status}
                    </Badge>
                    <span className="text-xs text-slate-400 font-mono">
                      MC: {project.minecraftVersions?.join(', ')}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 line-clamp-1 max-w-xl">
                    {project.shortDescription}
                  </p>

                  {/* Moderation note / reason if rejected */}
                  {project.moderation?.reason && project.status === 'rejected' && (
                    <div className="flex items-center gap-1.5 text-xs text-rose-300 bg-rose-950/40 border border-rose-900/60 p-2 rounded-lg">
                      <AlertCircle size={14} className="shrink-0" />
                      <span>
                        <strong>Moderation Feedback:</strong> {project.moderation.reason}
                      </span>
                    </div>
                  )}

                  <div className="flex items-center gap-4 text-xs text-slate-500 font-mono pt-1">
                    <span>{project.downloads || 0} downloads</span>
                    <span>•</span>
                    <span>{project.views || 0} views</span>
                    <span>•</span>
                    <span>
                      Updated{' '}
                      {project.updatedAt
                        ? formatDistanceToNow(new Date(project.updatedAt), { addSuffix: true })
                        : ''}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0 w-full md:w-auto justify-end border-t md:border-t-0 border-slate-800 pt-3 md:pt-0">
                <Link
                  to={`/dashboard/projects/${project.id}/versions`}
                  className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors"
                >
                  <HardDrive size={14} />
                  <span>Versions</span>
                </Link>

                <Link
                  to={`/dashboard/projects/${project.id}/edit`}
                  className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors"
                >
                  <FileEdit size={14} />
                  <span>Edit</span>
                </Link>

                {project.status === 'approved' && (
                  <Link
                    to={`/project/${project.slug}`}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                    title="View public page"
                  >
                    <Eye size={16} />
                  </Link>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

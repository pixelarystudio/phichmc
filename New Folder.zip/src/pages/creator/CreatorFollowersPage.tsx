import React, { useEffect, useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { UserProfile } from '../../types';
import { Avatar } from '../../components/common/Avatar';
import { Users, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

export const CreatorFollowersPage: React.FC = () => {
  const { user, profile } = useAuth();
  const [followers, setFollowers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetch = async () => {
      setLoading(true);
      try {
        const snap = await getDocs(collection(db, 'users', user.uid, 'followers'));
        setFollowers(snap.docs.map((d) => d.data()));
      } catch (err) {
        console.warn('Error fetching followers:', err);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [user]);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="pb-6 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2">
          <Users className="text-primary-400" />
          <span>Creator Community & Followers</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Players who have subscribed to receive notifications when you release new project updates.
        </p>
      </div>

      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 text-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <span className="font-semibold text-slate-200">Total Followers</span>
          <span className="text-lg font-heading font-bold text-primary-400">
            {profile?.followersCount || followers.length}
          </span>
        </div>
        <p className="text-slate-400 pt-4 leading-relaxed">
          Followers are automatically notified whenever you publish an approved project update or major release.
        </p>
      </div>
    </div>
  );
};

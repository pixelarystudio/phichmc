import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { ProjectItem } from '../../types';
import { formatCount } from '../../components/common/ResourceCard';
import { Badge } from '../../components/common/Badge';
import {
  Download,
  Eye,
  Users,
  Box,
  PlusCircle,
  Clock,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export const CreatorOverviewPage: React.FC = () => {
  const { user, profile } = useAuth();
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchCreatorData = async () => {
      setLoading(true);
      try {
        const q = query(collection(db, 'projects'), where('creatorId', '==', user.uid));
        const snap = await getDocs(q);
        setProjects(snap.docs.map((d) => d.data() as ProjectItem));
      } catch (err) {
        console.warn('Error loading creator projects:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchCreatorData();
  }, [user]);

  const totalDownloads = projects.reduce((acc, p) => acc + (p.downloads || 0), 0);
  const totalViews = projects.reduce((acc, p) => acc + (p.views || 0), 0);
  const totalFollowers = projects.reduce((acc, p) => acc + (p.followers || 0), 0);

  const pendingCount = projects.filter((p) => p.status === 'pending_review').length;
  const approvedCount = projects.filter((p) => p.status === 'approved').length;

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white">
            Creator Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Welcome back, {profile?.displayName || profile?.username}. Manage your published Minecraft resources.
          </p>
        </div>

        <Link
          to="/dashboard/projects/new"
          className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all hover:scale-102"
        >
          <PlusCircle size={15} />
          <span>New Project</span>
        </Link>
      </div>

      {/* Analytics KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Downloads</span>
            <Download size={16} className="text-primary-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-heading font-bold text-white">
            {formatCount(totalDownloads)}
          </div>
          <div className="text-[11px] text-slate-500">Across all projects</div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Views</span>
            <Eye size={16} className="text-secondary-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-heading font-bold text-white">
            {formatCount(totalViews)}
          </div>
          <div className="text-[11px] text-slate-500">Unique user impressions</div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Project Followers</span>
            <Users size={16} className="text-emerald-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-heading font-bold text-white">
            {formatCount(totalFollowers)}
          </div>
          <div className="text-[11px] text-slate-500">Subscribed for version updates</div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Published Projects</span>
            <Box size={16} className="text-amber-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-heading font-bold text-white">
            {approvedCount}
          </div>
          <div className="text-[11px] text-slate-500">
            {pendingCount > 0 ? `${pendingCount} under review` : 'All projects up to date'}
          </div>
        </div>
      </div>

      {/* Recent Projects List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-bold text-base text-white">Your Recent Projects</h3>
          <Link
            to="/dashboard/projects"
            className="flex items-center gap-1 text-xs text-primary-400 hover:underline"
          >
            <span>View All</span>
            <ArrowRight size={13} />
          </Link>
        </div>

        {projects.length === 0 && !loading ? (
          <div className="p-12 rounded-2xl bg-slate-900/50 border border-slate-800 text-center space-y-3">
            <Box size={32} className="mx-auto text-slate-500" />
            <p className="text-sm text-slate-300 font-semibold">You haven't created any projects yet</p>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Ready to publish your mod or resource pack? Start your first project submission.
            </p>
            <Link
              to="/dashboard/projects/new"
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-primary-600 rounded-xl text-xs font-semibold text-white mt-2"
            >
              <PlusCircle size={14} />
              <span>Create Project</span>
            </Link>
          </div>
        ) : (
          <div className="divide-y divide-slate-800/80 rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden">
            {projects.slice(0, 5).map((project) => (
              <div
                key={project.id}
                className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-850 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-slate-800 overflow-hidden shrink-0 flex items-center justify-center">
                    {project.iconUrl ? (
                      <img src={project.iconUrl} alt={project.title} className="w-full h-full object-cover" />
                    ) : (
                      <Box size={24} className="text-primary-400" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <Link
                        to={`/project/${project.slug}`}
                        className="font-heading font-semibold text-sm text-white hover:text-primary-400 transition-colors"
                      >
                        {project.title}
                      </Link>
                      <Badge
                        variant={
                          project.status === 'approved'
                            ? 'success'
                            : project.status === 'pending_review'
                            ? 'warning'
                            : 'neutral'
                        }
                        size="sm"
                        className="uppercase text-[10px]"
                      >
                        {project.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-400 pt-1 font-mono">
                      <span>{project.downloads || 0} downloads</span>
                      <span>•</span>
                      <span>{project.followers || 0} followers</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Link
                    to={`/dashboard/projects/${project.id}/versions`}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg"
                  >
                    Versions
                  </Link>
                  <Link
                    to={`/dashboard/projects/${project.id}/edit`}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg"
                  >
                    Edit
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useSiteConfig } from '../../contexts/SiteConfigContext';
import { useToast } from '../../components/common/Toast';
import { projectService } from '../../services/projectService';
import { ProjectItem, ProjectVersion, ResourceType, MinecraftEdition, ProjectEnvironment, ReleaseType } from '../../types';
import { MarkdownRenderer } from '../../components/common/MarkdownRenderer';
import { sanitizeSlug, isReservedSlug, getSafeUrl } from '../../utils/security';
import {
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  AlertTriangle,
  Upload,
  Layers,
  FileCode,
  Link as LinkIcon,
  Eye,
  Box,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const CreateProjectPage: React.FC = () => {
  const { user, profile } = useAuth();
  const { resourceTypes, categories, loaders, minecraftVersions } = useSiteConfig();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [step, setStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);

  // Form Fields
  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [description, setDescription] = useState('');

  const [resourceTypeId, setResourceTypeId] = useState<ResourceType>('mod');
  const [editionId, setEditionId] = useState<MinecraftEdition>('java');
  const [selectedVersions, setSelectedVersions] = useState<string[]>(['1.21.4']);
  const [selectedLoaders, setSelectedLoaders] = useState<string[]>(['fabric']);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [tagsInput, setTagsInput] = useState('');
  const [environment, setEnvironment] = useState<ProjectEnvironment>('client');
  const [license, setLicense] = useState('MIT');

  // Media
  const [iconUrl, setIconUrl] = useState('');
  const [galleryInput, setGalleryInput] = useState('');

  // Links
  const [sourceUrl, setSourceUrl] = useState('');
  const [issuesUrl, setIssuesUrl] = useState('');
  const [wikiUrl, setWikiUrl] = useState('');
  const [discordUrl, setDiscordUrl] = useState('');

  // Initial Version
  const [versionNumber, setVersionNumber] = useState('1.0.0');
  const [versionName, setVersionName] = useState('Initial Release');
  const [releaseType, setReleaseType] = useState<ReleaseType>('release');
  const [fileName, setFileName] = useState('');
  const [fileUrl, setFileUrl] = useState('');
  const [fileSize, setFileSize] = useState(2500000); // 2.5 MB default
  const [changelog, setChangelog] = useState('Initial release on PHICHMC.');

  // Auto-generate slug from title
  const handleTitleChange = (val: string) => {
    setTitle(val);
    setSlug(sanitizeSlug(val));
  };

  const toggleSelection = (list: string[], item: string, setter: (val: string[]) => void) => {
    if (list.includes(item)) {
      setter(list.filter((x) => x !== item));
    } else {
      setter([...list, item]);
    }
  };

  const handleNext = () => {
    if (step === 1) {
      const cleanSlug = sanitizeSlug(slug);
      if (!title.trim() || !cleanSlug || !shortDescription.trim() || !description.trim()) {
        showToast('Please fill out all required basic information fields.', 'error');
        return;
      }
      if (cleanSlug.length < 3) {
        showToast('URL slug must be at least 3 characters long.', 'error');
        return;
      }
      if (isReservedSlug(cleanSlug)) {
        showToast(`The slug "${cleanSlug}" is reserved for platform routes. Please choose a different slug.`, 'error');
        return;
      }
    }
    if (step === 2) {
      if (selectedVersions.length === 0 || selectedLoaders.length === 0) {
        showToast('Please select at least one Minecraft version and loader.', 'error');
        return;
      }
    }
    setStep((s) => s + 1);
  };

  const handleSubmit = async (submitForReview: boolean) => {
    if (!user || !profile) return;

    const cleanSlug = sanitizeSlug(slug);
    if (!cleanSlug || cleanSlug.length < 3) {
      showToast('URL slug must be at least 3 characters.', 'error');
      return;
    }
    if (isReservedSlug(cleanSlug)) {
      showToast(`The slug "${cleanSlug}" is reserved by the system.`, 'error');
      return;
    }

    setSubmitting(true);

    try {
      // Duplicate slug check
      const existing = await projectService.getProjectBySlug(cleanSlug);
      if (existing) {
        showToast(`A project with slug "${cleanSlug}" already exists. Please choose a unique slug.`, 'error');
        setSubmitting(false);
        return;
      }

      const projectId = cleanSlug;
      const versionId = `v_${Date.now()}`;
      const finalStatus = submitForReview ? 'pending_review' : 'draft';

      const galleryList = galleryInput
        .split('\n')
        .map((s) => s.trim())
        .filter((s) => s.length > 0);

      const tagList = tagsInput
        .split(',')
        .map((t) => t.trim().toLowerCase())
        .filter((t) => t.length > 0);

      const newProject: ProjectItem = {
        id: projectId,
        slug: cleanSlug,
        title: title.trim(),
        shortDescription: shortDescription.trim(),
        description: description.trim(),
        creatorId: user.uid,
        creatorUsername: profile.username,
        creatorDisplayName: profile.displayName || profile.username,
        creatorAvatarUrl: profile.avatarUrl,
        creatorVerified: profile.isVerified,
        resourceTypeId,
        editionId,
        categoryIds: selectedCategories,
        tagIds: tagList,
        minecraftVersions: selectedVersions,
        loaders: selectedLoaders,
        environment,
        license,
        links: {
          source: getSafeUrl(sourceUrl) || undefined,
          issues: getSafeUrl(issuesUrl) || undefined,
          wiki: getSafeUrl(wikiUrl) || undefined,
          discord: getSafeUrl(discordUrl) || undefined,
        },
        iconUrl: getSafeUrl(iconUrl) || undefined,
        gallery: galleryList,
        status: finalStatus,
        verified: false,
        featured: false,
        downloads: 0,
        views: 0,
        followers: 0,
        favorites: 0,
        trendingScore: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const initialVer: ProjectVersion = {
        id: versionId,
        projectId,
        versionNumber: versionNumber.trim() || '1.0.0',
        name: versionName.trim() || 'Initial Release',
        releaseType,
        changelog: changelog.trim(),
        minecraftVersions: selectedVersions,
        loaders: selectedLoaders,
        files: [
          {
            fileId: `file_${Date.now()}`,
            fileName: fileName.trim() || `${slug.trim()}-${versionNumber.trim()}.jar`,
            fileSize,
            downloadUrl: fileUrl.trim() || 'https://github.com/phichmc/demo-files/raw/main/sample.jar',
            primary: true,
          },
        ],
        dependencies: [],
        status: finalStatus,
        downloadCount: 0,
        publishedAt: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      };

      await projectService.saveProject(newProject);
      await projectService.addProjectVersion(projectId, initialVer);

      confetti({ particleCount: 100, spread: 70 });
      showToast(
        submitForReview
          ? 'Project submitted for moderator review!'
          : 'Project saved as draft.'
      );
      navigate('/dashboard/projects');
    } catch (err: any) {
      showToast(err.message || 'Error creating project.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      {/* Wizard Header */}
      <div className="pb-6 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-heading font-extrabold text-white flex items-center gap-2.5">
          <Sparkles className="text-primary-400" />
          <span>Create New Minecraft Project</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Follow the steps below to configure your resource, upload initial files, and submit for review.
        </p>

        {/* Step Indicator */}
        <div className="flex items-center gap-2 pt-6 overflow-x-auto text-xs">
          {[
            { num: 1, label: '1. Basic Info' },
            { num: 2, label: '2. Compatibility' },
            { num: 3, label: '3. Media & Links' },
            { num: 4, label: '4. Initial Version' },
            { num: 5, label: '5. Preview & Submit' },
          ].map((s) => (
            <button
              key={s.num}
              onClick={() => setStep(s.num)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-colors ${
                step === s.num
                  ? 'bg-primary-600 text-white font-semibold'
                  : step > s.num
                  ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-800/40'
                  : 'bg-slate-900 text-slate-400'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Step 1: Basic Information */}
      {step === 1 && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-5 text-xs">
          <h2 className="text-base font-heading font-bold text-white">Project Identity</h2>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Project Title *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => handleTitleChange(e.target.value)}
              placeholder="e.g. Lumina Engine — High Performance Renderer"
              className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:border-primary-500 font-medium"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">URL Slug (unique) *</label>
            <input
              type="text"
              required
              value={slug}
              onChange={(e) => setSlug(sanitizeSlug(e.target.value))}
              placeholder="lumina-engine"
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 font-mono text-xs focus:outline-none focus:border-primary-500"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Your project will be accessible at: <code>phichmc.com/project/{slug || 'your-slug'}</code>
            </p>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Short Summary (max 155 chars) *
            </label>
            <input
              type="text"
              maxLength={160}
              required
              value={shortDescription}
              onChange={(e) => setShortDescription(e.target.value)}
              placeholder="A brief one-sentence explanation shown on cards and search results..."
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-primary-500"
            />
            <div className="text-right text-[10px] text-slate-500 mt-1">
              {shortDescription.length}/155
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Full Description (Markdown Supported) *
            </label>
            <textarea
              rows={8}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="## Overview&#10;Describe features, recipes, crafting mechanics, and installation guides using Markdown..."
              className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 font-mono text-xs focus:outline-none focus:border-primary-500"
            />
          </div>
        </div>
      )}

      {/* Step 2: Compatibility & Classification */}
      {step === 2 && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-6 text-xs">
          <h2 className="text-base font-heading font-bold text-white">Classification & Specs</h2>

          {/* Resource Type */}
          <div>
            <label className="block text-slate-300 font-semibold mb-2">Resource Type *</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {resourceTypes.map((type) => (
                <button
                  key={type.id}
                  type="button"
                  onClick={() => setResourceTypeId(type.slug)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    resourceTypeId === type.slug
                      ? 'bg-primary-600 border-primary-500 text-white font-semibold'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="font-heading font-semibold text-xs">{type.name}</div>
                  <div className="text-[10px] opacity-75 truncate">{type.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Minecraft Edition */}
          <div>
            <label className="block text-slate-300 font-semibold mb-2">Target Minecraft Edition *</label>
            <div className="flex gap-3">
              {[
                { id: 'java', label: 'Java Edition' },
                { id: 'bedrock', label: 'Bedrock Edition' },
                { id: 'both', label: 'Both / Cross-Platform' },
              ].map((ed) => (
                <button
                  key={ed.id}
                  type="button"
                  onClick={() => setEditionId(ed.id as any)}
                  className={`flex-1 py-2.5 rounded-xl border text-xs font-semibold transition-all ${
                    editionId === ed.id
                      ? 'bg-primary-600 border-primary-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  {ed.label}
                </button>
              ))}
            </div>
          </div>

          {/* MC Versions */}
          <div>
            <label className="block text-slate-300 font-semibold mb-2">
              Supported Game Versions *
            </label>
            <div className="flex flex-wrap gap-2 max-h-36 overflow-y-auto p-3 bg-slate-950 rounded-xl border border-slate-800">
              {minecraftVersions.map((v) => {
                const active = selectedVersions.includes(v.version);
                return (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() => toggleSelection(selectedVersions, v.version, setSelectedVersions)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                      active
                        ? 'bg-primary-600 text-white font-semibold'
                        : 'bg-slate-850 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {v.version}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Loaders */}
          <div>
            <label className="block text-slate-300 font-semibold mb-2">Compatible Mod Loaders *</label>
            <div className="flex flex-wrap gap-2">
              {loaders.map((l) => {
                const active = selectedLoaders.includes(l.slug);
                return (
                  <button
                    key={l.id}
                    type="button"
                    onClick={() => toggleSelection(selectedLoaders, l.slug, setSelectedLoaders)}
                    className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition-colors ${
                      active
                        ? 'bg-primary-600 border-primary-500 text-white font-semibold'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    {l.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Categories */}
          <div>
            <label className="block text-slate-300 font-semibold mb-2">Categories</label>
            <div className="flex flex-wrap gap-1.5">
              {categories.map((c) => {
                const active = selectedCategories.includes(c.slug);
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => toggleSelection(selectedCategories, c.slug, setSelectedCategories)}
                    className={`px-2.5 py-1 rounded-lg text-xs transition-colors ${
                      active
                        ? 'bg-secondary-600 text-white font-medium'
                        : 'bg-slate-950 border border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    {c.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Tags & Environment */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Tags (comma separated)
              </label>
              <input
                type="text"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="performance, fps, vanilla-plus"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">License</label>
              <input
                type="text"
                value={license}
                onChange={(e) => setLicense(e.target.value)}
                placeholder="MIT, LGPL-3.0, All Rights Reserved"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 font-mono"
              />
            </div>
          </div>
        </div>
      )}

      {/* Step 3: Media & External Links */}
      {step === 3 && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-5 text-xs">
          <h2 className="text-base font-heading font-bold text-white">Media & Repository Links</h2>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Project Icon URL</label>
            <input
              type="url"
              value={iconUrl}
              onChange={(e) => setIconUrl(e.target.value)}
              placeholder="https://example.com/project-icon.png"
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
            />
            <p className="text-[11px] text-slate-500 mt-1">Recommended size: 256x256 square PNG or WEBP.</p>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Gallery Screenshots URLs (one per line)
            </label>
            <textarea
              rows={4}
              value={galleryInput}
              onChange={(e) => setGalleryInput(e.target.value)}
              placeholder="https://example.com/screenshot1.png&#10;https://example.com/screenshot2.png"
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 font-mono text-[11px]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-slate-800">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Source Code URL</label>
              <input
                type="url"
                value={sourceUrl}
                onChange={(e) => setSourceUrl(e.target.value)}
                placeholder="https://github.com/user/my-mod"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Issue Tracker URL</label>
              <input
                type="url"
                value={issuesUrl}
                onChange={(e) => setIssuesUrl(e.target.value)}
                placeholder="https://github.com/user/my-mod/issues"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Documentation / Wiki URL</label>
              <input
                type="url"
                value={wikiUrl}
                onChange={(e) => setWikiUrl(e.target.value)}
                placeholder="https://wiki.example.com"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Discord Community URL</label>
              <input
                type="url"
                value={discordUrl}
                onChange={(e) => setDiscordUrl(e.target.value)}
                placeholder="https://discord.gg/invite"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
              />
            </div>
          </div>
        </div>
      )}

      {/* Step 4: Initial Version & Upload File */}
      {step === 4 && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-5 text-xs">
          <h2 className="text-base font-heading font-bold text-white">Initial Version & Release File</h2>
          <p className="text-slate-400">
            Every published project requires at least one initial release version.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Version Number *</label>
              <input
                type="text"
                required
                value={versionNumber}
                onChange={(e) => setVersionNumber(e.target.value)}
                placeholder="1.0.0"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Version Title</label>
              <input
                type="text"
                value={versionName}
                onChange={(e) => setVersionName(e.target.value)}
                placeholder="Release 1.0"
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Release Type</label>
              <select
                value={releaseType}
                onChange={(e) => setReleaseType(e.target.value as any)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
              >
                <option value="release">Release (Stable)</option>
                <option value="beta">Beta</option>
                <option value="alpha">Alpha</option>
              </select>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
            <h3 className="font-semibold text-slate-200">Attached Release File</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-400 mb-1">File Name</label>
                <input
                  type="text"
                  value={fileName}
                  onChange={(e) => setFileName(e.target.value)}
                  placeholder={`${slug || 'mod'}-${versionNumber}.jar`}
                  className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Direct Download Link / Storage URL</label>
                <input
                  type="url"
                  value={fileUrl}
                  onChange={(e) => setFileUrl(e.target.value)}
                  placeholder="https://example.com/files/mod-1.0.jar"
                  className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 font-mono"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Initial Changelog</label>
            <textarea
              rows={3}
              value={changelog}
              onChange={(e) => setChangelog(e.target.value)}
              placeholder="What's included in this initial version?"
              className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-slate-200"
            />
          </div>
        </div>
      )}

      {/* Step 5: Preview & Final Submission */}
      {step === 5 && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-6 text-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 size={20} className="text-emerald-400" />
            <h2 className="text-base font-heading font-bold text-white">Review & Submit Project</h2>
          </div>

          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-slate-400">Title:</span>
              <strong className="text-slate-100">{title}</strong>
            </div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-slate-400">Slug:</span>
              <span className="font-mono text-primary-400">{slug}</span>
            </div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-slate-400">Resource Type:</span>
              <span className="capitalize text-slate-200">{resourceTypeId}</span>
            </div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-slate-400">Minecraft Versions:</span>
              <span className="font-mono text-slate-200">{selectedVersions.join(', ')}</span>
            </div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-slate-400">Loaders:</span>
              <span className="capitalize text-slate-200">{selectedLoaders.join(', ')}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Initial Release:</span>
              <span className="font-mono text-slate-200">v{versionNumber} ({releaseType})</span>
            </div>
          </div>

          {/* Moderation policy acknowledgment */}
          <div className="p-4 rounded-xl bg-primary-950/20 border border-primary-900/40 text-primary-300 text-[11px] leading-relaxed">
            <strong>Moderation Policy:</strong> All new projects are reviewed by PHICHMC moderators for safety, copyright compliance, and valid Minecraft assets before becoming publicly visible.
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-4">
            <button
              type="button"
              disabled={submitting}
              onClick={() => handleSubmit(false)}
              className="w-full sm:w-auto px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-semibold transition-colors"
            >
              Save as Draft
            </button>
            <button
              type="button"
              disabled={submitting}
              onClick={() => handleSubmit(true)}
              className="w-full sm:w-auto px-6 py-2.5 bg-primary-600 hover:bg-primary-500 text-white rounded-xl font-semibold shadow-lg shadow-primary-600/30 transition-all hover:scale-102"
            >
              {submitting ? 'Submitting...' : 'Submit for Review'}
            </button>
          </div>
        </div>
      )}

      {/* Navigation Buttons for Wizard */}
      <div className="flex items-center justify-between pt-4">
        {step > 1 ? (
          <button
            type="button"
            onClick={() => setStep((s) => s - 1)}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold"
          >
            <ArrowLeft size={14} />
            <span>Previous Step</span>
          </button>
        ) : (
          <div />
        )}

        {step < 5 && (
          <button
            type="button"
            onClick={handleNext}
            className="flex items-center gap-1.5 px-5 py-2 bg-primary-600 hover:bg-primary-500 text-white rounded-xl text-xs font-semibold shadow-md"
          >
            <span>Next Step</span>
            <ArrowRight size={14} />
          </button>
        )}
      </div>
    </div>
  );
};

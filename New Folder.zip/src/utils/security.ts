/**
 * Security utilities for PHICHMC
 * Sanitization, URL validation, and input verification
 */

/**
 * Returns the URL if it is a valid HTTP or HTTPS link, or a safe relative path.
 * Strictly blocks javascript:, data:, vbscript:, and other executable URI schemes.
 */
export const getSafeUrl = (url?: string | null): string | null => {
  if (!url || typeof url !== 'string') return null;
  const trimmed = url.trim();

  // Explicitly check for dangerous protocols
  const lower = trimmed.toLowerCase();
  if (
    lower.startsWith('javascript:') ||
    lower.startsWith('data:') ||
    lower.startsWith('vbscript:') ||
    lower.startsWith('file:') ||
    lower.startsWith('about:')
  ) {
    return null;
  }

  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
      return trimmed;
    }
    return null;
  } catch {
    // Safe relative link within app
    if (trimmed.startsWith('/') && !trimmed.startsWith('//') && !trimmed.startsWith('/\\')) {
      return trimmed;
    }
    return null;
  }
};

/**
 * Sanitizes project or resource slug.
 * Allows only lowercase alphanumeric characters and single hyphens.
 */
export const sanitizeSlug = (raw: string): string => {
  return raw
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
};

/**
 * List of reserved slugs that conflict with platform routes
 */
export const RESERVED_SLUGS = new Set([
  'admin',
  'api',
  'dashboard',
  'discover',
  'resources',
  'project',
  'user',
  'creator',
  'creators',
  'collection',
  'collections',
  'favorites',
  'settings',
  'notifications',
  'download',
  'login',
  'register',
  'forgot-password',
  'about',
  'terms',
  'privacy',
  'dmca',
  'copyright',
  'community-guidelines',
  'contact',
  'report',
  'apply-creator',
]);

export const isReservedSlug = (slug: string): boolean => {
  return RESERVED_SLUGS.has(slug.toLowerCase().trim());
};

import { doc, getDoc, updateDoc, increment } from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { db, functions } from '../firebase/config';
import { ProjectItem, ProjectVersion, VersionFile } from '../types';
import { SAMPLE_PROJECTS } from '../firebase/seed';
import { projectService } from './projectService';
import { getSafeUrl } from '../utils/security';

export interface DownloadDetails {
  project: ProjectItem;
  version: ProjectVersion;
  file: VersionFile;
}

export const downloadService = {
  /**
   * Fetch verified details for download page
   */
  async getDownloadDetails(
    projectSlug: string,
    versionId: string
  ): Promise<DownloadDetails | null> {
    let project: ProjectItem | null = null;
    let version: ProjectVersion | null = null;

    // Check sample projects first or Firestore
    const sample = SAMPLE_PROJECTS.find(
      (p) => p.project.slug === projectSlug && p.version.id === versionId
    );
    if (sample) {
      project = sample.project;
      version = sample.version;
    } else {
      // Fetch from Firestore
      try {
        project = await projectService.getProjectBySlug(projectSlug);
        if (project) {
          const vSnap = await getDoc(
            doc(db, 'projects', project.id, 'versions', versionId)
          );
          if (vSnap.exists()) {
            version = vSnap.data() as ProjectVersion;
          }
        }
      } catch (err) {
        console.warn('Error fetching download info:', err);
      }
    }

    if (!project || !version || version.files.length === 0) {
      return null;
    }

    const primaryFile = version.files.find((f) => f.primary) || version.files[0];

    return {
      project,
      version,
      file: primaryFile,
    };
  },

  /**
   * Safely record a download event with session deduplication
   */
  async recordDownload(projectId: string, versionId: string, fileId: string): Promise<void> {
    const dedupeKey = `downloaded_${projectId}_${versionId}_${fileId}`;
    if (sessionStorage.getItem(dedupeKey)) {
      return; // Already counted in this session window
    }

    sessionStorage.setItem(dedupeKey, '1');

    // 1. Attempt secure server-side increment via Cloud Functions
    try {
      const requestDownloadFn = httpsCallable(functions, 'requestDownload');
      await requestDownloadFn({ projectId, versionId, fileId, sessionKey: dedupeKey });
      return;
    } catch {
      // Cloud functions may not be deployed locally; fallback to direct update
    }

    // 2. Fallback to client-side Firestore increment
    try {
      const projectRef = doc(db, 'projects', projectId);
      await updateDoc(projectRef, {
        downloads: increment(1),
        trendingScore: increment(3),
      });

      const versionRef = doc(db, 'projects', projectId, 'versions', versionId);
      await updateDoc(versionRef, {
        downloadCount: increment(1),
      });
    } catch {
      // Handled if restricted by firestore rules
    }
  },

  /**
   * Trigger direct browser download of file
   */
  triggerFileDownload(file: VersionFile) {
    const safeUrl = getSafeUrl(file.downloadUrl);
    if (!safeUrl) return;

    const link = document.createElement('a');
    link.href = safeUrl;
    link.download = file.fileName;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  },
};

import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db } from '../firebase/config';
import {
  ProjectItem,
  ProjectStatus,
  ReportItem,
  CreatorApplication,
  UserProfile,
  AuditLogItem,
  CategoryItem,
  TagItem,
  LoaderItem,
  MinecraftVersionItem,
  ResourceTypeItem,
  SiteSettings,
  AdUnit,
  AnnouncementItem,
} from '../types';

export const adminService = {
  // ===================== AUDIT LOGS =====================
  async logAction(
    adminId: string,
    adminUsername: string,
    action: string,
    targetType: string,
    targetId: string,
    details?: string
  ): Promise<void> {
    try {
      const logId = `log_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const logItem: Record<string, any> = {
        id: logId,
        adminId: adminId || 'unknown',
        adminUsername: adminUsername || 'admin',
        action,
        targetType,
        targetId,
        timestamp: new Date().toISOString(),
      };
      if (details) {
        logItem.details = details;
      }
      await setDoc(doc(db, 'auditLogs', logId), logItem);
    } catch (err) {
      console.warn('Failed to write audit log:', err);
    }
  },

  async getAuditLogs(limitCount = 50): Promise<AuditLogItem[]> {
    try {
      const q = query(
        collection(db, 'auditLogs'),
        orderBy('timestamp', 'desc'),
        limit(limitCount)
      );
      const snap = await getDocs(q);
      return snap.docs.map((d) => d.data() as AuditLogItem);
    } catch {
      return [];
    }
  },

  // ===================== MODERATION QUEUE =====================

  async getPendingProjects(): Promise<ProjectItem[]> {
    try {
      const q = query(
        collection(db, 'projects'),
        where('status', '==', 'pending_review')
      );
      const snap = await getDocs(q);
      return snap.docs.map((d) => ({ id: d.id, ...d.data() } as ProjectItem));
    } catch {
      return [];
    }
  },

  async getAllProjects(): Promise<ProjectItem[]> {
    try {
      const snap = await getDocs(collection(db, 'projects'));
      return snap.docs.map((d) => ({ id: d.id, ...d.data() } as ProjectItem));
    } catch {
      return [];
    }
  },

  async moderateProject(
    projectId: string,
    newStatus: ProjectStatus,
    adminId: string,
    adminUsername: string,
    reason?: string,
    privateNote?: string
  ): Promise<void> {
    const projectRef = doc(db, 'projects', projectId);
    const reviewer = adminUsername || 'admin';

    const moderationData: Record<string, any> = {
      status: newStatus,
      reviewedBy: reviewer,
      reviewedAt: new Date().toISOString(),
    };
    if (reason && reason.trim()) {
      moderationData.reason = reason.trim();
    }
    if (privateNote && privateNote.trim()) {
      moderationData.privateNote = privateNote.trim();
    }

    const updateData: Record<string, any> = {
      status: newStatus,
      moderation: moderationData,
    };

    if (newStatus === 'approved') {
      updateData.publishedAt = new Date().toISOString();
      // Cascade version approval
      try {
        const versionsSnap = await getDocs(collection(db, 'projects', projectId, 'versions'));
        for (const vDoc of versionsSnap.docs) {
          const vData = vDoc.data();
          if (vData.status === 'pending_review' || vData.status === 'draft') {
            await updateDoc(vDoc.ref, {
              status: 'approved',
              publishedAt: new Date().toISOString(),
            });
          }
        }
      } catch (e) {
        console.warn('Could not cascade version approval:', e);
      }
    }

    await updateDoc(projectRef, updateData);
    await this.logAction(
      adminId,
      reviewer,
      `MODERATE_PROJECT_${newStatus.toUpperCase()}`,
      'project',
      projectId,
      reason ? `Reason: ${reason}` : undefined
    );
  },

  async toggleProjectFeatured(
    projectId: string,
    featured: boolean,
    adminId: string,
    adminUsername: string
  ): Promise<void> {
    await updateDoc(doc(db, 'projects', projectId), { featured });
    await this.logAction(
      adminId,
      adminUsername,
      featured ? 'FEATURE_PROJECT' : 'UNFEATURE_PROJECT',
      'project',
      projectId
    );
  },

  async toggleProjectVerified(
    projectId: string,
    verified: boolean,
    adminId: string,
    adminUsername: string
  ): Promise<void> {
    await updateDoc(doc(db, 'projects', projectId), { verified });
    await this.logAction(
      adminId,
      adminUsername,
      verified ? 'VERIFY_PROJECT' : 'UNVERIFY_PROJECT',
      'project',
      projectId
    );
  },

  async deleteProject(
    projectId: string,
    adminId: string,
    adminUsername: string,
    projectTitle?: string
  ): Promise<void> {
    // 1. Delete versions subcollection documents
    try {
      const versionsSnap = await getDocs(collection(db, 'projects', projectId, 'versions'));
      for (const vDoc of versionsSnap.docs) {
        await deleteDoc(doc(db, 'projects', projectId, 'versions', vDoc.id));
      }
    } catch (e) {
      console.warn('Error deleting sub-versions:', e);
    }

    // 2. Delete main project document
    await deleteDoc(doc(db, 'projects', projectId));

    // 3. Log audit action
    await this.logAction(
      adminId,
      adminUsername,
      'DELETE_PROJECT',
      'project',
      projectId,
      projectTitle ? `Deleted project "${projectTitle}"` : undefined
    );
  },

  // ===================== CREATOR APPLICATIONS =====================

  async getCreatorApplications(): Promise<CreatorApplication[]> {
    try {
      const snap = await getDocs(collection(db, 'creatorApplications'));
      return snap.docs.map((d) => ({ id: d.id, ...d.data() } as CreatorApplication));
    } catch {
      return [];
    }
  },

  async reviewCreatorApplication(
    applicationId: string,
    userId: string,
    decision: 'approved' | 'rejected',
    adminId: string,
    adminUsername: string,
    adminNote?: string
  ): Promise<void> {
    const appRef = doc(db, 'creatorApplications', applicationId);
    const updatePayload: Record<string, any> = {
      status: decision,
      reviewedAt: new Date().toISOString(),
    };
    if (adminNote && adminNote.trim()) {
      updatePayload.adminNote = adminNote.trim();
    }
    await updateDoc(appRef, updatePayload);

    if (decision === 'approved') {
      const userRef = doc(db, 'users', userId);
      await updateDoc(userRef, { role: 'creator', isCreator: true });
    }

    await this.logAction(
      adminId,
      adminUsername,
      `CREATOR_APP_${decision.toUpperCase()}`,
      'creatorApplication',
      applicationId,
      adminNote && adminNote.trim() ? adminNote.trim() : undefined
    );
  },

  // ===================== REPORTS =====================

  async getReports(): Promise<ReportItem[]> {
    try {
      const snap = await getDocs(collection(db, 'reports'));
      return snap.docs.map((d) => ({ id: d.id, ...d.data() } as ReportItem));
    } catch {
      return [];
    }
  },

  async resolveReport(
    reportId: string,
    status: 'resolved' | 'dismissed',
    adminId: string,
    adminUsername: string,
    resolutionNote?: string
  ): Promise<void> {
    const reportUpdatePayload: Record<string, any> = {
      status,
      resolvedAt: new Date().toISOString(),
    };
    if (resolutionNote && resolutionNote.trim()) {
      reportUpdatePayload.resolutionNote = resolutionNote.trim();
    }
    await updateDoc(doc(db, 'reports', reportId), reportUpdatePayload);
    await this.logAction(
      adminId,
      adminUsername,
      `RESOLVE_REPORT_${status.toUpperCase()}`,
      'report',
      reportId,
      resolutionNote && resolutionNote.trim() ? resolutionNote.trim() : undefined
    );
  },

  // ===================== USERS MANAGEMENT =====================

  async getAllUsers(): Promise<UserProfile[]> {
    try {
      const snap = await getDocs(collection(db, 'users'));
      return snap.docs.map((d) => ({ uid: d.id, ...d.data() } as UserProfile));
    } catch {
      return [];
    }
  },

  async updateUserRole(
    userId: string,
    newRole: 'user' | 'creator' | 'admin',
    adminId: string,
    adminUsername: string
  ): Promise<void> {
    await updateDoc(doc(db, 'users', userId), {
      role: newRole,
      isCreator: newRole === 'creator' || newRole === 'admin',
    });
    await this.logAction(
      adminId,
      adminUsername,
      `CHANGE_USER_ROLE_TO_${newRole.toUpperCase()}`,
      'user',
      userId
    );
  },

  async updateUserStatus(
    userId: string,
    newStatus: 'active' | 'suspended' | 'banned',
    adminId: string,
    adminUsername: string
  ): Promise<void> {
    await updateDoc(doc(db, 'users', userId), { status: newStatus });
    await this.logAction(
      adminId,
      adminUsername,
      `CHANGE_USER_STATUS_${newStatus.toUpperCase()}`,
      'user',
      userId
    );
  },

  async toggleUserVerified(
    userId: string,
    isVerified: boolean,
    adminId: string,
    adminUsername: string
  ): Promise<void> {
    await updateDoc(doc(db, 'users', userId), { isVerified });
    await this.logAction(
      adminId,
      adminUsername,
      isVerified ? 'VERIFY_CREATOR' : 'UNVERIFY_CREATOR',
      'user',
      userId
    );
  },

  // ===================== TAXONOMY CRUD =====================

  async saveCategory(item: CategoryItem): Promise<void> {
    await setDoc(doc(db, 'categories', item.id), item);
  },

  async deleteCategory(id: string): Promise<void> {
    await deleteDoc(doc(db, 'categories', id));
  },

  async saveTag(item: TagItem): Promise<void> {
    await setDoc(doc(db, 'tags', item.id), item);
  },

  async deleteTag(id: string): Promise<void> {
    await deleteDoc(doc(db, 'tags', id));
  },

  async saveLoader(item: LoaderItem): Promise<void> {
    await setDoc(doc(db, 'loaders', item.id), item);
  },

  async deleteLoader(id: string): Promise<void> {
    await deleteDoc(doc(db, 'loaders', id));
  },

  async saveMinecraftVersion(item: MinecraftVersionItem): Promise<void> {
    await setDoc(doc(db, 'minecraftVersions', item.id), item);
  },

  async deleteMinecraftVersion(id: string): Promise<void> {
    await deleteDoc(doc(db, 'minecraftVersions', id));
  },

  async saveResourceType(item: ResourceTypeItem): Promise<void> {
    await setDoc(doc(db, 'resourceTypes', item.id), item);
  },

  async deleteResourceType(id: string): Promise<void> {
    await deleteDoc(doc(db, 'resourceTypes', id));
  },

  // ===================== ADS & ADSTERRA =====================

  async saveAdUnit(unit: AdUnit): Promise<void> {
    await setDoc(doc(db, 'ads', unit.id), unit);
  },

  async deleteAdUnit(id: string): Promise<void> {
    await deleteDoc(doc(db, 'ads', id));
  },

  async toggleGlobalAds(enabled: boolean): Promise<void> {
    await updateDoc(doc(db, 'siteSettings', 'global'), { adsEnabled: enabled });
  },

  async toggleAdsterra(enabled: boolean): Promise<void> {
    await updateDoc(doc(db, 'siteSettings', 'global'), { adsterraEnabled: enabled });
  },

  // ===================== ANNOUNCEMENTS =====================

  async saveAnnouncement(ann: AnnouncementItem): Promise<void> {
    await setDoc(doc(db, 'announcements', ann.id), ann);
  },

  async deleteAnnouncement(id: string): Promise<void> {
    await deleteDoc(doc(db, 'announcements', id));
  },

  // ===================== SITE SETTINGS =====================

  async updateSiteSettings(settings: Partial<SiteSettings>): Promise<void> {
    await setDoc(doc(db, 'siteSettings', 'global'), settings, { merge: true });
  },
};

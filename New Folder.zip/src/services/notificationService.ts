import {
  collection,
  doc,
  getDocs,
  setDoc,
  updateDoc,
  query,
  where,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { NotificationItem } from '../types';

export const notificationService = {
  async getUserNotifications(userId: string, limitCount = 30): Promise<NotificationItem[]> {
    try {
      const q = query(
        collection(db, 'notifications'),
        where('userId', '==', userId),
        orderBy('createdAt', 'desc'),
        limit(limitCount)
      );
      const snap = await getDocs(q);
      return snap.docs.map((d) => d.data() as NotificationItem);
    } catch {
      return [];
    }
  },

  async markAsRead(notificationId: string): Promise<void> {
    try {
      await updateDoc(doc(db, 'notifications', notificationId), { read: true });
    } catch (err) {
      console.warn('Error marking notification read:', err);
    }
  },

  async markAllAsRead(userId: string): Promise<void> {
    try {
      const items = await this.getUserNotifications(userId, 50);
      for (const item of items) {
        if (!item.read) {
          await updateDoc(doc(db, 'notifications', item.id), { read: true });
        }
      }
    } catch (err) {
      console.warn('Error marking all notifications read:', err);
    }
  },

  async createNotification(notification: NotificationItem): Promise<void> {
    try {
      await setDoc(doc(db, 'notifications', notification.id), notification);
    } catch (err) {
      console.warn('Error creating notification:', err);
    }
  },
};

import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  increment,
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { ProjectItem, ProjectVersion, ResourceType } from '../types';
import { SAMPLE_PROJECTS } from '../firebase/seed';

export interface DiscoverFilters {
  searchQuery?: string;
  resourceType?: string;
  edition?: string;
  version?: string;
  loader?: string;
  category?: string;
  environment?: string;
  sort?: 'relevance' | 'downloads' | 'followers' | 'updated' | 'published' | 'trending';
  limitCount?: number;
}

export const projectService = {
  /**
   * Get an approved project by its slug
   */
  async getProjectBySlug(slug: string): Promise<ProjectItem | null> {
    try {
      const q = query(collection(db, 'projects'), where('slug', '==', slug), limit(1));
      const snap = await getDocs(q);
      if (!snap.empty) {
        return { id: snap.docs[0].id, ...snap.docs[0].data() } as ProjectItem;
      }
    } catch (err) {
      console.warn('Firestore query failed, checking fallback:', err);
    }

    // Fallback to sample projects
    const fallback = SAMPLE_PROJECTS.find((p) => p.project.slug === slug);
    return fallback ? fallback.project : null;
  },

  /**
   * Get project by ID (useful for owner/dashboard)
   */
  async getProjectById(id: string): Promise<ProjectItem | null> {
    try {
      const snap = await getDoc(doc(db, 'projects', id));
      if (snap.exists()) {
        return { id: snap.id, ...snap.data() } as ProjectItem;
      }
    } catch (err) {
      console.warn('Error getting project by id:', err);
    }
    const fallback = SAMPLE_PROJECTS.find((p) => p.project.id === id);
    return fallback ? fallback.project : null;
  },

  /**
   * Check if a slug is available
   */
  async isSlugAvailable(slug: string, currentProjectId?: string): Promise<boolean> {
    try {
      const q = query(collection(db, 'projects'), where('slug', '==', slug), limit(1));
      const snap = await getDocs(q);
      if (snap.empty) return true;
      if (currentProjectId && snap.docs[0].id === currentProjectId) return true;
      return false;
    } catch {
      return true;
    }
  },

  /**
   * Discover / Search projects with rich filters and sorting
   */
  async discoverProjects(filters: DiscoverFilters): Promise<ProjectItem[]> {
    let allProjects: ProjectItem[] = [];

    try {
      // Fetch approved projects from Firestore
      const q = query(
        collection(db, 'projects'),
        where('status', '==', 'approved'),
        limit(filters.limitCount || 50)
      );
      const snap = await getDocs(q);
      if (!snap.empty) {
        allProjects = snap.docs.map((d) => ({ id: d.id, ...d.data() } as ProjectItem));
      }
    } catch (err) {
      console.warn('Failed to load from Firestore, using seeded resources:', err);
    }

    // If empty, supply seeded demo projects
    if (allProjects.length === 0) {
      allProjects = SAMPLE_PROJECTS.map((s) => s.project);
    }

    // Client-side filtering & ranking
    let filtered = [...allProjects];

    // Resource Type
    if (filters.resourceType && filters.resourceType !== 'all') {
      filtered = filtered.filter((p) => p.resourceTypeId === filters.resourceType);
    }

    // Edition
    if (filters.edition && filters.edition !== 'all') {
      filtered = filtered.filter(
        (p) => p.editionId === filters.edition || p.editionId === 'both'
      );
    }

    // Minecraft Version
    if (filters.version && filters.version !== 'all') {
      filtered = filtered.filter((p) =>
        p.minecraftVersions.some((v) => v.toLowerCase().includes(filters.version!.toLowerCase()))
      );
    }

    // Loader
    if (filters.loader && filters.loader !== 'all') {
      filtered = filtered.filter((p) =>
        p.loaders.some((l) => l.toLowerCase() === filters.loader!.toLowerCase())
      );
    }

    // Category
    if (filters.category && filters.category !== 'all') {
      filtered = filtered.filter((p) =>
        p.categoryIds.some((c) => c.toLowerCase() === filters.category!.toLowerCase())
      );
    }

    // Environment
    if (filters.environment && filters.environment !== 'all') {
      filtered = filtered.filter(
        (p) => p.environment === filters.environment || p.environment === 'both'
      );
    }

    // Text Search
    if (filters.searchQuery && filters.searchQuery.trim()) {
      const qLower = filters.searchQuery.toLowerCase().trim();
      filtered = filtered.filter(
        (p) =>
          p.title.toLowerCase().includes(qLower) ||
          p.shortDescription.toLowerCase().includes(qLower) ||
          p.creatorUsername.toLowerCase().includes(qLower) ||
          p.tagIds.some((t) => t.toLowerCase().includes(qLower))
      );
    }

    // Sorting
    const sort = filters.sort || 'relevance';
    switch (sort) {
      case 'downloads':
        filtered.sort((a, b) => b.downloads - a.downloads);
        break;
      case 'followers':
        filtered.sort((a, b) => b.followers - a.followers);
        break;
      case 'updated':
        filtered.sort(
          (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
        );
        break;
      case 'published':
        filtered.sort(
          (a, b) =>
            new Date(b.publishedAt || b.createdAt).getTime() -
            new Date(a.publishedAt || a.createdAt).getTime()
        );
        break;
      case 'trending':
        filtered.sort((a, b) => (b.trendingScore || 0) - (a.trendingScore || 0));
        break;
      default:
        // Relevance: blend downloads, trending and updated
        filtered.sort((a, b) => (b.trendingScore || 0) * 1.5 + b.downloads * 0.1 - ((a.trendingScore || 0) * 1.5 + a.downloads * 0.1));
        break;
    }

    return filtered;
  },

  /**
   * Fetch versions for a project.
   * If onlyApproved is true (default for public), only returns approved versions.
   * If onlyApproved is false (for creator/admin), returns all versions (drafts, pending_review, approved, etc.)
   */
  async getProjectVersions(projectId: string, onlyApproved = true): Promise<ProjectVersion[]> {
    try {
      let snap;
      try {
        if (onlyApproved) {
          const q = query(
            collection(db, 'projects', projectId, 'versions'),
            where('status', '==', 'approved')
          );
          snap = await getDocs(q);
        } else {
          const q = collection(db, 'projects', projectId, 'versions');
          snap = await getDocs(q);
        }
      } catch (queryErr) {
        console.warn('Filtered version query fallback to raw collection:', queryErr);
        const q = collection(db, 'projects', projectId, 'versions');
        snap = await getDocs(q);
      }

      if (snap && !snap.empty) {
        let list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as ProjectVersion));
        if (onlyApproved) {
          list = list.filter((v) => v.status === 'approved');
        }
        return list.sort((a, b) => {
          const dateA = new Date(a.publishedAt || a.createdAt || 0).getTime();
          const dateB = new Date(b.publishedAt || b.createdAt || 0).getTime();
          return dateB - dateA;
        });
      }
    } catch (err) {
      console.warn('Error fetching versions from Firestore:', err);
    }

    const sample = SAMPLE_PROJECTS.find((p) => p.project.id === projectId);
    return sample ? [sample.version] : [];
  },

  /**
   * Record a project view with session deduplication
   */
  async recordProjectView(projectId: string): Promise<void> {
    const sessionKey = `viewed_project_${projectId}`;
    if (sessionStorage.getItem(sessionKey)) return;

    sessionStorage.setItem(sessionKey, '1');
    try {
      const projectRef = doc(db, 'projects', projectId);
      await updateDoc(projectRef, {
        views: increment(1),
        trendingScore: increment(1),
      });
    } catch (err) {
      // Ignored for unauthenticated/demo
    }
  },

  /**
   * Create or update project
   */
  async saveProject(project: ProjectItem): Promise<void> {
    const projectRef = doc(db, 'projects', project.id);
    const cleaned = JSON.parse(JSON.stringify(project));
    await setDoc(projectRef, cleaned, { merge: true });
  },

  /**
   * Add a new version to a project
   */
  async addProjectVersion(projectId: string, version: ProjectVersion): Promise<void> {
    const versionRef = doc(db, 'projects', projectId, 'versions', version.id);
    const cleaned = JSON.parse(JSON.stringify(version));
    await setDoc(versionRef, cleaned);
    // Safely update project updatedAt timestamp
    try {
      const projectRef = doc(db, 'projects', projectId);
      await updateDoc(projectRef, { updatedAt: new Date().toISOString() });
    } catch (e) {
      console.warn('Could not update project updatedAt:', e);
    }
  },

  /**
   * Update an existing project version
   */
  async updateProjectVersion(
    projectId: string,
    versionId: string,
    updates: Partial<ProjectVersion>
  ): Promise<void> {
    const versionRef = doc(db, 'projects', projectId, 'versions', versionId);
    const cleaned = JSON.parse(JSON.stringify(updates));
    await updateDoc(versionRef, cleaned);
    try {
      const projectRef = doc(db, 'projects', projectId);
      await updateDoc(projectRef, { updatedAt: new Date().toISOString() });
    } catch (e) {
      console.warn('Could not update project updatedAt:', e);
    }
  },

  /**
   * Delete a project version
   */
  async deleteProjectVersion(projectId: string, versionId: string): Promise<void> {
    const versionRef = doc(db, 'projects', projectId, 'versions', versionId);
    await deleteDoc(versionRef);
  },
};

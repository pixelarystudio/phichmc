import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  updateDoc,
  query,
  where,
  orderBy,
  increment,
  limit,
} from 'firebase/firestore';
import { db } from '../firebase/config';
import {
  ProjectComment,
  CollectionItem,
  ReportItem,
  ProjectItem,
} from '../types';

export const communityService = {
  // ===================== FOLLOW SYSTEM =====================

  async isFollowingProject(projectId: string, userId: string): Promise<boolean> {
    try {
      const snap = await getDoc(doc(db, 'projects', projectId, 'followers', userId));
      return snap.exists();
    } catch {
      return false;
    }
  },

  async toggleFollowProject(projectId: string, userId: string): Promise<boolean> {
    const followerRef = doc(db, 'projects', projectId, 'followers', userId);
    const snap = await getDoc(followerRef);
    const projectRef = doc(db, 'projects', projectId);

    if (snap.exists()) {
      await deleteDoc(followerRef);
      try {
        await updateDoc(projectRef, { followers: increment(-1) });
      } catch (err) {
        // Safe catch if direct project document update is restricted by security rules
      }
      return false;
    } else {
      await setDoc(followerRef, { userId, followedAt: new Date().toISOString() });
      try {
        await updateDoc(projectRef, { followers: increment(1) });
      } catch (err) {
        // Safe catch if direct project document update is restricted by security rules
      }
      return true;
    }
  },

  async isFollowingUser(targetUserId: string, currentUserId: string): Promise<boolean> {
    try {
      const snap = await getDoc(doc(db, 'users', targetUserId, 'followers', currentUserId));
      return snap.exists();
    } catch {
      return false;
    }
  },

  async toggleFollowUser(targetUserId: string, currentUserId: string): Promise<boolean> {
    if (targetUserId === currentUserId) return false;
    const followerRef = doc(db, 'users', targetUserId, 'followers', currentUserId);
    const snap = await getDoc(followerRef);
    const targetUserRef = doc(db, 'users', targetUserId);
    const currentUserRef = doc(db, 'users', currentUserId);

    if (snap.exists()) {
      await deleteDoc(followerRef);
      try {
        await updateDoc(targetUserRef, { followersCount: increment(-1) });
        await updateDoc(currentUserRef, { followingCount: increment(-1) });
      } catch (err) {
        // Safe catch if target user document update is restricted
      }
      return false;
    } else {
      await setDoc(followerRef, { followedAt: new Date().toISOString() });
      try {
        await updateDoc(targetUserRef, { followersCount: increment(1) });
        await updateDoc(currentUserRef, { followingCount: increment(1) });
      } catch (err) {
        // Safe catch if target user document update is restricted
      }
      return true;
    }
  },

  // ===================== FAVORITES SYSTEM =====================

  async isProjectFavorited(projectId: string, userId: string): Promise<boolean> {
    try {
      const snap = await getDoc(doc(db, 'favorites', userId, 'items', projectId));
      return snap.exists();
    } catch {
      return false;
    }
  },

  async toggleFavorite(projectId: string, userId: string): Promise<boolean> {
    const favRef = doc(db, 'favorites', userId, 'items', projectId);
    const snap = await getDoc(favRef);
    const projectRef = doc(db, 'projects', projectId);

    if (snap.exists()) {
      await deleteDoc(favRef);
      try {
        await updateDoc(projectRef, { favorites: increment(-1) });
      } catch (err) {
        // Safe catch if direct project document update is restricted
      }
      return false;
    } else {
      await setDoc(favRef, { projectId, favoritedAt: new Date().toISOString() });
      try {
        await updateDoc(projectRef, { favorites: increment(1) });
      } catch (err) {
        // Safe catch if direct project document update is restricted
      }
      return true;
    }
  },

  async getUserFavorites(userId: string): Promise<ProjectItem[]> {
    try {
      const snap = await getDocs(collection(db, 'favorites', userId, 'items'));
      const projectIds = snap.docs.map((d) => d.id);
      if (projectIds.length === 0) return [];

      const projects: ProjectItem[] = [];
      for (const pid of projectIds) {
        const pSnap = await getDoc(doc(db, 'projects', pid));
        if (pSnap.exists()) {
          projects.push(pSnap.data() as ProjectItem);
        }
      }
      return projects;
    } catch (err) {
      console.warn('Error fetching user favorites:', err);
      return [];
    }
  },

  // ===================== COLLECTIONS =====================

  async getUserCollections(userId: string): Promise<CollectionItem[]> {
    try {
      const q = query(collection(db, 'collections'), where('ownerId', '==', userId));
      const snap = await getDocs(q);
      return snap.docs.map((d) => d.data() as CollectionItem);
    } catch {
      return [];
    }
  },

  async getPublicCollections(): Promise<CollectionItem[]> {
    try {
      const q = query(
        collection(db, 'collections'),
        where('visibility', '==', 'public')
      );
      const snap = await getDocs(q);
      return snap.docs.map((d) => d.data() as CollectionItem);
    } catch {
      return [];
    }
  },

  async getCollectionBySlug(slug: string): Promise<CollectionItem | null> {
    try {
      const q = query(collection(db, 'collections'), where('slug', '==', slug), limit(1));
      const snap = await getDocs(q);
      if (!snap.empty) return snap.docs[0].data() as CollectionItem;
    } catch {
      // Ignored
    }
    return null;
  },

  async createCollection(collectionData: CollectionItem): Promise<void> {
    await setDoc(doc(db, 'collections', collectionData.id), collectionData);
  },

  async addProjectToCollection(collectionId: string, projectId: string): Promise<void> {
    const colRef = doc(db, 'collections', collectionId);
    const snap = await getDoc(colRef);
    if (snap.exists()) {
      const data = snap.data() as CollectionItem;
      if (!data.projectIds.includes(projectId)) {
        await updateDoc(colRef, {
          projectIds: [...data.projectIds, projectId],
          updatedAt: new Date().toISOString(),
        });
      }
    }
  },

  // ===================== COMMENTS =====================

  async getProjectComments(projectId: string): Promise<ProjectComment[]> {
    try {
      const q = query(
        collection(db, 'projects', projectId, 'comments'),
        orderBy('createdAt', 'desc')
      );
      const snap = await getDocs(q);
      return snap.docs.map((d) => d.data() as ProjectComment).filter((c) => !c.hidden);
    } catch (err) {
      console.warn('Error fetching comments:', err);
      return [];
    }
  },

  async postComment(comment: ProjectComment): Promise<void> {
    const commentRef = doc(db, 'projects', comment.projectId, 'comments', comment.id);
    await setDoc(commentRef, comment);
  },

  async deleteComment(projectId: string, commentId: string): Promise<void> {
    await deleteDoc(doc(db, 'projects', projectId, 'comments', commentId));
  },

  // ===================== REPORTS =====================

  async submitReport(report: ReportItem): Promise<void> {
    const reportRef = doc(db, 'reports', report.id);
    await setDoc(reportRef, report);
  },
};

export type UserRole = 'user' | 'creator' | 'admin';

export type UserStatus = 'active' | 'suspended' | 'banned';

export interface UserProfile {
  uid: string;
  username: string;
  displayName: string;
  email?: string;
  avatarUrl?: string;
  bio?: string;
  country?: string;
  website?: string;
  socialLinks?: {
    discord?: string;
    twitter?: string;
    github?: string;
    youtube?: string;
  };
  role: UserRole;
  status: UserStatus;
  isCreator: boolean;
  isVerified: boolean;
  followersCount: number;
  followingCount: number;
  projectCount: number;
  totalDownloads: number;
  totalViews: number;
  joinedAt: string; // ISO string
}

export type ResourceType =
  | 'mod'
  | 'addon'
  | 'resourcepack'
  | 'shader'
  | 'datapack'
  | 'map'
  | 'modpack'
  | 'skin'
  | 'other';

export type MinecraftEdition = 'java' | 'bedrock' | 'both';

export type ProjectEnvironment = 'client' | 'server' | 'both' | 'singleplayer';

export type ProjectStatus =
  | 'draft'
  | 'pending_review'
  | 'approved'
  | 'rejected'
  | 'archived'
  | 'unlisted'
  | 'suspended'
  | 'deleted';

export type ReleaseType = 'release' | 'beta' | 'alpha';

export interface ProjectDependency {
  id?: string; // Target PHICHMC project ID if on-platform
  name: string;
  type: 'required' | 'optional' | 'incompatible';
  url?: string;
}

export interface VersionFile {
  fileId: string;
  fileName: string;
  fileSize: number; // in bytes
  downloadUrl: string;
  sha256?: string;
  mimeType?: string;
  primary?: boolean;
}

export interface ProjectVersion {
  id: string;
  projectId: string;
  versionNumber: string;
  name: string;
  releaseType: ReleaseType;
  changelog: string;
  minecraftVersions: string[];
  loaders: string[];
  files: VersionFile[];
  dependencies: ProjectDependency[];
  status: ProjectStatus;
  downloadCount: number;
  publishedAt: string;
  createdAt: string;
  featured?: boolean;
}

export interface ProjectModeration {
  status: ProjectStatus;
  reason?: string;
  privateNote?: string;
  reviewedBy?: string;
  reviewedAt?: string;
}

export interface ProjectItem {
  id: string;
  slug: string;
  title: string;
  shortDescription: string;
  description: string;
  creatorId: string;
  creatorUsername: string;
  creatorDisplayName: string;
  creatorAvatarUrl?: string;
  creatorVerified?: boolean;
  resourceTypeId: ResourceType;
  editionId: MinecraftEdition;
  categoryIds: string[];
  tagIds: string[];
  minecraftVersions: string[];
  loaders: string[];
  environment: ProjectEnvironment;
  license: string;
  links?: {
    source?: string;
    issues?: string;
    wiki?: string;
    discord?: string;
    donation?: string;
    youtube?: string;
    twitter?: string;
    github?: string;
  };
  iconUrl?: string;
  gallery: string[];
  status: ProjectStatus;
  moderation?: ProjectModeration;
  verified?: boolean; // PHICHMC verified badge
  featured?: boolean; // Featured project flag
  downloads: number;
  views: number;
  followers: number;
  favorites: number;
  trendingScore: number;
  createdAt: string;
  updatedAt: string;
  publishedAt?: string;
  isDemo?: boolean;
}

export interface CategoryItem {
  id: string;
  name: string;
  slug: string;
  description?: string;
  iconName?: string;
  resourceTypes?: string[];
  active: boolean;
  order: number;
}

export interface TagItem {
  id: string;
  name: string;
  slug: string;
  active: boolean;
}

export interface MinecraftVersionItem {
  id: string;
  version: string;
  edition: MinecraftEdition;
  majorGroup: string; // e.g., '1.21'
  releaseType: 'release' | 'snapshot';
  active: boolean;
}

export interface LoaderItem {
  id: string;
  name: string; // e.g. 'Fabric', 'Forge', 'NeoForge', 'Quilt', 'Vanilla'
  slug: string;
  edition: MinecraftEdition;
  active: boolean;
}

export interface ResourceTypeItem {
  id: string;
  name: string; // 'Mods', 'Shaders', etc.
  slug: ResourceType;
  description: string;
  active: boolean;
}

export interface ProjectComment {
  id: string;
  projectId: string;
  authorId: string;
  authorUsername: string;
  authorDisplayName: string;
  authorAvatarUrl?: string;
  authorIsCreator?: boolean;
  authorIsAdmin?: boolean;
  content: string;
  parentId?: string; // for replies
  createdAt: string;
  updatedAt?: string;
  edited?: boolean;
  hidden?: boolean;
}

export interface CollectionItem {
  id: string;
  name: string;
  slug: string;
  description: string;
  coverImage?: string;
  ownerId: string;
  ownerUsername: string;
  ownerDisplayName: string;
  visibility: 'public' | 'private';
  projectIds: string[];
  createdAt: string;
  updatedAt: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  type:
    | 'project_approved'
    | 'project_rejected'
    | 'project_updated'
    | 'comment_reply'
    | 'version_published'
    | 'creator_application_approved'
    | 'creator_application_rejected'
    | 'announcement'
    | 'report_resolved';
  title: string;
  body: string;
  link?: string;
  read: boolean;
  createdAt: string;
}

export interface ReportItem {
  id: string;
  targetType: 'project' | 'version' | 'user' | 'comment';
  targetId: string;
  targetName?: string;
  reporterId: string;
  reporterUsername: string;
  reason:
    | 'copyright'
    | 'malware'
    | 'scam'
    | 'nsfw'
    | 'misleading'
    | 'reupload'
    | 'harassment'
    | 'spam'
    | 'other';
  details?: string;
  status: 'pending' | 'resolved' | 'dismissed';
  resolutionNote?: string;
  createdAt: string;
  resolvedAt?: string;
}

export interface CreatorApplication {
  id: string;
  userId: string;
  username: string;
  displayName: string;
  email: string;
  reason: string;
  experience: string;
  portfolio: string;
  website?: string;
  socialLinks?: string;
  status: 'pending' | 'approved' | 'rejected' | 'info_requested';
  adminNote?: string;
  createdAt: string;
  reviewedAt?: string;
}

export interface SiteSettings {
  siteName: string;
  tagline: string;
  logoUrl?: string;
  faviconUrl?: string;
  primaryColor: string;
  secondaryColor: string;
  maintenanceMode: boolean;
  allowRegistration: boolean;
  allowCreatorApplications: boolean;
  allowComments: boolean;
  allowLightMode: boolean;
  maxUploadSizeBytes: number;
  allowedFileExtensions: string[];
  adsEnabled: boolean;
  adsterraEnabled: boolean;
  discordUrl?: string;
  twitterUrl?: string;
  githubUrl?: string;
}

export interface AdUnit {
  id: string;
  providerId: 'adsterra' | 'other';
  placementId: 'homepage' | 'discover' | 'project' | 'download' | 'between_cards' | 'footer';
  format: 'banner' | 'native' | 'social_bar' | 'popunder' | 'other';
  title: string;
  desktopCode: string;
  mobileCode?: string;
  status: 'active' | 'paused';
  frequency?: number;
}

export interface AuditLogItem {
  id: string;
  adminId: string;
  adminUsername: string;
  action: string;
  targetType: string;
  targetId: string;
  targetName?: string;
  timestamp: string;
  details?: string;
}

export interface AnnouncementItem {
  id: string;
  title: string;
  content: string;
  type: 'info' | 'update' | 'maintenance' | 'warning' | 'community';
  active: boolean;
  createdAt: string;
}

import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Heart } from 'lucide-react';
import { TwitterIcon, GithubIcon } from '../common/SocialIcons';
import { useSiteConfig } from '../../contexts/SiteConfigContext';

export const Footer: React.FC = () => {
  const { settings } = useSiteConfig();

  return (
    <footer className="w-full bg-slate-950 border-t border-slate-800/80 pt-12 pb-16 text-xs text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 mb-12">
          {/* Col 1: Brand */}
          <div className="md:col-span-2 space-y-4">
            <Link to="/" className="inline-block" aria-label="PHICHMC Home">
              <img src="/main-logo.webp" alt="PHICHMC" className="h-8 w-auto object-contain rounded" />
            </Link>
            <p className="text-slate-400 max-w-sm leading-relaxed">
              Discover. Create. Share Minecraft. A modern, independent community platform for mods,
              resource packs, shaders, add-ons, and worlds.
            </p>
            <div className="flex items-center gap-3 pt-2">
              {settings.discordUrl && (
                <a
                  href={settings.discordUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 rounded-lg bg-slate-900 hover:bg-primary-950/40 text-slate-300 hover:text-primary-400 border border-slate-800 transition-colors"
                  title="Discord"
                >
                  <MessageSquare size={16} />
                </a>
              )}
              {settings.twitterUrl && (
                <a
                  href={settings.twitterUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 rounded-lg bg-slate-900 hover:bg-primary-950/40 text-slate-300 hover:text-primary-400 border border-slate-800 transition-colors"
                  title="Twitter / X"
                >
                  <TwitterIcon size={16} />
                </a>
              )}
              {settings.githubUrl && (
                <a
                  href={settings.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 rounded-lg bg-slate-900 hover:bg-primary-950/40 text-slate-300 hover:text-primary-400 border border-slate-800 transition-colors"
                  title="GitHub"
                >
                  <GithubIcon size={16} />
                </a>
              )}
            </div>
          </div>

          {/* Col 2: Discover */}
          <div className="space-y-3">
            <h4 className="font-heading font-semibold text-slate-200 text-sm">Discover</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/resources/mod" className="hover:text-primary-400 transition-colors">
                  Minecraft Mods
                </Link>
              </li>
              <li>
                <Link to="/resources/shader" className="hover:text-primary-400 transition-colors">
                  Shaders & Lighting
                </Link>
              </li>
              <li>
                <Link to="/resources/resourcepack" className="hover:text-primary-400 transition-colors">
                  Resource Packs
                </Link>
              </li>
              <li>
                <Link to="/resources/addon" className="hover:text-primary-400 transition-colors">
                  Bedrock Add-ons
                </Link>
              </li>
              <li>
                <Link to="/resources/datapack" className="hover:text-primary-400 transition-colors">
                  Data Packs
                </Link>
              </li>
              <li>
                <Link to="/resources/map" className="hover:text-primary-400 transition-colors">
                  Custom Maps
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Community & Creators */}
          <div className="space-y-3">
            <h4 className="font-heading font-semibold text-slate-200 text-sm">Community</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/creators" className="hover:text-primary-400 transition-colors">
                  Featured Creators
                </Link>
              </li>
              <li>
                <Link to="/collections" className="hover:text-primary-400 transition-colors">
                  Curated Collections
                </Link>
              </li>
              <li>
                <Link to="/apply-creator" className="hover:text-primary-400 transition-colors">
                  Creator Application
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-primary-400 transition-colors">
                  About PHICHMC
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-primary-400 transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 4: Legal & Policy */}
          <div className="space-y-3">
            <h4 className="font-heading font-semibold text-slate-200 text-sm">Legal & Safety</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/terms" className="hover:text-primary-400 transition-colors">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="hover:text-primary-400 transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/dmca" className="hover:text-primary-400 transition-colors">
                  DMCA / Copyright
                </Link>
              </li>
              <li>
                <Link to="/community-guidelines" className="hover:text-primary-400 transition-colors">
                  Community Guidelines
                </Link>
              </li>
              <li>
                <Link to="/report" className="hover:text-primary-400 transition-colors text-rose-400/90 hover:text-rose-400">
                  Report Abuse / Content
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Disclaimer & Bottom Bar */}
        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p className="max-w-xl text-center sm:text-left">
            Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.
            Minecraft is a registered trademark of Mojang Synergies AB.
          </p>
          <p>© {new Date().getFullYear()} PHICHMC. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

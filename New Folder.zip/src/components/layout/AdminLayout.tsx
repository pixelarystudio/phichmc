import React, { useState } from 'react';
import { Outlet, NavLink, Link, useNavigate } from 'react-router-dom';
import {
  ShieldAlert,
  ShieldCheck,
  Users,
  Box,
  Layers,
  FileCheck2,
  DollarSign,
  AlertOctagon,
  History,
  Settings,
  ArrowLeft,
  Menu,
  X,
  LayoutDashboard,
  CheckCircle,
  Loader2,
  LogIn,
  Crown,
  LogOut,
} from 'lucide-react';
import { useAuth, isSuperAdmin } from '../../contexts/AuthContext';
import { Avatar } from '../common/Avatar';

export const AdminLayout: React.FC = () => {
  const { user, profile, isAdmin, isCreator, loading, loginWithGoogle, logout, elevateToAdmin } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (loading || actionLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center">
        <Loader2 className="w-10 h-10 animate-spin text-amber-500 mb-4" />
        <p className="text-sm text-slate-400 font-mono">
          {actionLoading ? 'Updating credentials...' : 'Verifying administrative access...'}
        </p>
      </div>
    );
  }

  // 1. Not signed in at all
  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md p-8 rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl space-y-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
            <ShieldCheck size={32} />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-heading font-bold text-slate-100">PHICHMC Admin Console</h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              Sign in with your administrator account to access project moderation, user permissions, and platform settings.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-left space-y-1">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">Super Administrator</span>
            <p className="text-xs font-semibold text-amber-400 font-mono">pixelarystudio1@gmail.com</p>
          </div>

          {errorMsg && (
            <p className="text-xs text-rose-400 bg-rose-950/40 border border-rose-800/60 p-2.5 rounded-lg text-left">
              {errorMsg}
            </p>
          )}

          <div className="space-y-3 pt-2">
            <button
              onClick={async () => {
                setErrorMsg(null);
                setActionLoading(true);
                try {
                  await loginWithGoogle();
                } catch (err: any) {
                  setErrorMsg(err.message || 'Google sign-in failed.');
                  setActionLoading(false);
                }
              }}
              className="w-full flex items-center justify-center gap-3 py-3 px-4 bg-white hover:bg-slate-100 text-slate-900 font-semibold text-xs rounded-xl shadow transition-colors"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Continue with Google</span>
            </button>

            <button
              onClick={() => navigate('/login?from=/admin')}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs rounded-xl border border-slate-700 transition-colors"
            >
              <LogIn size={15} />
              <span>Sign In with Email & Password</span>
            </button>
          </div>

          <div className="pt-2 border-t border-slate-800/80">
            <Link to="/" className="text-xs text-slate-500 hover:text-slate-300 transition-colors">
              ← Return to PHICHMC
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // 2. User is signed in, but lacks admin claim/role
  if (!isAdmin) {
    const isSuper = isSuperAdmin(user.email) || isSuperAdmin(profile?.email);

    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md p-8 rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl space-y-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-center mx-auto">
            <ShieldAlert size={32} />
          </div>
          <div className="space-y-2">
            <h2 className="text-xl font-heading font-bold text-slate-100">
              {isSuper ? 'Administrator Activation Required' : 'Access Denied: Admin Clearance Required'}
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              {isSuper
                ? 'Your email is recognized as the platform owner. Click below to activate administrative privileges.'
                : 'This portal is restricted to authorized PHICHMC administrators. Your account does not have sufficient permissions to view or edit administrative data.'}
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-left space-y-1.5 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>Account:</span>
              <span className="font-mono text-slate-200 truncate max-w-[200px]">{user.email}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Current Role:</span>
              <span className="font-mono text-amber-400 uppercase font-semibold">{profile?.role || 'user'}</span>
            </div>
          </div>

          {errorMsg && (
            <p className="text-xs text-rose-400 bg-rose-950/40 border border-rose-800/60 p-2.5 rounded-lg text-left">
              {errorMsg}
            </p>
          )}

          <div className="space-y-3">
            {isSuper ? (
              <button
                onClick={async () => {
                  setErrorMsg(null);
                  setActionLoading(true);
                  try {
                    await elevateToAdmin();
                  } catch (err: any) {
                    setErrorMsg(err.message || 'Failed to grant admin privileges.');
                    setActionLoading(false);
                  }
                }}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition-all"
              >
                <Crown size={16} />
                <span>Activate Administrator Privileges</span>
              </button>
            ) : null}

            <div className="flex gap-2">
              <Link
                to="/"
                className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 bg-primary-600 hover:bg-primary-500 text-white font-semibold text-xs rounded-xl transition-colors"
              >
                <span>Return to PHICHMC</span>
              </Link>
              {isCreator && (
                <Link
                  to="/dashboard"
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs rounded-xl border border-slate-700 transition-colors"
                >
                  <span>Creator Studio</span>
                </Link>
              )}
            </div>

            <button
              onClick={async () => {
                await logout();
              }}
              className="w-full flex items-center justify-center gap-2 py-2 px-4 bg-transparent hover:bg-slate-800/60 text-slate-400 hover:text-slate-200 font-medium text-xs rounded-xl border border-slate-800 transition-colors"
            >
              <LogOut size={13} />
              <span>Sign Out & Switch Account</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const adminNav = [
    { label: 'Overview', path: '/admin', icon: LayoutDashboard, end: true },
    { label: 'Moderation Queue', path: '/admin/moderation', icon: FileCheck2 },
    { label: 'Users & Roles', path: '/admin/users', icon: Users },
    { label: 'All Projects', path: '/admin/projects', icon: Box },
    { label: 'Taxonomy & Minecraft', path: '/admin/taxonomy', icon: Layers },
    { label: 'Ads & Adsterra', path: '/admin/ads', icon: DollarSign },
    { label: 'Reports Queue', path: '/admin/reports', icon: AlertOctagon },
    { label: 'Audit Logs', path: '/admin/audit-logs', icon: History },
    { label: 'Site Settings', path: '/admin/settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-950 text-slate-100 selection:bg-amber-500 selection:text-black">
      {/* Mobile Header Bar */}
      <div className="md:hidden flex items-center justify-between p-4 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
          <span className="font-heading font-bold text-sm text-amber-400">PHICHMC ADMIN</span>
        </div>
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white"
        >
          {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Admin Sidebar */}
      <aside
        className={`${
          sidebarOpen ? 'block' : 'hidden'
        } md:block w-full md:w-64 bg-slate-900/90 border-r border-slate-800 p-5 flex flex-col justify-between shrink-0 z-30`}
      >
        <div>
          {/* Top Brand */}
          <div className="flex items-center justify-between pb-5 border-b border-slate-800 mb-6">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center font-bold font-mono text-sm">
                A
              </div>
              <div>
                <h3 className="font-heading font-bold text-sm text-slate-100">PHICHMC</h3>
                <span className="text-[10px] text-amber-400 font-mono uppercase tracking-wider">
                  Admin Console
                </span>
              </div>
            </div>
            <Link
              to="/"
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Return to site"
            >
              <ArrowLeft size={16} />
            </Link>
          </div>

          {/* Admin User Info */}
          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 mb-6">
            <Avatar src={profile?.avatarUrl} name={profile?.displayName || profile?.username} size="sm" />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-heading font-semibold text-slate-100 truncate">
                {profile?.displayName || profile?.username}
              </p>
              <span className="text-[10px] text-amber-400 font-mono font-medium">SUPER ADMIN</span>
            </div>
          </div>

          {/* Nav Items */}
          <nav className="space-y-1">
            {adminNav.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.end}
                  onClick={() => setSidebarOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/30'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                    }`
                  }
                >
                  <Icon size={16} />
                  <span>{item.label}</span>
                </NavLink>
              );
            })}
          </nav>
        </div>

        <div className="pt-6 border-t border-slate-800 mt-6">
          <Link
            to="/"
            className="flex items-center gap-2 text-xs text-slate-400 hover:text-primary-400 transition-colors"
          >
            <ArrowLeft size={14} />
            <span>Return to Public Platform</span>
          </Link>
        </div>
      </aside>

      {/* Admin Content Viewport */}
      <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full overflow-x-hidden">
        <Outlet />
      </main>
    </div>
  );
};

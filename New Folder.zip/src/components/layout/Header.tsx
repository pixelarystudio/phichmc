import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import {
  Search,
  Bell,
  Plus,
  User as UserIcon,
  LogOut,
  Settings,
  Shield,
  Heart,
  LayoutDashboard,
  CheckCheck,
  Menu,
  X,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Avatar } from '../common/Avatar';
import { notificationService } from '../../services/notificationService';
import { NotificationItem } from '../../types';
import { formatDistanceToNow } from 'date-fns';

export const Header: React.FC = () => {
  const { user, profile, isAdmin, isCreator, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  const profileRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  // Fetch notifications for signed in user
  useEffect(() => {
    if (!user) {
      setNotifications([]);
      setUnreadCount(0);
      return;
    }
    const loadNotifs = async () => {
      const items = await notificationService.getUserNotifications(user.uid, 6);
      setNotifications(items);
      setUnreadCount(items.filter((n) => !n.read).length);
    };
    loadNotifs();
  }, [user, location.pathname]);

  // Click outside to close dropdowns
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setProfileDropdownOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setNotifDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleMarkAllRead = async () => {
    if (!user) return;
    await notificationService.markAllAsRead(user.uid);
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    setUnreadCount(0);
  };

  const navLinks = [
    { label: 'Discover', path: '/discover' },
    { label: 'Resources', path: '/resources' },
    { label: 'Creators', path: '/creators' },
    { label: 'Collections', path: '/collections' },
    { label: 'About', path: '/about' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full glass-nav transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Left: Brand Logo & Navigation */}
        <div className="flex items-center gap-6">
          <Link to="/" className="flex items-center group" aria-label="PHICHMC Home">
            <img
              src="/main-logo.webp"
              alt="PHICHMC"
              className="h-8 sm:h-9 w-auto object-contain rounded transition-transform group-hover:scale-105"
            />
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => {
              const isActive = location.pathname === link.path;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'text-primary-400 bg-primary-500/10'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Right: Search, Notifications, Create, Auth */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Search trigger */}
          <button
            onClick={() => navigate('/discover')}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-slate-400 text-xs transition-colors"
          >
            <Search size={15} />
            <span className="hidden sm:inline">Search resources...</span>
            <kbd className="hidden lg:inline px-1.5 py-0.5 text-[10px] bg-slate-900 border border-slate-700 rounded text-slate-400">
              /
            </kbd>
          </button>

          {/* Create Resource Button */}
          {user && (
            <Link
              to={isCreator ? '/dashboard/projects/new' : '/apply-creator'}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary-600 hover:bg-primary-500 text-white font-medium text-xs shadow-sm transition-all hover:shadow-primary-500/20"
            >
              <Plus size={15} />
              <span>{isCreator ? 'Create' : 'Become Creator'}</span>
            </Link>
          )}

          {/* Notifications Dropdown */}
          {user && (
            <div className="relative" ref={notifRef}>
              <button
                onClick={() => setNotifDropdownOpen(!notifDropdownOpen)}
                className="relative p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
                title="Notifications"
              >
                <Bell size={18} />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-slate-900 animate-pulse" />
                )}
              </button>

              {notifDropdownOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden z-50">
                  <div className="p-3.5 border-b border-slate-800 flex items-center justify-between">
                    <span className="font-heading font-semibold text-sm text-slate-200">
                      Notifications
                    </span>
                    {unreadCount > 0 && (
                      <button
                        onClick={handleMarkAllRead}
                        className="flex items-center gap-1 text-[11px] text-primary-400 hover:text-primary-300"
                      >
                        <CheckCheck size={13} />
                        <span>Mark all read</span>
                      </button>
                    )}
                  </div>

                  <div className="max-h-80 overflow-y-auto divide-y divide-slate-800/60">
                    {notifications.length === 0 ? (
                      <div className="p-6 text-center text-xs text-slate-400">
                        No notifications yet
                      </div>
                    ) : (
                      notifications.map((item) => (
                        <Link
                          key={item.id}
                          to={item.link || '/notifications'}
                          onClick={() => setNotifDropdownOpen(false)}
                          className={`block p-3.5 text-xs hover:bg-slate-800/50 transition-colors ${
                            !item.read ? 'bg-primary-950/20' : ''
                          }`}
                        >
                          <div className="font-semibold text-slate-200 mb-0.5">{item.title}</div>
                          <div className="text-slate-400 line-clamp-2 leading-relaxed">
                            {item.body}
                          </div>
                          <div className="text-[10px] text-slate-500 mt-1.5 font-mono">
                            {item.createdAt
                              ? formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })
                              : ''}
                          </div>
                        </Link>
                      ))
                    )}
                  </div>

                  <Link
                    to="/notifications"
                    onClick={() => setNotifDropdownOpen(false)}
                    className="block p-2.5 text-center text-xs text-slate-400 hover:text-slate-200 bg-slate-950/40 border-t border-slate-800"
                  >
                    View all notifications
                  </Link>
                </div>
              )}
            </div>
          )}

          {/* User Auth / Profile Dropdown */}
          {user && profile ? (
            <div className="relative" ref={profileRef}>
              <button
                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                className="flex items-center gap-2 p-1 rounded-xl hover:bg-slate-800/80 transition-colors"
              >
                <Avatar
                  src={profile.avatarUrl}
                  name={profile.displayName || profile.username}
                  size="sm"
                />
              </button>

              {profileDropdownOpen && (
                <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-2 z-50 divide-y divide-slate-800/60">
                  <div className="px-3 py-2">
                    <p className="text-sm font-heading font-semibold text-slate-100 truncate">
                      {profile.displayName || profile.username}
                    </p>
                    <p className="text-xs text-slate-400 font-mono truncate">@{profile.username}</p>
                  </div>

                  <div className="py-1">
                    <Link
                      to={`/user/${profile.username}`}
                      onClick={() => setProfileDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                    >
                      <UserIcon size={15} />
                      <span>Public Profile</span>
                    </Link>

                    <Link
                      to="/favorites"
                      onClick={() => setProfileDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                    >
                      <Heart size={15} />
                      <span>Favorites</span>
                    </Link>

                    {isCreator && (
                      <Link
                        to="/dashboard"
                        onClick={() => setProfileDropdownOpen(false)}
                        className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-primary-400 hover:bg-primary-950/40 rounded-lg transition-colors"
                      >
                        <LayoutDashboard size={15} />
                        <span>Creator Dashboard</span>
                      </Link>
                    )}

                    {isAdmin && (
                      <Link
                        to="/admin"
                        onClick={() => setProfileDropdownOpen(false)}
                        className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-amber-400 hover:bg-amber-950/40 rounded-lg transition-colors"
                      >
                        <Shield size={15} />
                        <span>Admin Panel</span>
                      </Link>
                    )}

                    <Link
                      to="/settings"
                      onClick={() => setProfileDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                    >
                      <Settings size={15} />
                      <span>Account Settings</span>
                    </Link>
                  </div>

                  <div className="pt-1">
                    <button
                      onClick={() => {
                        setProfileDropdownOpen(false);
                        logout();
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-400 hover:bg-rose-950/30 rounded-lg transition-colors text-left"
                    >
                      <LogOut size={15} />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                to="/login"
                className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white transition-colors"
              >
                Sign In
              </Link>
              <Link
                to="/register"
                className="px-3 py-1.5 text-xs font-semibold text-white bg-primary-600 hover:bg-primary-500 rounded-lg transition-colors shadow-sm"
              >
                Sign Up
              </Link>
            </div>
          )}

          {/* Mobile hamburger menu */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-900 border-b border-slate-800 px-4 pt-2 pb-6 space-y-2">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-lg text-sm font-medium text-slate-300 hover:bg-slate-800"
            >
              {link.label}
            </Link>
          ))}
          {user && (
            <Link
              to={isCreator ? '/dashboard/projects/new' : '/apply-creator'}
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-lg text-sm font-medium text-primary-400 hover:bg-primary-950/40"
            >
              {isCreator ? '+ Create New Project' : 'Apply as Creator'}
            </Link>
          )}
        </div>
      )}
    </header>
  );
};

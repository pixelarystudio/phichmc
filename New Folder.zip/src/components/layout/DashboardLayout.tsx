import React from 'react';
import { Outlet, NavLink, Link, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Box,
  PlusCircle,
  Users,
  Bell,
  ArrowLeft,
  Shield,
  Sparkles,
  Settings,
  Loader2,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Avatar } from '../common/Avatar';
import { VerifiedBadge } from '../common/VerifiedBadge';

export const DashboardLayout: React.FC = () => {
  const { user, profile, isCreator, isAdmin, loading } = useAuth();
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center">
        <Loader2 className="w-10 h-10 animate-spin text-primary-500 mb-4" />
        <p className="text-sm text-slate-400 font-mono">Loading Creator Studio...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center">
        <h2 className="text-xl font-heading font-semibold text-slate-100 mb-2">Sign in Required</h2>
        <p className="text-sm text-slate-400 mb-6">You must be logged in to view the creator dashboard.</p>
        <button
          onClick={() => navigate('/login')}
          className="px-5 py-2.5 bg-primary-600 hover:bg-primary-500 text-white text-sm font-semibold rounded-xl"
        >
          Sign In
        </button>
      </div>
    );
  }

  if (!isCreator && !isAdmin) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-16 h-16 rounded-2xl bg-primary-500/10 border border-primary-500/20 text-primary-400 flex items-center justify-center mb-6">
          <Sparkles size={32} />
        </div>
        <h2 className="text-2xl font-heading font-bold text-slate-100 mb-2">Creator Account Required</h2>
        <p className="text-sm text-slate-400 max-w-md leading-relaxed mb-6">
          You need an approved Creator account to publish projects, upload Minecraft versions, and view creator analytics.
        </p>
        <Link
          to="/apply-creator"
          className="px-6 py-2.5 bg-primary-600 hover:bg-primary-500 text-white text-sm font-semibold rounded-xl shadow-lg shadow-primary-600/20"
        >
          Apply for Creator Status
        </Link>
      </div>
    );
  }

  const sidebarLinks = [
    { label: 'Overview', path: '/dashboard', icon: LayoutDashboard, end: true },
    { label: 'My Projects', path: '/dashboard/projects', icon: Box },
    { label: 'New Project', path: '/dashboard/projects/new', icon: PlusCircle },
    { label: 'Followers', path: '/dashboard/followers', icon: Users },
    { label: 'Notifications', path: '/dashboard/notifications', icon: Bell },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-background text-slate-100">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-slate-950/80 border-b md:border-b-0 md:border-r border-slate-800/80 p-4 md:p-6 flex flex-col justify-between shrink-0">
        <div>
          {/* Top Brand & Creator Profile Preview */}
          <div className="flex items-center justify-between pb-6 border-b border-slate-800/80 mb-6">
            <Link to="/" className="flex items-center group" aria-label="PHICHMC Home">
              <img src="/main-logo.webp" alt="PHICHMC" className="h-7 w-auto object-contain rounded" />
            </Link>
            <Link
              to="/"
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Return to site"
            >
              <ArrowLeft size={16} />
            </Link>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 mb-6">
            <Avatar src={profile?.avatarUrl} name={profile?.displayName || profile?.username} size="md" />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1 font-heading font-semibold text-xs text-slate-100 truncate">
                <span>{profile?.displayName || profile?.username}</span>
                {profile?.isVerified && <VerifiedBadge type="creator" size="sm" />}
              </div>
              <span className="text-[10px] text-primary-400 font-medium uppercase tracking-wider">
                {profile?.role}
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1">
            {sidebarLinks.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.end}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-primary-600 text-white font-semibold shadow-sm'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                    }`
                  }
                >
                  <Icon size={16} />
                  <span>{item.label}</span>
                </NavLink>
              );
            })}
          </nav>
        </div>

        {/* Footer actions */}
        <div className="pt-6 border-t border-slate-800/80 space-y-2 mt-6">
          {isAdmin && (
            <Link
              to="/admin"
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold text-amber-400 bg-amber-950/20 hover:bg-amber-950/40 border border-amber-900/40 transition-colors"
            >
              <Shield size={14} />
              <span>Admin Panel</span>
            </Link>
          )}
          <Link
            to="/settings"
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
          >
            <Settings size={14} />
            <span>Settings</span>
          </Link>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
        <Outlet />
      </main>
    </div>
  );
};

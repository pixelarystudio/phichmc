import React, { useState } from 'react';
import { Outlet, useLocation, Link } from 'react-router-dom';
import { Header } from './Header';
import { Footer } from './Footer';
import { MobileNav } from './MobileNav';
import { useSiteConfig } from '../../contexts/SiteConfigContext';
import { useAuth } from '../../contexts/AuthContext';
import { AlertTriangle, Info, Bell, X, LogIn } from 'lucide-react';

export const MainLayout: React.FC = () => {
  const { settings, activeAnnouncements } = useSiteConfig();
  const { isAdmin } = useAuth();
  const location = useLocation();
  const [dismissedAnnouncements, setDismissedAnnouncements] = useState<string[]>([]);

  const isAuthOrAdminRoute =
    location.pathname.startsWith('/login') ||
    location.pathname.startsWith('/register') ||
    location.pathname.startsWith('/forgot-password') ||
    location.pathname.startsWith('/admin');

  // Maintenance mode handling
  if (settings.maintenanceMode && !isAdmin && !isAuthOrAdminRoute) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mb-6">
          <AlertTriangle size={32} />
        </div>
        <h1 className="text-2xl sm:text-3xl font-heading font-bold text-slate-100 mb-3">
          PHICHMC is Under Maintenance
        </h1>
        <p className="text-slate-400 max-w-md text-sm leading-relaxed mb-6">
          We are currently performing scheduled maintenance to upgrade platform performance and
          security. Please check back shortly!
        </p>
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <Link
            to="/login"
            className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors"
          >
            <LogIn size={14} />
            <span>Administrator Sign In</span>
          </Link>
        </div>
      </div>
    );
  }

  const visibleAnnouncements = activeAnnouncements.filter(
    (a) => !dismissedAnnouncements.includes(a.id)
  );

  return (
    <div className="min-h-screen flex flex-col bg-background text-slate-100 selection:bg-primary-500 selection:text-white">
      {/* Site-wide Announcements Banner */}
      {visibleAnnouncements.length > 0 && (
        <div className="bg-primary-950 border-b border-primary-900/60 px-4 py-2 text-xs text-primary-200">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Info size={15} className="text-primary-400 shrink-0" />
              <span>
                <strong>{visibleAnnouncements[0].title}:</strong> {visibleAnnouncements[0].content}
              </span>
            </div>
            <button
              onClick={() =>
                setDismissedAnnouncements([...dismissedAnnouncements, visibleAnnouncements[0].id])
              }
              className="p-1 text-primary-400 hover:text-primary-200 transition-colors"
            >
              <X size={14} />
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="flex-1 pb-16 md:pb-0">
        <Outlet />
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile Bottom Navigation */}
      <MobileNav />
    </div>
  );
};

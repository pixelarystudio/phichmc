import React from 'react';

interface AvatarProps {
  src?: string;
  name?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const Avatar: React.FC<AvatarProps> = ({
  src,
  name = 'User',
  size = 'md',
  className = '',
}) => {
  const sizeMap = {
    xs: 'w-6 h-6 text-[10px]',
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-14 h-14 text-base font-medium',
    xl: 'w-20 h-20 text-xl font-bold',
  };

  const initial = name ? name.charAt(0).toUpperCase() : '?';

  if (src) {
    return (
      <img
        src={src}
        alt={name}
        className={`rounded-lg object-cover bg-slate-800 border border-slate-700/60 shrink-0 ${sizeMap[size]} ${className}`}
        loading="lazy"
        onError={(e) => {
          // Fallback if image fails to load
          (e.target as HTMLElement).style.display = 'none';
        }}
      />
    );
  }

  return (
    <div
      className={`rounded-lg bg-gradient-to-br from-primary-600 to-secondary-600 text-white flex items-center justify-center font-heading border border-white/10 shrink-0 ${sizeMap[size]} ${className}`}
    >
      {initial}
    </div>
  );
};

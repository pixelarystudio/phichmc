import React from 'react';
import { CheckCircle2, ShieldCheck } from 'lucide-react';

interface VerifiedBadgeProps {
  type?: 'creator' | 'project';
  size?: 'sm' | 'md';
  showLabel?: boolean;
}

export const VerifiedBadge: React.FC<VerifiedBadgeProps> = ({
  type = 'creator',
  size = 'md',
  showLabel = false,
}) => {
  const iconSize = size === 'sm' ? 14 : 16;

  if (type === 'project') {
    return (
      <span
        title="Reviewed & Verified by PHICHMC Moderation"
        className="inline-flex items-center gap-1 text-emerald-400 font-medium text-xs bg-emerald-500/10 border border-emerald-500/25 px-2 py-0.5 rounded"
      >
        <ShieldCheck size={iconSize} className="text-emerald-400 shrink-0" />
        {showLabel && <span>Verified Project</span>}
      </span>
    );
  }

  return (
    <span
      title="Verified Creator"
      className="inline-flex items-center gap-1 text-primary-400 font-medium text-xs bg-primary-500/10 border border-primary-500/25 px-2 py-0.5 rounded-full"
    >
      <CheckCircle2 size={iconSize} className="text-primary-400 shrink-0" />
      {showLabel && <span>Verified Creator</span>}
    </span>
  );
};

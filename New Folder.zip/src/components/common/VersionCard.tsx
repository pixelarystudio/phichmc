import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Download, ChevronDown, ChevronUp, FileCode, CheckCircle2 } from 'lucide-react';
import { ProjectVersion, ProjectItem } from '../../types';
import { Badge } from './Badge';
import { formatCount } from './ResourceCard';
import { formatDistanceToNow } from 'date-fns';

interface VersionCardProps {
  version: ProjectVersion;
  project: ProjectItem;
  className?: string;
}

export const VersionCard: React.FC<VersionCardProps> = ({ version, project, className = '' }) => {
  const [expanded, setExpanded] = useState<boolean>(false);

  const releaseTypeBadgeVariant = {
    release: 'success' as const,
    beta: 'warning' as const,
    alpha: 'danger' as const,
  };

  const primaryFile = version.files.find((f) => f.primary) || version.files[0];
  const fileSizeMb = primaryFile ? (primaryFile.fileSize / (1024 * 1024)).toFixed(2) + ' MB' : '';

  const formattedDate = version.publishedAt
    ? formatDistanceToNow(new Date(version.publishedAt), { addSuffix: true })
    : 'recently';

  return (
    <div
      className={`rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-colors overflow-hidden ${className}`}
    >
      <div className="p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        {/* Left Side: Version Info */}
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <h4 className="text-base font-heading font-semibold text-slate-100">
              {version.name || `Version ${version.versionNumber}`}
            </h4>
            <Badge variant={releaseTypeBadgeVariant[version.releaseType] || 'neutral'} size="sm">
              {version.releaseType}
            </Badge>
            <span className="text-xs text-slate-400">{formattedDate}</span>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300 mt-2">
            <span className="font-mono text-slate-400">MC:</span>
            {version.minecraftVersions?.map((v) => (
              <span key={v} className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[11px]">
                {v}
              </span>
            ))}
            <span className="text-slate-600">|</span>
            {version.loaders?.map((l) => (
              <span key={l} className="capitalize text-slate-300 text-xs">
                {l}
              </span>
            ))}
          </div>
        </div>

        {/* Right Side: File Info & Download CTA */}
        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800">
          <div className="text-right text-xs text-slate-400">
            {fileSizeMb && <div className="font-medium text-slate-300">{fileSizeMb}</div>}
            <div className="flex items-center gap-1">
              <Download size={12} className="text-primary-400" />
              <span>{formatCount(version.downloadCount || 0)} downloads</span>
            </div>
          </div>

          <Link
            to={`/download/${project.slug}/${version.id}`}
            className="flex items-center gap-2 px-4 py-2 bg-primary-600 hover:bg-primary-500 text-white font-medium text-xs sm:text-sm rounded-lg transition-colors shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500/50"
          >
            <Download size={16} />
            <span>Download</span>
          </Link>
        </div>
      </div>

      {/* Changelog Accordion Header */}
      {version.changelog && (
        <div className="border-t border-slate-800/60 bg-slate-900/30">
          <button
            onClick={() => setExpanded(!expanded)}
            className="w-full px-5 py-2.5 flex items-center justify-between text-xs text-slate-400 hover:text-slate-200 transition-colors"
          >
            <span className="font-medium">Changelog & Release Notes</span>
            {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>
          {expanded && (
            <div className="px-5 pb-4 pt-1 text-xs text-slate-300 whitespace-pre-wrap leading-relaxed font-sans border-t border-slate-800/30 bg-slate-950/20">
              {version.changelog}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

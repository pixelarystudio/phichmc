import React from 'react';
import { Link } from 'react-router-dom';
import { CollectionItem } from '../../types';
import { Layers, FolderHeart } from 'lucide-react';

interface CollectionCardProps {
  collection: CollectionItem;
  className?: string;
}

export const CollectionCard: React.FC<CollectionCardProps> = ({ collection, className = '' }) => {
  return (
    <Link
      to={`/collection/${collection.slug}`}
      className={`group relative flex flex-col p-5 rounded-2xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-secondary-500/40 card-hover-glow transition-all duration-200 overflow-hidden ${className}`}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="w-10 h-10 rounded-lg bg-secondary-500/10 border border-secondary-500/20 text-secondary-400 flex items-center justify-center">
          <FolderHeart size={20} />
        </div>
        <span className="flex items-center gap-1 text-xs text-slate-400 font-medium">
          <Layers size={13} />
          <span>{collection.projectIds?.length || 0} items</span>
        </span>
      </div>

      <h4 className="text-base font-heading font-semibold text-slate-100 group-hover:text-secondary-400 transition-colors mb-1 truncate">
        {collection.name}
      </h4>

      <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mb-4 flex-1">
        {collection.description || 'Curated Minecraft collection on PHICHMC.'}
      </p>

      <div className="pt-3 border-t border-slate-800/60 text-xs text-slate-400 flex items-center justify-between">
        <span>by @{collection.ownerUsername}</span>
        <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
          {collection.visibility}
        </span>
      </div>
    </Link>
  );
};

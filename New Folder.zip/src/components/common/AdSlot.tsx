import React, { useMemo } from 'react';
import { useSiteConfig } from '../../contexts/SiteConfigContext';

interface AdSlotProps {
  placement: 'homepage' | 'discover' | 'project' | 'download' | 'between_cards' | 'footer';
  className?: string;
}

export const AdSlot: React.FC<AdSlotProps> = ({ placement, className = '' }) => {
  const { settings, activeAds } = useSiteConfig();

  // If ads are disabled globally or Adsterra is off and no other ad exists
  if (!settings.adsEnabled) return null;

  // Find active ad unit matching placement
  const adUnit = useMemo(() => {
    return activeAds.find((ad) => ad.placementId === placement && ad.status === 'active');
  }, [activeAds, placement]);

  if (!adUnit || !adUnit.desktopCode) return null;

  return (
    <aside
      aria-label="Advertisement"
      className={`my-6 flex flex-col items-center justify-center p-3 rounded-xl bg-slate-900/40 border border-slate-800/60 overflow-hidden ${className}`}
    >
      <span className="text-[10px] uppercase font-mono tracking-widest text-slate-500 mb-2">
        Advertisement
      </span>

      {/* Sandboxed rendering container */}
      <div className="w-full flex justify-center items-center min-h-[90px]">
        <iframe
          title={`Ad ${adUnit.placementId}`}
          srcDoc={`<!DOCTYPE html><html><head><base target="_blank"><style>body{margin:0;display:flex;justify-content:center;align-items:center;background:transparent;color:#94a3b8;font-family:sans-serif;font-size:12px;}</style></head><body>${adUnit.desktopCode}</body></html>`}
          className="w-full max-w-[728px] h-[90px] border-0 overflow-hidden"
          sandbox="allow-scripts allow-popups allow-same-origin allow-forms"
          loading="lazy"
        />
      </div>
    </aside>
  );
};

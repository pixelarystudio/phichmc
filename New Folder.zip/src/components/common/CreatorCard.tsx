import React from 'react';
import { Link } from 'react-router-dom';
import { UserProfile } from '../../types';
import { Avatar } from './Avatar';
import { VerifiedBadge } from './VerifiedBadge';
import { formatCount } from './ResourceCard';
import { Box, Download, Users } from 'lucide-react';

interface CreatorCardProps {
  creator: Partial<UserProfile>;
  className?: string;
}

export const CreatorCard: React.FC<CreatorCardProps> = ({ creator, className = '' }) => {
  return (
    <Link
      to={`/user/${creator.username}`}
      className={`group flex items-center gap-4 p-4 rounded-xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-primary-500/40 card-hover-glow transition-all duration-200 ${className}`}
    >
      <Avatar
        src={creator.avatarUrl}
        name={creator.displayName || creator.username}
        size="lg"
        className="group-hover:scale-105 transition-transform"
      />

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 mb-0.5">
          <h4 className="font-heading font-semibold text-slate-100 group-hover:text-primary-400 transition-colors truncate">
            {creator.displayName || creator.username}
          </h4>
          {creator.isVerified && <VerifiedBadge type="creator" size="sm" />}
        </div>
        <p className="text-xs text-slate-400 font-mono mb-2">@{creator.username}</p>

        <div className="flex items-center gap-3 text-xs text-slate-400">
          <span className="flex items-center gap-1" title="Projects">
            <Box size={13} className="text-primary-400" />
            <span>{creator.projectCount || 0}</span>
          </span>
          <span className="flex items-center gap-1" title="Followers">
            <Users size={13} className="text-secondary-400" />
            <span>{formatCount(creator.followersCount || 0)}</span>
          </span>
          <span className="flex items-center gap-1" title="Total Downloads">
            <Download size={13} className="text-emerald-400" />
            <span>{formatCount(creator.totalDownloads || 0)}</span>
          </span>
        </div>
      </div>
    </Link>
  );
};

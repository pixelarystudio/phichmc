import React from 'react';

export const ResourceCardSkeleton: React.FC = () => {
  return (
    <div className="flex flex-col sm:flex-row gap-4 p-5 rounded-2xl bg-slate-900/70 border border-slate-800/80 animate-pulse">
      {/* Icon skeleton */}
      <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl bg-slate-800 shrink-0" />

      {/* Content skeleton */}
      <div className="flex-1 min-w-0 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <div className="h-5 w-48 bg-slate-800 rounded" />
            <div className="h-4 w-16 bg-slate-800 rounded" />
          </div>
          <div className="h-3.5 w-full bg-slate-800/70 rounded mb-1.5" />
          <div className="h-3.5 w-3/4 bg-slate-800/50 rounded mb-3" />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/50">
          <div className="flex items-center gap-2">
            <div className="h-4 w-16 bg-slate-800 rounded" />
            <div className="h-4 w-12 bg-slate-800 rounded" />
          </div>
          <div className="flex items-center gap-3">
            <div className="h-4 w-14 bg-slate-800 rounded" />
            <div className="h-4 w-14 bg-slate-800 rounded" />
          </div>
        </div>
      </div>
    </div>
  );
};

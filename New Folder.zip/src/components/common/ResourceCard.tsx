import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Download, Heart, Users, Clock, Box } from 'lucide-react';
import { ProjectItem } from '../../types';
import { Badge } from './Badge';
import { VerifiedBadge } from './VerifiedBadge';
import { formatDistanceToNow } from 'date-fns';
import { useAuth } from '../../contexts/AuthContext';
import { communityService } from '../../services/communityService';
import { useToast } from './Toast';

interface ResourceCardProps {
  project: ProjectItem;
  className?: string;
  showDownloadBtn?: boolean;
}

export const formatCount = (num: number): string => {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'k';
  return num.toString();
};

export const ResourceCard: React.FC<ResourceCardProps> = ({
  project,
  className = '',
  showDownloadBtn = false,
}) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { showToast } = useToast();
  const [isFavorited, setIsFavorited] = useState<boolean>(false);
  const [favCount, setFavCount] = useState<number>(project.favorites || 0);

  const formattedTime = project.updatedAt
    ? formatDistanceToNow(new Date(project.updatedAt), { addSuffix: true })
    : 'recently';

  const typeColorMap: Record<string, 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'neutral'> = {
    mod: 'primary',
    addon: 'secondary',
    resourcepack: 'success',
    shader: 'warning',
    datapack: 'danger',
    map: 'neutral',
    modpack: 'primary',
    skin: 'secondary',
    other: 'neutral',
  };

  const handleFavoriteClick = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      navigate('/login');
      return;
    }
    try {
      const nextState = await communityService.toggleFavorite(project.id, user.uid);
      setIsFavorited(nextState);
      setFavCount((c) => (nextState ? c + 1 : Math.max(0, c - 1)));
      showToast(nextState ? 'Added to favorites!' : 'Removed from favorites');
    } catch {
      showToast('Could not update favorite', 'error');
    }
  };

  return (
    <Link
      to={`/project/${project.slug}`}
      className={`group relative flex flex-col sm:flex-row gap-4 p-5 rounded-2xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-primary-500/40 card-hover-glow transition-all duration-200 ${className}`}
    >
      {/* Project Icon */}
      <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl bg-slate-800/90 border border-slate-700/60 flex items-center justify-center overflow-hidden shrink-0 group-hover:scale-105 transition-transform duration-200 shadow-md">
        {project.iconUrl ? (
          <img
            src={project.iconUrl}
            alt={project.title}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        ) : (
          <Box size={32} className="text-primary-400/80" />
        )}
      </div>

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col justify-between">
        <div>
          {/* Header Row: Title & Type */}
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <h3 className="text-base sm:text-lg font-heading font-semibold text-slate-100 group-hover:text-primary-400 transition-colors truncate">
              {project.title}
            </h3>

            <Badge
              variant={typeColorMap[project.resourceTypeId] || 'neutral'}
              size="sm"
              className="uppercase tracking-wider text-[10px]"
            >
              {project.resourceTypeId}
            </Badge>

            {project.verified && <VerifiedBadge type="project" size="sm" />}
          </div>

          {/* Creator Line */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-2">
            <span>by</span>
            <span className="text-slate-300 font-medium hover:underline">
              {project.creatorDisplayName || project.creatorUsername}
            </span>
            {project.creatorVerified && <VerifiedBadge type="creator" size="sm" />}
          </div>

          {/* Description */}
          <p className="text-xs sm:text-sm text-slate-400 line-clamp-2 leading-relaxed mb-3">
            {project.shortDescription}
          </p>
        </div>

        {/* Footer Row: Badges & Statistics */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800/60">
          {/* Versions and Loaders */}
          <div className="flex flex-wrap items-center gap-1.5">
            {project.minecraftVersions?.slice(0, 2).map((ver) => (
              <span
                key={ver}
                className="text-[11px] font-mono font-medium px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700/60"
              >
                {ver}
              </span>
            ))}
            {project.minecraftVersions?.length > 2 && (
              <span className="text-[10px] text-slate-400 font-mono">
                +{project.minecraftVersions.length - 2}
              </span>
            )}

            {project.loaders?.slice(0, 2).map((loader) => (
              <span
                key={loader}
                className="text-[11px] capitalize px-2 py-0.5 rounded bg-slate-800/60 text-slate-400 border border-slate-700/40"
              >
                {loader}
              </span>
            ))}
          </div>

          {/* Counts: Downloads, Followers, Updated */}
          <div className="flex items-center gap-4 text-xs text-slate-400 font-medium">
            <span className="flex items-center gap-1.5 text-slate-300" title="Total Downloads">
              <Download size={14} className="text-primary-400" />
              {formatCount(project.downloads || 0)}
            </span>

            <span className="flex items-center gap-1.5" title="Followers">
              <Users size={14} className="text-slate-400" />
              {formatCount(project.followers || 0)}
            </span>

            <button
              onClick={handleFavoriteClick}
              title="Add to Favorites"
              className={`flex items-center gap-1 p-1 rounded hover:text-rose-400 transition-colors ${
                isFavorited ? 'text-rose-400' : 'text-slate-400'
              }`}
            >
              <Heart size={14} className={isFavorited ? 'fill-rose-400' : ''} />
              <span>{favCount}</span>
            </button>

            <span className="hidden sm:flex items-center gap-1 text-slate-400" title="Updated">
              <Clock size={13} />
              {formattedTime}
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
};

import React from 'react';
import { useSiteConfig } from '../../contexts/SiteConfigContext';
import { RotateCcw, Filter, Check } from 'lucide-react';

export interface FilterState {
  resourceType: string;
  edition: string;
  version: string;
  loader: string;
  category: string;
  environment: string;
}

interface FilterPanelProps {
  filters: FilterState;
  onChange: (newFilters: FilterState) => void;
  onReset: () => void;
  className?: string;
}

export const FilterPanel: React.FC<FilterPanelProps> = ({
  filters,
  onChange,
  onReset,
  className = '',
}) => {
  const { resourceTypes, categories, loaders, minecraftVersions } = useSiteConfig();

  const handleSelect = (key: keyof FilterState, value: string) => {
    onChange({
      ...filters,
      [key]: filters[key] === value ? 'all' : value,
    });
  };

  const activeCount = Object.values(filters).filter((v) => v !== 'all' && v !== '').length;

  return (
    <div className={`flex flex-col gap-6 p-5 rounded-2xl bg-slate-900/70 border border-slate-800/90 text-sm ${className}`}>
      {/* Top Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2 font-heading font-semibold text-slate-200">
          <Filter size={16} className="text-primary-400" />
          <span>Filters</span>
          {activeCount > 0 && (
            <span className="w-5 h-5 rounded-full bg-primary-500 text-white text-[10px] font-bold flex items-center justify-center">
              {activeCount}
            </span>
          )}
        </div>
        {activeCount > 0 && (
          <button
            onClick={onReset}
            className="flex items-center gap-1 text-xs text-slate-400 hover:text-slate-200 transition-colors"
          >
            <RotateCcw size={12} />
            <span>Reset</span>
          </button>
        )}
      </div>

      {/* 1. Resource Type */}
      <div>
        <label className="block text-xs font-heading font-semibold uppercase tracking-wider text-slate-400 mb-2.5">
          Resource Type
        </label>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            onClick={() => handleSelect('resourceType', 'all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium text-left transition-colors flex items-center justify-between ${
              filters.resourceType === 'all'
                ? 'bg-primary-600 text-white font-semibold'
                : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>All Types</span>
            {filters.resourceType === 'all' && <Check size={12} />}
          </button>
          {resourceTypes.map((type) => (
            <button
              key={type.id}
              type="button"
              onClick={() => handleSelect('resourceType', type.slug)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium text-left transition-colors flex items-center justify-between ${
                filters.resourceType === type.slug
                  ? 'bg-primary-600 text-white font-semibold'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span className="truncate">{type.name}</span>
              {filters.resourceType === type.slug && <Check size={12} />}
            </button>
          ))}
        </div>
      </div>

      {/* 2. Minecraft Edition */}
      <div>
        <label className="block text-xs font-heading font-semibold uppercase tracking-wider text-slate-400 mb-2.5">
          Minecraft Edition
        </label>
        <div className="flex gap-2">
          {['all', 'java', 'bedrock'].map((ed) => (
            <button
              key={ed}
              type="button"
              onClick={() => onChange({ ...filters, edition: ed })}
              className={`flex-1 py-1.5 text-xs font-medium rounded-lg capitalize transition-colors ${
                filters.edition === ed
                  ? 'bg-primary-600 text-white font-semibold'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {ed === 'all' ? 'Any Edition' : ed}
            </button>
          ))}
        </div>
      </div>

      {/* 3. Minecraft Version */}
      <div>
        <label className="block text-xs font-heading font-semibold uppercase tracking-wider text-slate-400 mb-2.5">
          Game Version
        </label>
        <select
          value={filters.version}
          onChange={(e) => onChange({ ...filters, version: e.target.value })}
          className="w-full px-3 py-2 bg-slate-800 border border-slate-700/80 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-primary-500 font-mono"
        >
          <option value="all">Any Version</option>
          {minecraftVersions.map((v) => (
            <option key={v.id} value={v.version}>
              {v.version} ({v.edition})
            </option>
          ))}
        </select>
      </div>

      {/* 4. Loader */}
      <div>
        <label className="block text-xs font-heading font-semibold uppercase tracking-wider text-slate-400 mb-2.5">
          Mod Loader
        </label>
        <div className="flex flex-wrap gap-1.5">
          <button
            type="button"
            onClick={() => handleSelect('loader', 'all')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${
              filters.loader === 'all'
                ? 'bg-primary-600 text-white'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
            }`}
          >
            Any
          </button>
          {loaders.map((loader) => (
            <button
              key={loader.id}
              type="button"
              onClick={() => handleSelect('loader', loader.slug)}
              className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${
                filters.loader === loader.slug
                  ? 'bg-primary-600 text-white'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {loader.name}
            </button>
          ))}
        </div>
      </div>

      {/* 5. Categories */}
      <div>
        <label className="block text-xs font-heading font-semibold uppercase tracking-wider text-slate-400 mb-2.5">
          Category
        </label>
        <div className="flex flex-wrap gap-1.5 max-h-48 overflow-y-auto pr-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => handleSelect('category', cat.slug)}
              className={`px-2.5 py-1 rounded-md text-xs transition-colors ${
                filters.category === cat.slug
                  ? 'bg-secondary-600 text-white font-medium'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* 6. Environment */}
      <div>
        <label className="block text-xs font-heading font-semibold uppercase tracking-wider text-slate-400 mb-2.5">
          Environment
        </label>
        <div className="grid grid-cols-2 gap-1.5">
          {['all', 'client', 'server', 'both'].map((env) => (
            <button
              key={env}
              type="button"
              onClick={() => onChange({ ...filters, environment: env })}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium capitalize text-center transition-colors ${
                filters.environment === env
                  ? 'bg-primary-600 text-white'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {env === 'all' ? 'Any' : env}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

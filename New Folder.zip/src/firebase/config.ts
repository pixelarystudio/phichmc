import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getFunctions } from 'firebase/functions';

// Firebase configuration from environment or direct fallback
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyDdyLCJ-pkRSRwguUqnTEM4KdE6m6w_bq0",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "phich-mc.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "phich-mc",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "phich-mc.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "743033128093",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:743033128093:web:dc4c417c3b8d6e03698074",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-ZNRLYH2CV2"
};

// Initialize Firebase once
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const functions = getFunctions(app);

// Authentication Providers
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

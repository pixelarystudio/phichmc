import { doc, setDoc, getDoc, collection, writeBatch, getDocs, deleteDoc } from 'firebase/firestore';
import { db } from './config';
import {
  ResourceTypeItem,
  CategoryItem,
  LoaderItem,
  MinecraftVersionItem,
  TagItem,
  SiteSettings,
  ProjectItem,
  ProjectVersion,
} from '../types';

export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  siteName: 'PHICHMC',
  tagline: 'Discover. Create. Share Minecraft.',
  primaryColor: '#3B82F6',
  secondaryColor: '#8B5CF6',
  maintenanceMode: false,
  allowRegistration: true,
  allowCreatorApplications: true,
  allowComments: true,
  allowLightMode: true,
  maxUploadSizeBytes: 262144000, // 250 MB
  allowedFileExtensions: ['.jar', '.zip', '.mcpack', '.mcaddon', '.mcworld', '.mcmeta'],
  adsEnabled: true,
  adsterraEnabled: true,
  discordUrl: 'https://discord.gg/minecraft',
  twitterUrl: 'https://x.com',
  githubUrl: 'https://github.com',
};

export const INITIAL_RESOURCE_TYPES: ResourceTypeItem[] = [
  { id: 'mod', slug: 'mod', name: 'Mods', description: 'Game modifications for Java Edition', active: true },
  { id: 'addon', slug: 'addon', name: 'Add-ons', description: 'Behavior and resource add-ons for Bedrock Edition', active: true },
  { id: 'resourcepack', slug: 'resourcepack', name: 'Resource Packs', description: 'Textures, models, and audio overhauls', active: true },
  { id: 'shader', slug: 'shader', name: 'Shaders', description: 'Lighting, shadows, and graphical enhancements', active: true },
  { id: 'datapack', slug: 'datapack', name: 'Data Packs', description: 'Custom mechanics, recipes, and advancements without mods', active: true },
  { id: 'map', slug: 'map', name: 'Maps & Worlds', description: 'Adventure, survival, and parkour custom worlds', active: true },
  { id: 'modpack', slug: 'modpack', name: 'Modpacks', description: 'Curated modpack collections and experiences', active: true },
  { id: 'skin', slug: 'skin', name: 'Skins', description: 'Custom player character appearances', active: true },
  { id: 'other', slug: 'other', name: 'Other', description: 'Tools, presets, scripts, and Minecraft utilities', active: true },
];

export const INITIAL_LOADERS: LoaderItem[] = [
  { id: 'fabric', slug: 'fabric', name: 'Fabric', edition: 'java', active: true },
  { id: 'forge', slug: 'forge', name: 'Forge', edition: 'java', active: true },
  { id: 'neoforge', slug: 'neoforge', name: 'NeoForge', edition: 'java', active: true },
  { id: 'quilt', slug: 'quilt', name: 'Quilt', edition: 'java', active: true },
  { id: 'vanilla-java', slug: 'vanilla', name: 'Vanilla (Java)', edition: 'java', active: true },
  { id: 'bedrock-engine', slug: 'bedrock', name: 'Bedrock Engine', edition: 'bedrock', active: true },
];

export const INITIAL_MC_VERSIONS: MinecraftVersionItem[] = [
  { id: '1-21-4', version: '1.21.4', edition: 'java', majorGroup: '1.21', releaseType: 'release', active: true },
  { id: '1-21-3', version: '1.21.3', edition: 'java', majorGroup: '1.21', releaseType: 'release', active: true },
  { id: '1-21-1', version: '1.21.1', edition: 'java', majorGroup: '1.21', releaseType: 'release', active: true },
  { id: '1-21', version: '1.21', edition: 'java', majorGroup: '1.21', releaseType: 'release', active: true },
  { id: '1-20-6', version: '1.20.6', edition: 'java', majorGroup: '1.20', releaseType: 'release', active: true },
  { id: '1-20-4', version: '1.20.4', edition: 'java', majorGroup: '1.20', releaseType: 'release', active: true },
  { id: '1-20-1', version: '1.20.1', edition: 'java', majorGroup: '1.20', releaseType: 'release', active: true },
  { id: '1-19-4', version: '1.19.4', edition: 'java', majorGroup: '1.19', releaseType: 'release', active: true },
  { id: '1-18-2', version: '1.18.2', edition: 'java', majorGroup: '1.18', releaseType: 'release', active: true },
  { id: '1-16-5', version: '1.16.5', edition: 'java', majorGroup: '1.16', releaseType: 'release', active: true },
  { id: 'bedrock-1-21', version: '1.21.x (Bedrock)', edition: 'bedrock', majorGroup: '1.21', releaseType: 'release', active: true },
  { id: 'bedrock-1-20', version: '1.20.x (Bedrock)', edition: 'bedrock', majorGroup: '1.20', releaseType: 'release', active: true },
];

export const INITIAL_CATEGORIES: CategoryItem[] = [
  { id: 'optimization', name: 'Optimization', slug: 'optimization', description: 'FPS boosts and memory performance', active: true, order: 1 },
  { id: 'technology', name: 'Technology & Machinery', slug: 'technology', description: 'Automation, pipes, energy, and machines', active: true, order: 2 },
  { id: 'adventure', name: 'Adventure & RPG', slug: 'adventure', description: 'Quests, dungeons, bosses, and leveling', active: true, order: 3 },
  { id: 'magic', name: 'Magic & Spells', slug: 'magic', description: 'Sorcery, rituals, artifacts, and wands', active: true, order: 4 },
  { id: 'decoration', name: 'Decoration & Furniture', slug: 'decoration', description: 'Aesthetic blocks, furniture, and lights', active: true, order: 5 },
  { id: 'worldgen', name: 'World Generation', slug: 'worldgen', description: 'New biomes, dimensions, and structures', active: true, order: 6 },
  { id: 'utility', name: 'Utility & QoL', slug: 'utility', description: 'Minimaps, inventory tweaks, and tooltips', active: true, order: 7 },
  { id: 'combat', name: 'Combat & Weapons', slug: 'combat', description: 'Guns, swords, combat overhauls, and shields', active: true, order: 8 },
  { id: 'mobs', name: 'Mobs & Creatures', slug: 'mobs', description: 'Wildlife, mythical beasts, and companion pets', active: true, order: 9 },
  { id: 'food', name: 'Food & Farming', slug: 'food', description: 'Crops, cooking, culinary arts, and trees', active: true, order: 10 },
  { id: 'shaders', name: 'Graphics & Shaders', slug: 'shaders', description: 'Photorealistic lighting and water reflections', active: true, order: 11 },
];

export const INITIAL_TAGS: TagItem[] = [
  { id: 'performance', name: 'Performance', slug: 'performance', active: true },
  { id: 'vanilla-plus', name: 'Vanilla+', slug: 'vanilla-plus', active: true },
  { id: 'multiplayer', name: 'Multiplayer', slug: 'multiplayer', active: true },
  { id: 'medieval', name: 'Medieval', slug: 'medieval', active: true },
  { id: 'scifi', name: 'Sci-Fi', slug: 'scifi', active: true },
  { id: 'automation', name: 'Automation', slug: 'automation', active: true },
  { id: 'gui', name: 'Custom GUI', slug: 'gui', active: true },
  { id: 'audio', name: 'Custom Audio', slug: 'audio', active: true },
];

// Empty: No demo projects
export const SAMPLE_PROJECTS: Array<{ project: ProjectItem; version: ProjectVersion }> = [];

/**
 * Ensures initial platform taxonomy and site settings exist in Firestore without any demo projects.
 */
export async function seedPlatformDefaults(force = false) {
  try {
    const settingsDoc = await getDoc(doc(db, 'siteSettings', 'global'));
    if (settingsDoc.exists() && !force) {
      return;
    }

    const batch = writeBatch(db);

    // 1. Site settings
    batch.set(doc(db, 'siteSettings', 'global'), DEFAULT_SITE_SETTINGS);

    // 2. Resource types
    for (const type of INITIAL_RESOURCE_TYPES) {
      batch.set(doc(db, 'resourceTypes', type.id), type);
    }

    // 3. Loaders
    for (const loader of INITIAL_LOADERS) {
      batch.set(doc(db, 'loaders', loader.id), loader);
    }

    // 4. Minecraft versions
    for (const mcVer of INITIAL_MC_VERSIONS) {
      batch.set(doc(db, 'minecraftVersions', mcVer.id), mcVer);
    }

    // 5. Categories
    for (const cat of INITIAL_CATEGORIES) {
      batch.set(doc(db, 'categories', cat.id), cat);
    }

    // 6. Tags
    for (const tag of INITIAL_TAGS) {
      batch.set(doc(db, 'tags', tag.id), tag);
    }

    await batch.commit();
    console.log('PHICHMC platform settings and taxonomy initialized (clean, 0 demo items).');
  } catch (error) {
    console.error('Error seeding platform defaults:', error);
  }
}

/**
 * Permanently purge all demo projects, demo versions, and demo creators from Firestore.
 */
export async function removeDemoData() {
  try {
    const knownDemoSlugs = [
      'lumina-fps-boost',
      'aetheria-cinematic-shaders',
      'cogworks-steampunk-addon',
      'chroma-faithful-64x',
      'chronicles-eldoria-map',
    ];

    const projectsSnapshot = await getDocs(collection(db, 'projects'));
    for (const projectDoc of projectsSnapshot.docs) {
      const data = projectDoc.data() as ProjectItem;
      const isDemo =
        Boolean(data.isDemo) ||
        knownDemoSlugs.includes(data.slug) ||
        knownDemoSlugs.includes(projectDoc.id) ||
        Boolean(data.creatorId?.startsWith('seed-creator'));

      if (isDemo) {
        // Delete versions subcollection
        try {
          const versionsSnapshot = await getDocs(collection(db, 'projects', projectDoc.id, 'versions'));
          for (const vDoc of versionsSnapshot.docs) {
            await deleteDoc(vDoc.ref);
          }
        } catch (e) {
          console.warn('Error deleting sub-versions for demo project:', e);
        }
        await deleteDoc(projectDoc.ref);
      }
    }

    // Also remove seed creators from users collection if any exist
    try {
      const usersSnapshot = await getDocs(collection(db, 'users'));
      for (const userDoc of usersSnapshot.docs) {
        const uData = userDoc.data();
        if (
          userDoc.id.startsWith('seed-creator') ||
          ['c1', 'c2', 'c3', 'aerocraft', 'solaristudio', 'cogworks'].includes(userDoc.id) ||
          ['aerocraft', 'solaristudio', 'cogworks'].includes(uData?.username)
        ) {
          await deleteDoc(userDoc.ref);
        }
      }
    } catch (e) {
      console.warn('Error deleting demo users:', e);
    }

    console.log('All demo projects and demo creators purged successfully.');
  } catch (err) {
    console.error('Error removing demo data:', err);
  }
}

/**
 * Elevate a user UID to Administrator
 */
export async function makeUserAdmin(uid: string) {
  try {
    const userRef = doc(db, 'users', uid);
    await setDoc(userRef, { role: 'admin', isVerified: true, isCreator: true }, { merge: true });
    return true;
  } catch (err) {
    console.error('Error setting user as admin:', err);
    return false;
  }
}

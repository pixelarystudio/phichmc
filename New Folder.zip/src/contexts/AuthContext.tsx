import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
  sendPasswordResetEmail,
  updateProfile as updateFirebaseProfile
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from '../firebase/config';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  role: UserRole;
  isAdmin: boolean;
  isCreator: boolean;
  loading: boolean;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (email: string, pass: string, username: string, displayName: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updateProfileData: (data: Partial<UserProfile>) => Promise<void>;
  refreshProfile: () => Promise<void>;
  elevateToAdmin: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const SUPER_ADMIN_EMAILS = ['pixelarystudio1@gmail.com'];
export const isSuperAdmin = (email?: string | null): boolean => {
  return Boolean(email && SUPER_ADMIN_EMAILS.includes(email.toLowerCase().trim()));
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const syncUserProfile = async (firebaseUser: User): Promise<UserProfile> => {
    const userRef = doc(db, 'users', firebaseUser.uid);
    const snap = await getDoc(userRef);

    if (snap.exists()) {
      let data = snap.data() as UserProfile;
      // Auto-promote configured super admins
      if (isSuperAdmin(firebaseUser.email) && (data.role !== 'admin' || !data.isCreator || !data.isVerified)) {
        data = { ...data, role: 'admin', isCreator: true, isVerified: true };
        try {
          await updateDoc(userRef, { role: 'admin', isCreator: true, isVerified: true });
        } catch (e) {
          console.warn('Could not auto-promote super admin in firestore:', e);
        }
      }
      setProfile(data);
      return data;
    } else {
      const isSuper = isSuperAdmin(firebaseUser.email);
      // Create initial profile
      const defaultUsername = (firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'miner')
        .toLowerCase()
        .replace(/[^a-z0-9_]/g, '')
        .slice(0, 20) || `user_${firebaseUser.uid.slice(0, 5)}`;

      const newProfile: UserProfile = {
        uid: firebaseUser.uid,
        username: defaultUsername,
        displayName: firebaseUser.displayName || defaultUsername,
        email: firebaseUser.email || undefined,
        avatarUrl: firebaseUser.photoURL || undefined,
        bio: 'Minecraft enthusiast and creator on PHICHMC.',
        role: isSuper ? 'admin' : 'user',
        status: 'active',
        isCreator: isSuper,
        isVerified: isSuper,
        followersCount: 0,
        followingCount: 0,
        projectCount: 0,
        totalDownloads: 0,
        totalViews: 0,
        joinedAt: new Date().toISOString(),
      };

      await setDoc(userRef, newProfile);
      setProfile(newProfile);
      return newProfile;
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          await syncUserProfile(currentUser);
        } catch (err) {
          console.error('Error fetching user profile:', err);
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const refreshProfile = async () => {
    if (!user) return;
    await syncUserProfile(user);
  };

  const loginWithEmail = async (email: string, pass: string) => {
    await signInWithEmailAndPassword(auth, email, pass);
  };

  const registerWithEmail = async (
    email: string,
    pass: string,
    username: string,
    displayName: string
  ) => {
    const cleanUsername = username.toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (!cleanUsername || cleanUsername.length < 3) {
      throw new Error('Username must be at least 3 characters (letters, numbers, underscores).');
    }

    // Verify unique username before creating auth user
    const usernameRef = doc(db, 'usernames', cleanUsername);
    const uSnap = await getDoc(usernameRef);
    if (uSnap.exists()) {
      throw new Error(`The username @${cleanUsername} is already taken. Please choose another.`);
    }

    const res = await createUserWithEmailAndPassword(auth, email, pass);
    await updateFirebaseProfile(res.user, { displayName });

    const isSuper = isSuperAdmin(email);
    const newProfile: UserProfile = {
      uid: res.user.uid,
      username: cleanUsername,
      displayName: displayName || cleanUsername,
      email: email,
      bio: 'Minecraft enthusiast and creator on PHICHMC.',
      role: isSuper ? 'admin' : 'user',
      status: 'active',
      isCreator: isSuper,
      isVerified: isSuper,
      followersCount: 0,
      followingCount: 0,
      projectCount: 0,
      totalDownloads: 0,
      totalViews: 0,
      joinedAt: new Date().toISOString(),
    };

    await setDoc(doc(db, 'users', res.user.uid), newProfile);
    try {
      await setDoc(usernameRef, { uid: res.user.uid, createdAt: new Date().toISOString() });
    } catch (e) {
      console.warn('Could not register username claim document:', e);
    }
    setProfile(newProfile);
  };

  const loginWithGoogle = async () => {
    await signInWithPopup(auth, googleProvider);
  };

  const logout = async () => {
    await signOut(auth);
    setProfile(null);
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  const updateProfileData = async (data: Partial<UserProfile>) => {
    if (!user) throw new Error('Not authenticated');
    const userRef = doc(db, 'users', user.uid);
    await updateDoc(userRef, data);
    setProfile((prev) => (prev ? { ...prev, ...data } : null));
  };

  const elevateToAdmin = async () => {
    if (!user) throw new Error('Not authenticated');
    if (!isSuperAdmin(user.email) && !isSuperAdmin(profile?.email)) {
      throw new Error('Access Denied: Only designated platform administrators may activate admin privileges.');
    }
    const userRef = doc(db, 'users', user.uid);
    await setDoc(
      userRef,
      { role: 'admin', isCreator: true, isVerified: true },
      { merge: true }
    );
    setProfile((prev) =>
      prev ? { ...prev, role: 'admin', isCreator: true, isVerified: true } : null
    );
  };

  const isSuper = isSuperAdmin(user?.email) || isSuperAdmin(profile?.email);
  const role: UserRole = isSuper ? 'admin' : (profile?.role || 'user');
  const isAdmin: boolean = role === 'admin' || isSuper;
  const isCreator: boolean = role === 'creator' || isAdmin || Boolean(profile?.isCreator) || isSuper;

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        role,
        isAdmin,
        isCreator,
        loading,
        loginWithEmail,
        registerWithEmail,
        loginWithGoogle,
        logout,
        resetPassword,
        updateProfileData,
        refreshProfile,
        elevateToAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};

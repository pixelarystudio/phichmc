import React, { createContext, useContext, useEffect, useState } from 'react';
import { doc, getDoc, collection, getDocs, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase/config';
import {
  SiteSettings,
  ResourceTypeItem,
  CategoryItem,
  LoaderItem,
  MinecraftVersionItem,
  TagItem,
  AnnouncementItem,
  AdUnit,
} from '../types';
import {
  DEFAULT_SITE_SETTINGS,
  INITIAL_RESOURCE_TYPES,
  INITIAL_CATEGORIES,
  INITIAL_LOADERS,
  INITIAL_MC_VERSIONS,
  INITIAL_TAGS,
  seedPlatformDefaults,
  removeDemoData,
} from '../firebase/seed';

interface SiteConfigContextType {
  settings: SiteSettings;
  resourceTypes: ResourceTypeItem[];
  categories: CategoryItem[];
  loaders: LoaderItem[];
  minecraftVersions: MinecraftVersionItem[];
  tags: TagItem[];
  activeAnnouncements: AnnouncementItem[];
  activeAds: AdUnit[];
  loading: boolean;
  reloadConfig: () => Promise<void>;
}

const SiteConfigContext = createContext<SiteConfigContextType | undefined>(undefined);

export const SiteConfigProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SITE_SETTINGS);
  const [resourceTypes, setResourceTypes] = useState<ResourceTypeItem[]>(INITIAL_RESOURCE_TYPES);
  const [categories, setCategories] = useState<CategoryItem[]>(INITIAL_CATEGORIES);
  const [loaders, setLoaders] = useState<LoaderItem[]>(INITIAL_LOADERS);
  const [minecraftVersions, setMinecraftVersions] = useState<MinecraftVersionItem[]>(INITIAL_MC_VERSIONS);
  const [tags, setTags] = useState<TagItem[]>(INITIAL_TAGS);
  const [activeAnnouncements, setActiveAnnouncements] = useState<AnnouncementItem[]>([]);
  const [activeAds, setActiveAds] = useState<AdUnit[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const loadData = async () => {
    try {
      // 1. Settings listener / fetch
      const settingsRef = doc(db, 'siteSettings', 'global');
      const settingsSnap = await getDoc(settingsRef);
      if (settingsSnap.exists()) {
        setSettings({ ...DEFAULT_SITE_SETTINGS, ...(settingsSnap.data() as SiteSettings) });
      } else {
        // Auto-seed initial defaults
        await seedPlatformDefaults(false);
      }

      // Purge any lingering demo projects and creators
      await removeDemoData();

      // 2. Resource types
      const rtSnap = await getDocs(collection(db, 'resourceTypes'));
      if (!rtSnap.empty) {
        const items = rtSnap.docs.map((d) => d.data() as ResourceTypeItem).filter((t) => t.active);
        if (items.length > 0) setResourceTypes(items);
      }

      // 3. Categories
      const catSnap = await getDocs(collection(db, 'categories'));
      if (!catSnap.empty) {
        const items = catSnap.docs.map((d) => d.data() as CategoryItem).filter((c) => c.active);
        if (items.length > 0) setCategories(items.sort((a, b) => a.order - b.order));
      }

      // 4. Loaders
      const loadSnap = await getDocs(collection(db, 'loaders'));
      if (!loadSnap.empty) {
        const items = loadSnap.docs.map((d) => d.data() as LoaderItem).filter((l) => l.active);
        if (items.length > 0) setLoaders(items);
      }

      // 5. Minecraft versions
      const mvSnap = await getDocs(collection(db, 'minecraftVersions'));
      if (!mvSnap.empty) {
        const items = mvSnap.docs.map((d) => d.data() as MinecraftVersionItem).filter((v) => v.active);
        if (items.length > 0) setMinecraftVersions(items);
      }

      // 6. Tags
      const tagSnap = await getDocs(collection(db, 'tags'));
      if (!tagSnap.empty) {
        const items = tagSnap.docs.map((d) => d.data() as TagItem).filter((t) => t.active);
        if (items.length > 0) setTags(items);
      }

      // 7. Announcements
      const annSnap = await getDocs(collection(db, 'announcements'));
      if (!annSnap.empty) {
        const items = annSnap.docs
          .map((d) => ({ id: d.id, ...d.data() } as AnnouncementItem))
          .filter((a) => a.active);
        setActiveAnnouncements(items);
      }

      // 8. Ads
      const adsSnap = await getDocs(collection(db, 'ads'));
      if (!adsSnap.empty) {
        const items = adsSnap.docs
          .map((d) => ({ id: d.id, ...d.data() } as AdUnit))
          .filter((a) => a.status === 'active');
        setActiveAds(items);
      }
    } catch (err) {
      console.warn('Using seeded platform defaults due to network or rules initialization:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    // Listen to real-time changes on global settings
    const unsubSettings = onSnapshot(
      doc(db, 'siteSettings', 'global'),
      (docSnap) => {
        if (docSnap.exists()) {
          setSettings((prev) => ({ ...prev, ...(docSnap.data() as SiteSettings) }));
        }
      },
      (error) => {
        console.warn('Real-time settings listener offline, using cached/defaults:', error.message);
      }
    );

    return () => unsubSettings();
  }, []);

  return (
    <SiteConfigContext.Provider
      value={{
        settings,
        resourceTypes,
        categories,
        loaders,
        minecraftVersions,
        tags,
        activeAnnouncements,
        activeAds,
        loading,
        reloadConfig: loadData,
      }}
    >
      {children}
    </SiteConfigContext.Provider>
  );
};

export const useSiteConfig = () => {
  const context = useContext(SiteConfigContext);
  if (!context) throw new Error('useSiteConfig must be used within a SiteConfigProvider');
  return context;
};

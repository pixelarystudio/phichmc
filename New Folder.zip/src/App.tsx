import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { SiteConfigProvider } from './contexts/SiteConfigContext';
import { ToastProvider } from './components/common/Toast';

// Layouts
import { MainLayout } from './components/layout/MainLayout';
import { DashboardLayout } from './components/layout/DashboardLayout';
import { AdminLayout } from './components/layout/AdminLayout';

// Public Pages
import { HomePage } from './pages/public/HomePage';
import { DiscoverPage } from './pages/public/DiscoverPage';
import { ResourceHubPage } from './pages/public/ResourceHubPage';
import { ProjectDetailPage } from './pages/public/ProjectDetailPage';
import { DownloadPage } from './pages/public/DownloadPage';
import { UserProfilePage } from './pages/public/UserProfilePage';
import { CreatorsPage } from './pages/public/CreatorsPage';
import { CollectionsPage } from './pages/public/CollectionsPage';
import { CollectionDetailPage } from './pages/public/CollectionDetailPage';
import { LegalPage } from './pages/public/LegalPage';
import { ReportPage } from './pages/public/ReportPage';
import { NotFoundPage } from './pages/public/NotFoundPage';

// Auth Pages
import { LoginPage } from './pages/auth/LoginPage';
import { RegisterPage } from './pages/auth/RegisterPage';
import { ForgotPasswordPage } from './pages/auth/ForgotPasswordPage';

// User Pages
import { FavoritesPage } from './pages/user/FavoritesPage';
import { SettingsPage } from './pages/user/SettingsPage';
import { NotificationsPage } from './pages/user/NotificationsPage';
import { ApplyCreatorPage } from './pages/user/ApplyCreatorPage';

// Creator Pages
import { CreatorOverviewPage } from './pages/creator/CreatorOverviewPage';
import { CreatorProjectsPage } from './pages/creator/CreatorProjectsPage';
import { CreateProjectPage } from './pages/creator/CreateProjectPage';
import { EditProjectPage } from './pages/creator/EditProjectPage';
import { ProjectVersionsPage } from './pages/creator/ProjectVersionsPage';
import { CreatorFollowersPage } from './pages/creator/CreatorFollowersPage';

// Admin Pages
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AdminModerationPage } from './pages/admin/AdminModerationPage';
import { AdminUsersPage } from './pages/admin/AdminUsersPage';
import { AdminProjectsPage } from './pages/admin/AdminProjectsPage';
import { AdminTaxonomyPage } from './pages/admin/AdminTaxonomyPage';
import { AdminAdsPage } from './pages/admin/AdminAdsPage';
import { AdminReportsPage } from './pages/admin/AdminReportsPage';
import { AdminAuditLogsPage } from './pages/admin/AdminAuditLogsPage';
import { AdminSettingsPage } from './pages/admin/AdminSettingsPage';

export function App() {
  return (
    <AuthProvider>
        <SiteConfigProvider>
          <ToastProvider>
            <BrowserRouter>
              <Routes>
                {/* Public Shell Routes */}
                <Route element={<MainLayout />}>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/discover" element={<DiscoverPage />} />
                  <Route path="/resources" element={<ResourceHubPage />} />
                  <Route path="/resources/:type" element={<ResourceHubPage />} />
                  <Route path="/creators" element={<CreatorsPage />} />
                  <Route path="/collections" element={<CollectionsPage />} />
                  <Route path="/collection/:slug" element={<CollectionDetailPage />} />
                  <Route path="/project/:slug" element={<ProjectDetailPage />} />
                  <Route path="/download/:projectSlug/:versionId" element={<DownloadPage />} />
                  <Route path="/user/:username" element={<UserProfilePage />} />
                  <Route path="/creator/:username" element={<UserProfilePage />} />
                  <Route path="/favorites" element={<FavoritesPage />} />
                  <Route path="/settings" element={<SettingsPage />} />
                  <Route path="/notifications" element={<NotificationsPage />} />
                  <Route path="/apply-creator" element={<ApplyCreatorPage />} />

                  {/* Informational & Legal Pages */}
                  <Route path="/about" element={<LegalPage />} />
                  <Route path="/terms" element={<LegalPage />} />
                  <Route path="/privacy" element={<LegalPage />} />
                  <Route path="/dmca" element={<LegalPage />} />
                  <Route path="/copyright" element={<LegalPage />} />
                  <Route path="/community-guidelines" element={<LegalPage />} />
                  <Route path="/contact" element={<LegalPage />} />
                  <Route path="/report" element={<ReportPage />} />

                  {/* Auth routes */}
                  <Route path="/login" element={<LoginPage />} />
                  <Route path="/register" element={<RegisterPage />} />
                  <Route path="/forgot-password" element={<ForgotPasswordPage />} />

                  {/* 404 Route */}
                  <Route path="*" element={<NotFoundPage />} />
                </Route>

                {/* Creator Dashboard Routes */}
                <Route path="/dashboard" element={<DashboardLayout />}>
                  <Route index element={<CreatorOverviewPage />} />
                  <Route path="projects" element={<CreatorProjectsPage />} />
                  <Route path="projects/new" element={<CreateProjectPage />} />
                  <Route path="projects/:id/edit" element={<EditProjectPage />} />
                  <Route path="projects/:id/versions" element={<ProjectVersionsPage />} />
                  <Route path="followers" element={<CreatorFollowersPage />} />
                  <Route path="notifications" element={<NotificationsPage />} />
                </Route>

                {/* Admin Console Routes */}
                <Route path="/admin" element={<AdminLayout />}>
                  <Route index element={<AdminDashboardPage />} />
                  <Route path="moderation" element={<AdminModerationPage />} />
                  <Route path="users" element={<AdminUsersPage />} />
                  <Route path="projects" element={<AdminProjectsPage />} />
                  <Route path="taxonomy" element={<AdminTaxonomyPage />} />
                  <Route path="categories" element={<AdminTaxonomyPage />} />
                  <Route path="tags" element={<AdminTaxonomyPage />} />
                  <Route path="minecraft-versions" element={<AdminTaxonomyPage />} />
                  <Route path="loaders" element={<AdminTaxonomyPage />} />
                  <Route path="resource-types" element={<AdminTaxonomyPage />} />
                  <Route path="ads" element={<AdminAdsPage />} />
                  <Route path="adsterra" element={<AdminAdsPage />} />
                  <Route path="reports" element={<AdminReportsPage />} />
                  <Route path="audit-logs" element={<AdminAuditLogsPage />} />
                  <Route path="settings" element={<AdminSettingsPage />} />
                </Route>
              </Routes>
            </BrowserRouter>
          </ToastProvider>
        </SiteConfigProvider>
      </AuthProvider>
  );
}

export default App;
